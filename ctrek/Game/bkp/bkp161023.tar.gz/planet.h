extern int percentile();
extern int randomNumber(int max);

typedef struct Planet {
  Menu *mainMenu;
  Menu *commMenu;
  Menu *outfitMenu;
  Menu *repairMenu;
  Menu *shipMenu;
  Menu *supplyMenu;
  Menu *upgradeMenu;
  Menu *buyMenu;
  Menu *sellMenu;
  // faction based
  char name[32];
  int position;
  int initialized;
  // streamline
  int commerceArray[100];
  int shipyardArray[100];
  int outfitArray[100];

  static Planet *newPlanet(int pos) {
    Debug.log("Planet Planet::Planet(%d)", pos);
    Planet *p = (Planet*)malloc(sizeof(Planet));
    p->mainMenu = Menu::newMenu(PLANET_MENU_START);
    p->commMenu = Menu::newMenu(PLANET_MENU_START);
    p->outfitMenu = Menu::newMenu(PLANET_MENU_START);
    p->repairMenu = Menu::newMenu(PLANET_MENU_START);
    p->shipMenu = Menu::newMenu(PLANET_MENU_START);
    p->supplyMenu = Menu::newMenu(PLANET_MENU_START);
    p->upgradeMenu = Menu::newMenu(PLANET_MENU_START);
    p->buyMenu = Menu::newMenu(PLANET_MENU_START);
    p->sellMenu = Menu::newMenu(PLANET_MENU_START);
    memset(p->commerceArray, 0, 100 * sizeof(int));
    memset(p->shipyardArray, 0, 100 * sizeof(int));
    memset(p->outfitArray, 0, 100 * sizeof(int));
    snprintf(p->name, 32, "%s", "Hello world");
    p->position = pos;
    p->initialized = 0;
    return p;
  }

  // Called on docking if uninitialized
  //
  void initialize() {
    Debug.log("void Planet::initialize()");
    if (initialized) {
      return;
    }

    int i = 1;

    // Build menus
    mainMenu->addOption("0: Undock");
    if (initShips()) {
      mainMenu->addOption("%d: Shipyard", i++);
      buildShipMenu();
    }
    if (initOutfit()) {
      mainMenu->addOption("%d: Outfitter", i++);
      buildOutfitterMenu();
    }
    if (initCommerce()) {
      mainMenu->addOption("%d: Commercial Sector", i++);
      buildCommerceMenu();
    }
    mainMenu->addOption("%d: Bar", i++);

    //ACHIEVE_PLANETS++;
    initialized = 1;
    Debug.log("Planet initialized: %d", initialized);
  }

  static Planet *load(FILE *fp) {
    Debug.log("static Planet* Planet::load(%d)", fp);
    Planet *p = newPlanet(0);
    fread(p, sizeof(Planet), 1, fp);
    p->mainMenu = Menu::load(fp);
    p->commMenu = Menu::load(fp);
    p->outfitMenu = Menu::load(fp);
    p->repairMenu = Menu::load(fp);
    p->shipMenu = Menu::load(fp);
    p->supplyMenu = Menu::load(fp);
    p->upgradeMenu = Menu::load(fp);
    p->buyMenu = Menu::load(fp);
    p->sellMenu = Menu::load(fp);
    return p;
  }


  int save(FILE *fp) {
    Debug.log("int Planet::save(%d)", fp);
    fwrite(this, sizeof(Planet), 1, fp);
    mainMenu->save(fp);
    commMenu->save(fp);
    outfitMenu->save(fp);
    repairMenu->save(fp);
    shipMenu->save(fp);
    supplyMenu->save(fp);
    upgradeMenu->save(fp);
    buyMenu->save(fp);
    sellMenu->save(fp);
    return 1;
  }

  static void unload(Planet *p) {
    Debug.log("static void Planet::unload(%d)", p);
    if (p == NULL) {
      return;
    }
    Menu::unload(p->mainMenu);
    Menu::unload(p->commMenu);
    Menu::unload(p->outfitMenu);
    Menu::unload(p->repairMenu);
    Menu::unload(p->shipMenu);
    Menu::unload(p->supplyMenu);
    Menu::unload(p->upgradeMenu);
    Menu::unload(p->buyMenu);
    Menu::unload(p->sellMenu);
    free(p);
  }

  void planetHUD() {
    Debug.log("void Planet::planetHUD()");
    clrs();
    planetWindow();
    minimalHUD(HUD_MINIMAL_START);
    comLog(COM_BELOW_MAP);
  }

  void dock() {
    Debug.log("void Planet::dock(init = %d)", initialized);
    initialize();

    planetHUD();
    if (HS_PASSENGERS != 0) {
      int reward = HS_PASSENGERS * (8000 + randomNumber(4000));
      comLog(COM_BELOW_PLANET_HUD); //66
      printf("Your passenger");
      if (HS_PASSENGERS != 1) {
        printf("s");
      }
      printf(" rewarded you with %s credits.", prefix(reward, 'n'));
      HS_CREDITS += reward;
      HS_PASSENGERS = 0;
    }

    do {
      printAt(PLANET_MENU_HEADER, "%s", "Planetary services:");
      mainMenu->getSelection();

      if (mainMenu->isHighlighted("Shipyard")) {
        shipyardMenu();
      } else if (mainMenu->isHighlighted("Outfitter")) {
        outfitterMenu();
      } else if (mainMenu->isHighlighted("Commercial")) {
        commerceMenu();
      } else if (mainMenu->isHighlighted("Bar")) {
        barMenu();
      } else {
        clrs();
        HS_DATE++;
        return;
      }
    } while (1);
  }

  int initOutfit() {
    Debug.log("int Planet::initOutfit()");
    int i = 0;
    if (percentile() > 20) {
      outfitArray[0] = 1;
      i = 1;
    }
    outfitArray[1] = 5 + randomNumber(10);
    outfitArray[2] = 10 + randomNumber(10);

    if (percentile() > 50) {
      outfitArray[3] = 1;
      i = 1;
    }
    outfitArray[4] = 900 + randomNumber(200); // torps
    outfitArray[5] = 80000 + randomNumber(20000); // cannon 1
    outfitArray[6] = 100000 + randomNumber(100000); // cannon 2
    outfitArray[7] = 5000000 + randomNumber(5000000); // cannon 3

    if (percentile() > 70) {
      outfitArray[8] = 1;
      i = 1;
    }

    return i;
  }

  int initShips() {
    Debug.log("int Planet::initShips()");
    int i = 0;
    if (percentile() > 20) {
      shipyardArray[0] = 1;
      shipyardArray[1] = 10000 + randomNumber(1000);
      i = 1;
    }
    if (percentile() > 40) {
      shipyardArray[2] = 1;
      shipyardArray[3] = 100000 + randomNumber(10000);
      i = 1;
    }
    if (percentile() > 60) {
      shipyardArray[4] = 1;
      shipyardArray[5] = 1000000 + randomNumber(100000);
      i = 1;
    }
    if (percentile() > 80) {
      shipyardArray[6] = 1;
      shipyardArray[7] = 10000000 + randomNumber(10000000);
      i = 1;
    }
    if (percentile() > 90) {
      shipyardArray[8] = 1;
      shipyardArray[9] = 100000000 + randomNumber(100000000);
      i = 1;
    }

    return i;
  }

  int buildShipMenu() {
    Debug.log("int Planet::buildShipMenu()");
    int i = 1;
    shipMenu->addOption("0: Back");
    if (shipyardArray[0] == 1) {
      shipMenu->addOption("%i: NXC-01: P-Class Shuttle", i++);
      shipMenu->indices[i - 1] = 1;
    }
    if (shipyardArray[2] == 1) {
      shipMenu->addOption("%i: Expanse 5060: F-Class Cargo Drone", i++);
      shipMenu->indices[i - 1] = 2;
    }
    if (shipyardArray[4] == 1) {
      shipMenu->addOption("%i: Axess DN-5: F-Class Freighter", i++);
      shipMenu->indices[i - 1] = 3;
    }
    if (shipyardArray[6] == 1) {
      shipMenu->addOption("%i: Green Goose FX-1: C-Class Frigate", i++);
      shipMenu->indices[i - 1] = 4;
    }
    if (shipyardArray[8] == 1) {
      shipMenu->addOption("%i: Imperium Industry FT9: C-Class Destroyer", i++);
      shipMenu->indices[i - 1] = 5;
    }

    return i - 1;
  }


  void shipyardMenu() {
    Debug.log("void Planet::shipyardMenu()");
    int choice;

    planetHUD();
    printAt(PLANET_MENU_HEADER, "%s", "Ships avaliable at this location:");
    do {
      choice = shipMenu->getInput();
      planetHUD();
      printAt(PLANET_MENU_HEADER, "%s", "Ships avaliable at this location:");

      if (shipMenu->highlighted > 0 && shipMenu->highlighted <= shipMenu->length - 1) {
        shipInfo(shipMenu->indices[shipMenu->highlighted]); // 1, 3, 5, 7, 9
      }
      if (choice == KEY_RETURN && !shipMenu->isHighlighted("Back")) {
        comLog(COM_BELOW_PLANET_HUD); //66
        printf("You entered %d", shipMenu->highlighted);
        /*
        comLog(COM_BELOW_PLANET_HUD); //66
        if (submenu == 1) {
          if (HS_CREDITS + resaleValue() < shipyardArray[ship * 2 - 1]) {
            comLog(COM_BELOW_PLANET_HUD); //66
            printf("Insufficient credits.");
          } else {
            cost = (shipyardArray[ship * 2 - 1] - resaleValue() > 0) ?
            shipyardArray[ship * 2 - 1] - resaleValue() : 0;

            printBuySell('b', 's', HS_SHIP_TYPE, ship, cost);
            HS_CREDITS -= cost;
            HS_SHIP_TYPE = ship;
            HS_SHIELD = capacityArray[10 + HS_SHIP_TYPE];
            HS_HULL = capacityArray[20 + HS_SHIP_TYPE];
            HS_ENERGY = capacityArray[30 + HS_SHIP_TYPE];
            HS_TORPEDOS = 0;
            for (i = HS_I_WEAPON1; i <= HS_I_UP_TORP; i++) {
              hudstats[i] = 0;
            }
            ACHIEVE_SHIPS++;
          }
        }*/
      }
    } while (!((choice == KEY_RETURN && shipMenu->isHighlighted("Back")) ||
    choice == 0));
  }


  int buildOutfitterMenu() {
    Debug.log("int Planet::buildOutfitterMenu(menus)");
    int i = 1;
    int n = outfitArray[0] + outfitArray[3] + outfitArray[8];
    outfitMenu->addOption("0: Back");

    if (n > 0) {
      if (outfitArray[0] == 1) {
        outfitMenu->addOption("%d: Repairs", i);
        i++;
        repairMenu->addOption("0: Back");
        repairMenu->addOption("1: Hull Repairs (%i/hour)",
        outfitArray[1] * HS_SHIP_TYPE);
        repairMenu->addOption("2: Power Cell Replacement (%i/hour)",
        outfitArray[2] * HS_SHIP_TYPE);
      }
      if (outfitArray[3] == 1) {
        outfitMenu->addOption("%d: Supplies", i);
        i++;
        supplyMenu->addOption("0: Back");
        supplyMenu->addOption("1: Buy Torpedos (%i/unit)", outfitArray[4]);
        supplyMenu->addOption("2: Sell Torpedos (%i/unit)", outfitArray[4]);
        supplyMenu->addOption("3: Buy Weapons");
        supplyMenu->addOption("4: Sell Weapons");
      }
      if (outfitArray[8] == 1) {
        outfitMenu->addOption("%d: Upgrades", i);
        upgradeMenu->addOption("0: Back");
        upgradeMenu->addOption("1: Ammunition Upgrade");
        upgradeMenu->addOption("2: Cannon Barrel Upgrade");
        upgradeMenu->addOption("3: Advanced Hull Plating Upgrade");
        upgradeMenu->addOption("4: Oscillating Shield Upgrade");
        upgradeMenu->addOption("5: Cargo Refit");
        upgradeMenu->addOption("6: Advanced Torpedo Upgrade");
        upgradeMenu->addOption("7: Port and Polish Engine Upgrade");
        i++;
      }
    }

    return n;
  }


  void outfitterMenu() {
    Debug.log("void Planet::outfitterMenu()");
    int quantity = 0, choice;

    do {
      planetHUD();
      printAt(PLANET_MENU_HEADER, "%s", "Oufitter services at this location:");
      outfitMenu->getSelection();

      if (outfitMenu->isHighlighted("Repair")) {
        do {
          planetHUD();
          printAt(PLANET_MENU_HEADER, "%s", "Repairs:");
          repairMenu->getSelection();

          if (repairMenu->isHighlighted("Hull")) {
            comLog(COM_BELOW_PLANET_HUD);
            printf("Hours: ");
            scanf("%i", &quantity);
            clean();
            tryToBuy(quantity, outfitArray[1] * HS_SHIP_TYPE, COMMODITY_HULL);
          }
          if (repairMenu->isHighlighted("Power")) {
            comLog(COM_BELOW_PLANET_HUD);
            printf("Hours:");
            scanf("%i", &quantity);
            clean();
            tryToBuy(quantity, outfitArray[2] * HS_SHIP_TYPE, COMMODITY_SHIELD);
          }
        } while (!repairMenu->isHighlighted("Back"));
      } else if (outfitMenu->isHighlighted("Supplies")) {
        do {
          planetHUD();
          printAt(PLANET_MENU_HEADER, "%s", "Resupply:");
          supplyMenu->getSelection();

          if (supplyMenu->isHighlighted("Buy Torpedos")) {
            comLog(COM_BELOW_PLANET_HUD);
            printf("Torpedo quantity to buy: ");
            scanf("%i", &quantity);
            clean();
            tryToBuy(quantity, outfitArray[4] * HS_SHIP_TYPE, COMMODITY_TORPEDOS);
          }
          if (supplyMenu->isHighlighted("Sell Torpedos")) {
            gotoXY(3, 27);
            printf("Torpedo quantity to sell: ");
            scanf("%i", &quantity);
            clean();
            tryToSell(quantity, outfitArray[4], COMMODITY_TORPEDOS);
            /*
            comLog(COM_BELOW_PLANET_HUD); //66
            if (HS_TORPEDOS < quantity) {
              comLog(COM_BELOW_PLANET_HUD); //66
              printf("Insufficient supply");
              gotoXY(3, 27);
              printf("Do you want to sell all your torpedos (y/n)?");
              buymax = getch_arrow();
              if (buymax == 'y') {
                printBuySell('s', 't', HS_TORPEDOS,
                HS_TORPEDOS * outfitArray[4], 0);
                HS_TORPEDOS -= HS_TORPEDOS;
                HS_CREDITS -= HS_TORPEDOS * outfitArray[4];
              } else {
                comLog(COM_BELOW_PLANET_HUD); //66
              }
            } else {
              printBuySell('s', 't', quantity, quantity * outfitArray[4], 0);
              HS_TORPEDOS -= quantity;
              HS_CREDITS += quantity * outfitArray[4];
            }*/
          }
          if (supplyMenu->isHighlighted("Buy Weapons")) {
            /*do {
              planetHUD();
              printf("Weapons for sale:");
              //wepon menu
              printf("1: Pew-Pew SK-337 Lance (%s)",
              prefix(outfitArray[5], 'n'));
              printf("2: N00bzorz ID 10-T Killer (%s)",
              prefix(outfitArray[6], 'n'));
              printf("3: Pwnzorz 1337 Cannon (%s)", prefix(outfitArray[7], 'n'));
              printf("1-3: Weapon info    0: Back");
              gotoXY(3, 29);
              subsubmenu = getch_arrow() - '0';
              comLog(COM_BELOW_PLANET_HUD); //66
              if (subsubmenu == 1) {
                do {
                  planetHUD();
                  gotoXY(3, 5);
                  printf("Pew-Pew SK-337 Lance    %s",
                  prefix(outfitArray[5], 'n'));
                  gotoXY(3, 7);
                  printf("Damage: 30");
                  gotoXY(3, 8);
                  printf("Range: 30km");
                  gotoXY(3, 9);
                  printf("Energy depletion: 10 MJ");
                  gotoXY(3, 10);
                  printf("Compatibility: All standard regulation federation"
                  " ships.");
                  gotoXY(3, 27);
                  printf("1: Buy  0: Back");
                  gotoXY(3, 28);
                  subsubsubmenu = getch_arrow() - '0';
                  gotoXY(3, 28);
                  printf("  ");
                  *
                  comLog(COM_BELOW_PLANET_HUD); //66
                  if (subsubsubmenu == 1) {
                    if (HS_CREDITS < outfitArray[5] ||
                    HS_WEAPONS == capacityArray[5 + HS_SHIP_TYPE]) {
                      comLog(COM_BELOW_PLANET_HUD); //66
                      printf("Insufficient funds or space.");
                    } else {
                      cost = outfitArray[5];
                      printBuySell('b', 'g', 1, cost, 0);
                      HS_CREDITS -= cost;
                      for (i = HS_I_WEAPON1; i < HS_I_WEAPON5; i++) {
                        if (hudstats[i] == 0) {
                          hudstats[i] = 1;
                          break;
                        }
                      }
                      hudstats[i] = 1;
                      HS_WEAPONS++;
                      ACHIEVE_WEAPONS++;
                    }
                  }*
                  if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Invalid selection.");
                  }
                } while (subsubsubmenu != 0);
                comLog(COM_BELOW_PLANET_HUD); //66
              }
              if (subsubmenu == 2) {
                do {
                  planetHUD();
                  gotoXY(3, 5);
                  printf("N00bzorz ID10-T Killer    %s",
                  prefix(outfitArray[6], 'n'));
                  gotoXY(3, 7);
                  printf("Damage: 50");
                  gotoXY(3, 8);
                  printf("Range: 50km");
                  gotoXY(3, 9);
                  printf("Energy depletion: 50 MJ");
                  gotoXY(3, 10);
                  printf("Compatibility: F or C class federation ships.");
                  gotoXY(3, 27);
                  printf("1: Buy  0: Back");
                  gotoXY(3, 28);
                  subsubsubmenu = getch_arrow() - '0';
                  gotoXY(3, 28);
                  printf("  ");
                  *
                  comLog(COM_BELOW_PLANET_HUD); //66
                  if (subsubsubmenu == 1) {
                    // TODO split for better errors
                    if (HS_CREDITS < outfitArray[6] || HS_WEAPONS ==
                    capacityArray[5 + HS_SHIP_TYPE] || HS_SHIP_TYPE == 1) {
                      comLog(COM_BELOW_PLANET_HUD); //66
                      printf("Insufficient funds, space, or compatibility.");
                    } else {
                      cost = outfitArray[6];
                      printBuySell('b', 'g', 2, cost, 0);
                      HS_CREDITS -= cost;
                      for (i = HS_WEAPON1; i < HS_WEAPON5; i++) {
                        if (hudstats[i] == 0) {
                          hudstats[i] = 2;
                          break;
                        }
                      }
                      HS_WEAPONS++;
                      ACHIEVE_WEAPONS++;
                    }
                  }*
                  if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Invalid selection.");
                  }
                } while (subsubsubmenu != 0);
                comLog(COM_BELOW_PLANET_HUD); //66
              }
              if (subsubmenu == 3) {
                do {
                  planetHUD();
                  gotoXY(3, 5);
                  printf("Pwnzorz 1337 Cannon    %s",
                  prefix(outfitArray[7], 'n'));
                  gotoXY(3, 7);
                  printf("Damage: 100");
                  gotoXY(3, 8);
                  printf("Range: 70km");
                  gotoXY(3, 9);
                  printf("Energy depletion: 100 MJ");
                  gotoXY(3, 10);
                  printf("Compatibility: C class federation ships.");
                  gotoXY(3, 27);
                  printf("1: Buy  0: Back");
                  gotoXY(3, 28);
                  subsubsubmenu = getch_arrow() - '0';
                  gotoXY(3, 28);
                  printf("  ");
                  *
                  comLog(COM_BELOW_PLANET_HUD); //66
                  if (subsubsubmenu == 1) {
                    if (HS_CREDITS < outfitArray[7] ||
                    HS_WEAPONS == capacityArray[5 + HS_SHIP_TYPE] ||
                    HS_SHIP_TYPE < 4) {
                      comLog(COM_BELOW_PLANET_HUD); //66
                      printf("Insufficient funds, space, or compatibility.");
                    } else {
                      cost = outfitArray[7];
                      printBuySell('b', 'g', 3, cost, 0);
                      HS_CREDITS -= cost;
                      for (i = 1; i < 6; i++) {
                        if (hudstats[HS_I_ENEMY_LOC + i] == 0) {
                          hudstats[HS_I_ENEMY_LOC + i] = 3;
                          break;
                        }
                      }
                      HS_WEAPONS++;
                      ACHIEVE_WEAPONS++;
                    }
                  }*
                  if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Invalid selection.");
                  }
                } while (subsubsubmenu != 0);
                comLog(COM_BELOW_PLANET_HUD); //66
              }
              if (subsubmenu != 1 && subsubmenu != 2 && subsubmenu != 3) {
                gotoXY(67, 27);
                printf("Invalid selection.");
              }
            } while (subsubmenu != 0);
            */
          }
          if (supplyMenu->isHighlighted("Sell weapons")) {
  //        do {
  //          planetHUD();
  //          gotoXY(3, 5);
  //          printf("Your Weapons:");
  //          gotoXY(3, 7);
  //          if (HS_WEAPON1 != 0) {
  //            printf("1: Sell Type %i Weapon in slot 1 (%s)", HS_WEAPON1,
  //            prefix(outfitArray[4 + HS_WEAPON1] / 2, 'n'));
  //          } else {
  //             printf("No weapon in slot 1");
  //          }
  //          gotoXY(3, 8);
  //          if (HS_WEAPON2 != 0) {
  //            printf("2: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON2,
  //            prefix(outfitArray[4 + HS_WEAPON2] / 2, 'n'));
  //          } else {
  //             printf("No weapon in slot 2");
  //          }
  //          gotoXY(3, 9);
  //          if (HS_WEAPON3 != 0) {
  //            printf("3: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON3,
  //            prefix(outfitArray[4 + HS_WEAPON3] / 2, 'n'));
  //          } else {
  //             printf("No weapon in slot 3");
  //          }
  //          gotoXY(3, 10);
  //          if (HS_WEAPON4 != 0) {
  //            printf("4: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON4,
  //            prefix(outfitArray[4 + HS_WEAPON4] / 2, 'n'));
  //          } else {
  //             printf("No weapon in slot 4");
  //          }
  //          gotoXY(3, 11);
  //          if (HS_WEAPON5 != 0) {
  //            printf("5: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON5,
  //            prefix(outfitArray[4 + HS_WEAPON5] / 2, 'n'));
  //          } else {
  //             printf("No weapon in slot 5");
  //          }
  //          gotoXY(3, 13);
  //          printf("0: Back");
  //          gotoXY(3, 27);
  //          printf("1-5: Sell weapon in slot    0: Back");
  //          gotoXY(3, 29);
  //          subsubmenu = getch_arrow() - '0';
  //          gotoXY(3, 27);
  //          comLog(COM_BELOW_PLANET_HUD); //66
  //          if (subsubmenu > 0 && subsubmenu < 6 &&
  //          hudstats[HS_I_ENEMY_LOC + subsubmenu] == 0) {
  //            comLog(COM_BELOW_PLANET_HUD); //66
  //            printf("There is no weapon in that slot.");
  //          }
  //          if (subsubmenu > 0 && subsubmenu < 6 &&
  //          hudstats[HS_I_ENEMY_LOC + subsubmenu] != 0) {
  //            cost = outfitArray[4 + hudstats[HS_I_ENEMY_LOC + subsubmenu]] / 2;
  //            printBuySell('s', HS_I_WEAPONS,
  //            hudstats[HS_I_ENEMY_LOC + subsubmenu],
  //            cost, 0);
  //            HS_CREDITS += cost;
  //            hudstats[HS_I_ENEMY_LOC + subsubmenu] = 0;
  //            HS_WEAPONS--;
  //          }
  //          if (subsubmenu < 0 || subsubmenu > 5) {
  //            comLog(COM_BELOW_PLANET_HUD); //66
  //            printf("Invalid selection.");
  //          }
  //        } while (subsubmenu != 0);
          }
        } while (!supplyMenu->isHighlighted("Back"));
      } else if (outfitMenu->isHighlighted("Upgrade")) {
        planetHUD();
        printAt(PLANET_MENU_HEADER, "Upgrades:");
        do {
          choice = upgradeMenu->getInput();
          planetHUD();
          printAt(PLANET_MENU_HEADER, "Upgrades:");
          if (upgradeMenu->highlighted > 0 && upgradeMenu->highlighted <= 7) {
            Upgrade upgrade = UPGRADES[upgradeMenu->highlighted - 1];
            printLinesAt(3, 14, upgrade.description);
            printf("%i", currentPlayer->upgrades[upgrade.hudstat]);
            if (choice == KEY_RETURN) {
              comLog(COM_BELOW_PLANET_HUD); //66
              if (HS_CREDITS < upgrade.cost) {
                printf("Insufficient credits.");
              } else if (currentPlayer->upgrades[upgrade.hudstat] >= upgrade.max) {
                printf("There is no more room for this upgrade.");
              } else if (HS_SHIP_TYPE < upgrade.compatibility) {
                printf("Upgrade incompatible with ship architecture.");
              } else {
                printf("You bought %s for %s credits.", upgrade.name,
                prefix(upgrade.cost, 'n'));
                HS_CREDITS -= upgrade.cost;
                currentPlayer->upgrades[upgrade.hudstat]++;
                printLinesAt(3, 14, upgrade.description);
                printf("%i", currentPlayer->upgrades[upgrade.hudstat]++);
              }
            }
          }
        } while (!((choice == KEY_RETURN && upgradeMenu->isHighlighted("Back")) ||
        choice == 0));
      }
    } while (!outfitMenu->isHighlighted("Back"));
    planetHUD();
  }


  /**
   * Dynamic commodity preview.
   * Returns last y coord printed at.
   */
  int commodityPreview(int x, int y, int buying) {
    Debug.log("int Planet::commodityPreview(%d %d, %d)", x, y, buying);
    int increment, indexStart = 0, compStart;
    int *array, *comparator;

    if (buying) {
      array = commerceArray;
      comparator = capacityArray;
      compStart = 46;
      increment = 2;
    } else {
      array = currentPlayer->commodities;
      comparator = commodityLastBuy;
      compStart = 0;
      increment = 1;
    }

    if (array[indexStart] > 0) {
      y = printAt(x, y, "Warp Plasma (%i/L) %s", commerceArray[1],
      printDealArrow(commerceArray[1], comparator[compStart], buying));
    }
    indexStart += increment;
    compStart++;
    if (array[indexStart] > 0) {
      y = printAt(x, y, "Duterium (%i/kg) %s", commerceArray[3],
      printDealArrow(commerceArray[3], comparator[compStart], buying));
    }
    indexStart += increment;
    compStart++;
    if (array[indexStart] > 0) {
      y = printAt(x, y, "Latinum (%i/kg) %s", commerceArray[5],
      printDealArrow(commerceArray[5], comparator[compStart], buying));
    }
    indexStart += increment;
    compStart++;
    if (array[indexStart] > 0) {
      y = printAt(x, y, "Water (%i/L) %s", commerceArray[7],
      printDealArrow(commerceArray[7], comparator[compStart], buying));
    }
    indexStart += increment;
    compStart++;
    if (array[indexStart] > 0) {
      y = printAt(x, y, "Uranium Ore (%i/kg) %s", commerceArray[9],
      printDealArrow(commerceArray[9], comparator[compStart], buying));
    }

    return y;
  }


  void buildCommerceMenu() {
    Debug.log("void Planet::buildCommerceMenu(menus)");
    int i, j = 1;
    commMenu->addOption("0: Back");
    buyMenu->addOption("0: Back");
    sellMenu->addOption("0: Back");

    i = 1;
    if (commerceArray[0] == 1) {
      buyMenu->addOption("%i: Warp Plasma (%i/L) %s", i++, commerceArray[1],
      printDealArrow(commerceArray[1], CAP_AVGPLASMA, 1));
    }
    if (commerceArray[2] == 1) {
      buyMenu->addOption("%i: Duterium (%i/kg) %s", i++, commerceArray[3],
      printDealArrow(commerceArray[3], CAP_AVGDUTERIUM, 1));
    }
    if (commerceArray[4] == 1) {
      buyMenu->addOption("%i: Latinum (%i/kg) %s", i++, commerceArray[5],
      printDealArrow(commerceArray[5], CAP_AVGLATINUM, 1));
    }
    if (commerceArray[6] == 1) {
      buyMenu->addOption("%i: Water (%i/L) %s", i++, commerceArray[7],
      printDealArrow(commerceArray[7], CAP_AVGWATER, 1));
    }
    if (commerceArray[8] == 1) {
      buyMenu->addOption("%i: Uranium Ore (%i/kg) %s", i++, commerceArray[9],
      printDealArrow(commerceArray[9], CAP_AVGURANIUM, 1));
    }
    if (i > 1) {
      commMenu->addOption("%d: Buy", j++);
    }

    i = 1;
    if (HS_PLASMA > 0) {
      sellMenu->addOption("%i: Warp Plasma (%i/L) %s", i++, commerceArray[1],
      printDealArrow(commerceArray[1], LASTBUY_PLASMA, 0));
    }
    if (HS_DUTERIUM > 0) {
      sellMenu->addOption("%i: Duterium (%i/kg) %s", i++, commerceArray[3],
      printDealArrow(commerceArray[3], LASTBUY_DUTERIUM, 0));
    }
    if (HS_LATINUM > 0) {
      sellMenu->addOption("%i: Latinum (%i/kg) %s", i++, commerceArray[5],
      printDealArrow(commerceArray[5], LASTBUY_LATINUM, 0));
    }
    if (HS_WATER > 0) {
      sellMenu->addOption("%i: Water (%i/L) %s", i++, commerceArray[7],
      printDealArrow(commerceArray[7], LASTBUY_WATER, 0));
    }
    if (HS_URANIUM > 0) {
      sellMenu->addOption("%i: Uranium Ore (%i/kg) %s", i++, commerceArray[9],
      printDealArrow(commerceArray[9], LASTBUY_URANIUM, 0));
    }
    Debug.log("done adding menu items");
    commMenu->addOption("%d: Sell", j++);
  }


  void getMenuCommodity(char *opt, int *price, int *index) {
    Debug.log("void Planet::getMenuCommodity(%s, %d, %d)", opt, *price, *index);
    if (strstr(opt, "Plasma")) {
      *price = commerceArray[1];
      *index = COMMODITY_PLASMA;
    } else if (strstr(opt, "Duterium")) {
      *price = commerceArray[3];
      *index = COMMODITY_DUTERIUM;
    } else if (strstr(opt, "Latinum")) {
      *price = commerceArray[5];
      *index = COMMODITY_LATINUM;
    } else if (strstr(opt, "Water")) {
      *price = commerceArray[7];
      *index = COMMODITY_WATER;
    } else if (strstr(opt, "Uranium")) {
      *price = commerceArray[9];
      *index = COMMODITY_URANIUM;
    }
    Debug.log("return getMenuCommodity(%s, %d, %d)", opt, *price, *index);

    return;
  }


  void rebuildCommerceMenus() {
    Debug.log("void Planet::rebuildCommerceMenus(menus)");
    int m = Math.max(commMenu->highlighted, 0);
    int b = Math.max(buyMenu->highlighted, 0);
    int s = Math.max(sellMenu->highlighted, 0);
    commMenu->destruct();
    buyMenu->destruct();
    sellMenu->destruct();

    buildCommerceMenu();
    commMenu->highlighted = m;
    buyMenu->highlighted = b;
    sellMenu->highlighted = Math.min(s, sellMenu->length - 1);
  }


  void commerceMenu() {
    Debug.log("void Planet::commerceMenu()");
    int choice, price, hudstat;
    double quantity;

    planetHUD();
    printAt(PLANET_MENU_HEADER, "Commercial sector:");
    do {
      choice = commMenu->getInput();
      planetHUD();
      printAt(PLANET_MENU_HEADER, "Commercial sector:");

      if (commMenu->isHighlighted("Buy")) {
        commodityPreview(3, 10, 1);
        if (choice == KEY_RETURN || (choice > -1 &&
        choice == commMenu->optionIndex("Buy"))) {
          planetHUD();
          do {
            planetWindow();
            printAt(PLANET_MENU_HEADER, "Buy commodities:");
            choice = buyMenu->getSelection();

            if (!buyMenu->isHighlighted("Back")) {
              comLog(COM_BELOW_PLANET_HUD);
              printf("Purchase how many units: ");
              scanf("%lf", &quantity);
              clean();
              getMenuCommodity(buyMenu->options[buyMenu->highlighted], &price, &hudstat);
              if (tryToBuy(quantity, price, hudstat)) {
                commodityLastBuy[hudstat - COMMODITY_PLASMA] = price;
                minimalHUD(HUD_MINIMAL_START);
                rebuildCommerceMenus();
              }
              choice = -1;
            }
          } while (!((buyMenu->isHighlighted("Back") && choice == KEY_RETURN) ||
          choice == 0));
          choice = -1;
          planetHUD();
          printAt(PLANET_MENU_HEADER, "Commercial sector:");
          commodityPreview(3, 10, 1);
        }
      } else if (commMenu->isHighlighted("Sell")) {
        commodityPreview(3, 10, 0);
        if (choice == KEY_RETURN || (choice > -1 &&
        choice == commMenu->optionIndex("Sell"))) {
          planetHUD();
          do {
            planetWindow();
            printAt(PLANET_MENU_HEADER, "Sell commodities:");
            choice = sellMenu->getSelection();

            if (!sellMenu->isHighlighted("Back")) {
              comLog(COM_BELOW_PLANET_HUD);
              printf("Sell how many units: ");
              scanf("%lf", &quantity);
              clean();
              getMenuCommodity(sellMenu->options[sellMenu->highlighted],
              &price, &hudstat);
              if (tryToSell(quantity, price, hudstat)) {
                minimalHUD(HUD_MINIMAL_START);
                rebuildCommerceMenus();
                planetWindow();
                choice = -1;
              }
            }
          } while (!((sellMenu->isHighlighted("Back") && choice == KEY_RETURN) ||
          choice == 0));
          choice = -1;
          planetHUD();
          printAt(PLANET_MENU_HEADER, "Commercial sector:");
          commodityPreview(3, 10, 0);
        }
      }
    } while (!((commMenu->isHighlighted("Back") && choice == KEY_RETURN) ||
    choice == 0));
  }


  int initCommerce() {
    Debug.log("int Planet::initCommerce()");
    int i;
    if (percentile() > 20) {
      commerceArray[0] = 1;
      i = 1;
    }
    commerceArray[1] = 5 + randomNumber(15);
    if (percentile() > 30) {
      commerceArray[2] = 1;
      i = 1;
    }
    commerceArray[3] = 20 + randomNumber(30);
    if (percentile() > 40) {
      commerceArray[4] = 1;
      i = 1;
    }
    commerceArray[5] = 70 + randomNumber(30);
    if (percentile() > 50) {
      commerceArray[6] = 1;
      i = 1;
    }
    commerceArray[7] = 350 + randomNumber(150);
    if (percentile() > 75) {
      commerceArray[8] = 1;
      i = 1;
    }
    commerceArray[9] = 700 + randomNumber(300);

    return i;
  }

  void shipInfo(int ship) {
    Debug.log("void Planet::shipInfo(%d)", ship);
    int x = 3, y = 12;
    const char *sfmt = "%-30s%-16s%s";
    const char *ifmt = "%-30s%-16d%d";
    y = printAt(x, y, sfmt, "Ship stats:", shipName(ship), "Your ship");
    y = printAt(x, y, ifmt, "Shield Power:",
    capacityArray[10 + ship], capacityArray[10 + HS_SHIP_TYPE]);
    y = printAt(x, y, ifmt, "Hull Strength:", capacityArray[20 + ship],
    capacityArray[20 + HS_SHIP_TYPE]);
    y = printAt(x, y, ifmt, "Battery Charge:", capacityArray[30 + ship],
    capacityArray[30 + HS_SHIP_TYPE]);
    y = printAt(x, y, ifmt, "Torpedo Bay Capacity:", capacityArray[40 + ship],
    capacityArray[40 + HS_SHIP_TYPE]);
    y = printAt(x, y, ifmt, "Cargo Hold Capacity:", capacityArray[ship],
    capacityArray[HS_SHIP_TYPE]);
    y = printAt(x, y, ifmt, "Turret Hardpoints:", capacityArray[5 + ship],
    capacityArray[5 + HS_SHIP_TYPE]);
    y = printAt(x, y, "Current Ship Value: %s", prefix(resaleValue(), 'n'));
    y = printAt(x, y, "Cost before resale: %s",
    prefix(shipyardArray[ship * 2 - 1], 'n'));
    y = printAt(x, y, "Total Cost: %s",
    prefix(Math.max(shipyardArray[ship * 2 - 1] - resaleValue(), 0), 'n'));
  }


  int resaleValue() { // torps???????!?!?!?
    Debug.log("int Planet::resaleValue()");
    int guns = 0, i, upgrades;
    float shipCondition;
    upgrades = 50000 * (HS_UP_DMG + HS_UP_RANGE) + 125000 *
    (HS_UP_HULL + HS_UP_SHIELD) + 75000 * HS_UP_CARGO + 250000 * HS_UP_TORP;
    shipCondition = (HS_SHIELD + HS_HULL + HS_ENERGY) /
    (capacityArray[HS_SHIP_TYPE + 10] + capacityArray[HS_SHIP_TYPE + 20] +
    capacityArray[HS_SHIP_TYPE + 30]);


    if (ACHIEVE_SHIPS != 1) {
      for (i = 1; i <= 5; i++) {
        guns += (currentPlayer->weapons[i] == 1) ? outfitArray[5] : 0;
        guns += (currentPlayer->weapons[i] == 2) ? outfitArray[6] : 0;
        guns += (currentPlayer->weapons[i] == 3) ? outfitArray[7] : 0;
      }
      return ((shipCondition * shipyardArray[2 * HS_SHIP_TYPE - 1] / 4) +
      shipyardArray[2 * HS_SHIP_TYPE - 1] / 4 + guns / 2 + upgrades +
      (HS_TORPEDOS * outfitArray[4]) / 2);
    }

    return ((shipCondition * shipyardArray[2 * HS_SHIP_TYPE - 1] / 4) +
    shipyardArray[2 * HS_SHIP_TYPE - 1] / 4);
  }


  /**
   * TODO descriptive var names
   */
  const char* printDealArrow(int price, int lastBuy, int buying) {
    Debug.log("const char* Planet::printDealArrow(%d, %d, %d)", price, lastBuy, buying);
    int cost, comparator;

    if (buying) {
      cost = price;
      comparator = lastBuy;
    } else {
      cost = lastBuy;
      comparator = price;
    }

    if (cost > comparator) {
      if (buying) {
        return STR_COL_RED">"STR_COL_WHITE;
      } else {
        return STR_COL_RED"<"STR_COL_WHITE;
      }
    }
    if (cost < comparator) {
      if (buying) {
        return STR_COL_GREEN"<"STR_COL_WHITE;
      } else {
        return STR_COL_GREEN">"STR_COL_WHITE;
      }
    }
    return STR_COL_YELLOW"="STR_COL_WHITE;
  }


  void barMenu() { // 1525
    Debug.log("void Planet::barMenu()");
    int choice;
    planetHUD();
    do {
      planetHUD();
      gotoXY(3, 5);
      printf("Bar:");
      gotoXY(3, 7);
      printf("1: Ship Logs");
      gotoXY(3, 8);
      printf("2: Achievements");
      gotoXY(3, 9);
      printf("3: Gamble");
      gotoXY(3, 27);
      printf("1-3: Select Passtime\t\t0: Back");
      gotoXY(3, 29);
      choice = getch_arrow() - '0';
      comLog(COM_BELOW_MAP); //66

      switch (choice) {
      case 1:
        if (HS_SHIP_TYPE != 0) {
          printLog();
        } else {
          comLog(COM_BELOW_MAP); //66
          printf("Ship logs not available in this vessel.");
        }
        break;
      case 2:
        achievementsMenu();
        break;
      case 3:
        gamblingMenu();
        break;
      default:
        if (choice != 0) {
          comLog(COM_BELOW_MAP); //66
          printf("Invalid selection.");
        }
      }
    } while (choice != 0);
    //gamble, crew?
  }


  void printLog() {
    Debug.log("void Planet::printLog()");
    int page = 1, choice, i, j;
    do {
      planetHUD(); // max 24
      if (page == 1) {
        gotoXY(3, 5);
        printf("Ship Logs: Current as of %i.%i", HS_DATE / 10,
        HS_DATE % 10);
        gotoXY(3, 8);
        printf("General Information:");
        gotoXY(3, 10);
        printf("Exploration Logs:");
        gotoXY(3, 11);
        printf("\tTime in Space: %i day", HS_DATE - 407594);
        if (HS_DATE - 407594 > 1) {
          printf("s");
        }
        gotoXY(3, 12);
        printf("\tDistance Travelled: %i km", ACHIEVE_DISTANCE * 10);
        // in move - a[0]
        gotoXY(3, 13);
        printf("\tSystems Visited: %i", ACHIEVE_SYSTEMS);
        // in move - a[1]
        gotoXY(3, 14);
        printf("\tPlanets Visited: %i", ACHIEVE_PLANETS);
        // in planet menu
        gotoXY(3, 16);
        printf("Combat Logs:");
        gotoXY(3, 17);
        printf("\tShips Commanded: %i", ACHIEVE_SHIPS);
        // in outfitter
        gotoXY(3, 18);
        printf("\tWeapons Obtained: %i", ACHIEVE_WEAPONS);
        // outfit
        gotoXY(3, 19);
        printf("\tEnemies Ships Destroyed: %i", ACHIEVE_KILLS);
        // damagereport
        gotoXY(3, 20);
        printf("\tCombat Status: Legionnaire");
      }
      if (page == 2) {
        i = 0;
        gotoXY(3, 5);
        printf("Outfit Details:");
        gotoXY(3, 8);
        printf("Ship Class: Section %i ", HS_SHIP_TYPE);
        shipName(HS_SHIP_TYPE), printf(" Class");
        gotoXY(3, 10);
        printf("Armaments:");
        gotoXY(3, 11);
        printf("\tShip Hardpoints: %i", capacityArray[5 + HS_SHIP_TYPE]);
        if (HS_WEAPONS == 0) {
          gotoXY(3, 11 + i);
          printf("\tNo modules currently equipped.");
        } else {
          int guns[3] = {0};
          gotoXY(3, 11 + i);
          printf("\tCurrent installations: %i", HS_WEAPONS);
          for (j = 0; j < 5; j++) {
            guns[currentPlayer->weapons[j] - 1]++;
          }
          for (j = 0; j < 3; j++) {
            if (guns[j] != 0) {
              i++;
              gotoXY(3, 11 + i);
              printf("\t\t%i Class %i type pulse cannon", guns[j], j + 1);
              if (guns[j] > 1) {
                printf("s.");
              } else {
                printf(".");
              }
            }
          }
        }
        if (HS_WEAPONS != 0) {
          i++;
          gotoXY(3, 11 + i);
          rangeCheck(1, 2);
          printf("\tMaximum energy draw: %i MJ", HS_DEPLETION);
        }
        if (HS_WEAPONS != 0) {
          i++;
          gotoXY(3, 11 + i);
          printf("\tPotential damage output: %i", rangeCheck(1, 2));
        }
        if (HS_SHIP_TYPE != 1) {
          i++;
          gotoXY(3, 11 + i);
          printf("\tStandard Sigma Shipyards torpedo bays: %i",
          HS_SHIP_TYPE - 1);
        }
      }
      if (page == 3) {
        //armour pierce+10, carbonalloy+10, tritaniumhullstruts+10,
        //shieldprotocol+10, reconfigure+100, ,photons+20
        i = 0;
        gotoXY(3, 5);
        // 27-32//damage, range, hull, shield, cargo, torp
        printf("Ship Enhancements:");
        gotoXY(3, 7 + i);
        if (HS_UP_DMG != 0) {
          printf("%i Pulse cannon armour piercing shell upgrades.", HS_UP_DMG);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i extra damage per shot.", HS_UP_DMG * 10);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (HS_UP_RANGE != 0) {
          printf("%i Pulse cannon carbon alloy barrel upgrades.", HS_UP_RANGE);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i km range added.", HS_UP_RANGE * 10);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (HS_UP_HULL != 0) {
          printf("%i Tritanium hull strut upgrades.", HS_UP_HULL);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i damage dampening on hull per shot.", HS_UP_HULL * 10);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (HS_UP_SHIELD != 0) {
          printf("%i Shileding reaction protocol reconfigurations.",
          HS_UP_SHIELD);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i damage deflection on shield per shot.",
          HS_UP_SHIELD * 10);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (HS_UP_CARGO != 0) {
          printf("%i Cargo bay reconfigurations and expansion processes.",
          HS_UP_CARGO);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i extra cargo capacity.", HS_UP_CARGO * 100);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (HS_UP_TORP != 0) {
          printf("%i Photonic torpedo upgrades.", HS_UP_TORP);
          i++;
          gotoXY(3, 7 + i);
          printf("\t%i extra damage per torpedo.", HS_UP_TORP * 20);
          i += 2;
        }
        gotoXY(3, 7 + i);
        if (i == 0) {
          printf("No upgrades at this time.");
        }
      }
      gotoXY(3, 27);
      if (page == 1) {
        printf("0: Back\t\t2: Next");
      } else if (page == 3) {
        printf("1: Previous\t\t0: Back");
      } else {
        printf("1: Previous\t\t0: Back\t\t2: Next");
      }

      gotoXY(3, 28);
      choice = getch_arrow() - '0';
      gotoXY(3, 28);
      comLog(COM_BELOW_MAP); //66
      if (choice == 1) {
        if (page == 1) {
          printf("Cannot go back a page") ;
        } else {
          page--;
        }
      }
      if (choice == 2) {
        if (page == 3) {
          printf("Cannot go forward a page") ;
        } else {
          page++;
        }
      }
      if (choice != 1 && choice != 2 && choice != 0) {
        gotoXY(67, 27);
        printf("Invalid selection");
      }
    } while (choice != 0);
  }

  void achievementsMenu() {
    Debug.log("void Planet::achievementsMenu()");
    int page = 1, choice, slot, value;
    do {
      planetHUD(); // dis = 0, 1 = syst, 2 = plan, 3 = ships, 4 = weps, 5 = kills
      if (page == 1) {
        gotoXY(3, 5);
        printf("Basic Achievements:");
        gotoXY(5, 7);
        if (ACHIEVE_DISTANCE >= 20) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("The Traveler");
        printf("\t\t%i/20 km travelled", ACHIEVE_DISTANCE);
        gotoXY(5, 8);
        if (ACHIEVE_SYSTEMS >= 10) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Discoverer");
        printf("\t\t\t%i/10 systems visited", ACHIEVE_SYSTEMS);
        gotoXY(5, 9);
        if (ACHIEVE_PLANETS >= 15) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Land Harr");
        printf("\t\t\t%i/15 planets landed on", ACHIEVE_PLANETS);
        gotoXY(5, 10);
        if (ACHIEVE_SHIPS >= 2) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Able Captain");
        printf("\t\t%i/2 ships owned", ACHIEVE_SHIPS);
        gotoXY(5, 11);
        if (ACHIEVE_WEAPONS >= 5) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Rifleman");
        printf("\t\t\t%i/5 weapons obtained", ACHIEVE_WEAPONS);
        gotoXY(5, 12);
        if (ACHIEVE_KILLS >= 10) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Brute");
        printf("\t\t\t%i/10 enemies killed", ACHIEVE_KILLS);
      }
      if (page == 2) {
        gotoXY(3, 5);
        printf("Intermediate Achievements:");
        gotoXY(5, 7);
        if (ACHIEVE_DISTANCE >= 50) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Well Travelled");
        printf("\t\t%i/50 km travelled", ACHIEVE_DISTANCE);
        gotoXY(5, 8);
        if (ACHIEVE_SYSTEMS >= 25) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Explorer");
        printf("\t\t\t%i/25 systems visited", ACHIEVE_SYSTEMS);
        gotoXY(5, 9);
        if (ACHIEVE_PLANETS >= 35) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Sphere Hunter");
        printf("\t\t%i/35 planets landed on", ACHIEVE_PLANETS);
        gotoXY(5, 10);
        if (ACHIEVE_SHIPS >= 4) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Admiral");
        printf("\t\t\t%i/4 ships owned", ACHIEVE_SHIPS);
        gotoXY(5, 11);
        if (ACHIEVE_WEAPONS >= 15) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Arms Dealer");
        printf("\t\t%i/15 weapons obtained", ACHIEVE_WEAPONS);
        gotoXY(5, 12);
        if (ACHIEVE_KILLS >= 25) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Soldier");
        printf("\t\t\t%i/25 enemiies killed", ACHIEVE_KILLS);
      }
      if (page == 3) {
        gotoXY(3, 5);
        printf("Advanced Achievements:");
        gotoXY(5, 7);
        if (ACHIEVE_DISTANCE >= 150) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Not Lost In Space");
        printf("\t\t%i/150 km travelled", ACHIEVE_DISTANCE);
        gotoXY(5, 8);
        if (ACHIEVE_SYSTEMS >= 50) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Found Your Hemingway");
        printf("\t%i/50 system visited", ACHIEVE_SYSTEMS);
        gotoXY(5, 9);
        if (ACHIEVE_PLANETS >= 75) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Diplomat");
        printf("\t\t\t%i/75 planets landed on", ACHIEVE_PLANETS);
        gotoXY(5, 10);
        if (ACHIEVE_SHIPS >= 5) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Enshiplopedia");
        printf("\t\t%i/5 ships owned", ACHIEVE_SHIPS);
        gotoXY(5, 11);
        if (ACHIEVE_WEAPONS >= 30) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Gun Fettish");
        printf("\t\t%i/30 weapons obtained", ACHIEVE_WEAPONS);
        gotoXY(5, 12);
        if (ACHIEVE_KILLS >= 50) {
          setC(COL_WHITE);
        } else {
          setC(COL_GREY);
        }
        printf("Warren Piece");
        printf("\t\t%i/50 enemies killed", ACHIEVE_KILLS);
  // silver tounge
      }
      setC(COL_WHITE);
      gotoXY(3, 27);
      if (page == 1) {
        printf("0: Back\t\t2: Next");
      } else if (page == 3) {
        printf("1: Previous\t\t0: Back");
      } else {
        printf("1: Previous\t\t0: Back\t\t2: Next");
      }
      gotoXY(3, 29);
      printf("5: achievements[x] = y");
      gotoXY(3, 30);
      choice = getch_arrow() - '0';
      comLog(COM_BELOW_MAP); //66
      if (choice == 5) {
        gotoXY(3, 28);
        printf("achievements[");
        scanf("%i", &slot);
        if (slot > 9) {
          gotoXY(18, 28) ;
        } else {
          gotoXY(17, 28);
        }
        printf("] = ");
        scanf("%i", &value);
        if (slot > 50 || value > 200) {
          gotoXY(67, 27);
          printf("Invalid slot/value");
        } else {
          achievements[slot] = value;
        }
      }
      if (choice == 1) {
        if (page == 1) {
          printf("Cannot go back a page");
        } else {
          page--;
        }
      }
      if (choice == 2) {
        if (page == 3) {
          printf("Cannot go forward a page");
        } else {
          page++;
        }
      }
      if (choice != 1 && choice != 2 && choice != 0 && choice != 5) {
        printf("Invalid selection");
      }
    } while (choice != 0);
  }


  void gamblingMenu() {
    Debug.log("void Planet::gamblingMenu()");
    int choice;
    do {
      planetHUD();

      gotoXY(3, 27);
      printf("Under Development\t\t0: Back");
      choice = getch_arrow() - '0';
      if (choice != 1 && choice != 2 && choice != 0 && choice != 5) {
        printf("Invalid selection");
      }
    } while (choice != 0);
  }

  void planetWindow() {
    Debug.log("void planetWindow()");
    drawWindow(1, 1, 60, 23);
  }


} Planet;

