#define CAP_CARGO       capacityArray[1]
#define CAP_HARDPOINT   capacityArray[6]
#define CAP_SHIELD      capacityArray[11]
#define CAP_HULL        capacityArray[21]
#define CAP_ENERGY      capacityArray[31]
#define CAP_TORP        capacityArray[41]

#define CAP_AVGURANIUM  capacityArray[46]
#define CAP_AVGDUTERIUM capacityArray[47]
#define CAP_AVGLATINUM  capacityArray[48]
#define CAP_AVGPLASMA   capacityArray[46]
#define CAP_AVGWATER    capacityArray[49]
#define SHIP_ESCAPE_POD 0
#define CAP_I_SIZE 50

int capacityArray[CAP_I_SIZE] = {0};
