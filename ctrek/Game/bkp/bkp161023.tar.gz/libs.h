/**
 * Basic math library
 */
typedef struct MATH {

  int min(int a, int b) {
    return (a > b) ? b : a;
  }

  int max(int a, int b) {
    return (a > b) ? a : b;
  }

  float round(float value) {
    return (value - (int)value >= 0.5) ? value + (1 - (value - (int)value)) :
    value - (value - (int)value);
  }

} MATH;
static MATH Math;


/**
 * Debugging library
 */
#define DEBUG_LOG_NONE 0
#define DEBUG_LOG_LOW 1
#define DEBUG_LOG_MEDIUM 2
#define DEBUG_LOG_ALL 3

typedef struct DEBUG {

  int logLevel;


  void init(const char *f, int level) {
    logLevel = level;

    static FILE *logfp = fopen(f, "w");
    if (logfp) {
      dup2(fileno(logfp), STDERR_FILENO);
      fclose(logfp);
    } else {
      fprintf(stderr, "No console log");
    }
  }


  void log(char *s) {
    fprintf(stderr, "LOG: %s\n", s);
  }


  void log(const char *format, ...) {
    char buf[BUFFER_MEDIUM] = {0};
    va_list args;
    va_start(args, format);
    vsnprintf(buf, BUFFER_MEDIUM - 1, format, args);
    fprintf(stderr, "LOG: %s\n", buf);
    va_end(args);
  }

  
  void write(char *s) {
    fprintf(stderr, "%s", s);
  }


  void write(const char *format, ...) {
    char buf[BUFFER_MEDIUM] = {0};
    va_list args;
    va_start(args, format);
    vsnprintf(buf, BUFFER_MEDIUM - 1, format, args);
    fprintf(stderr, "%s", buf);
    va_end(args);
  }

} DEBUG;

static DEBUG Debug;

