struct Player *currentPlayer;
#define SECURITY_SAFE    1
#define SECURITY_UNSAFE  2
#define SECURITY_INRANGE 3

#define SCAN_TYPE_NONE      0
#define SCAN_TYPE_RANGE     1
#define SCAN_TYPE_DEPLETION 2
#define SCAN_PLAYER_RANGE   1
#define SCAN_ENEMY_RANGE    2

#define KEY_ENEMY_MOVE   'E'
#define KEY_SKILLS_ARRAY 'S'
#define KEY_TAKE_DMG     'T'
#define KEY_HUDSTAT      'H'
#define KEY_SCANS        'l'
#define KEY_TORPEDO      'u'
#define KEY_STATS        'p'
#define KEY_SKILLS       'k'
#define KEY_RANGE        'r'
#define KEY_SCAN         'n'
#define KEY_ATTACK       't'
#define KEY_DIVERT       'o'
#define KEY_WARP_UP      'w'
#define KEY_WARP_LEFT    'a'
#define KEY_WARP_RIGHT   'd'
#define KEY_WARP_DOWN    's'
#define KEY_UP           65
#define KEY_DOWN         66
#define KEY_RIGHT        67
#define KEY_LEFT         68
#define KEY_RETURN       10
#define KEY_HELP         '?'
#define KEY_DEBUG ':'
#define KEY_TEST  ';'

#define _HS_I_PLASMA     0
#define _HS_I_DUTERIUM   1
#define _HS_I_LATINUM    2
#define _HS_I_WATER      3
#define _HS_I_URANIUM    4
#define _HS_I_WEAPON1    0
#define _HS_I_WEAPON2    1
#define _HS_I_WEAPON3    2
#define _HS_I_WEAPON4    3
#define _HS_I_WEAPON5    4

// Commodity indeces
#define COMMODITY_SHIELD    1
#define COMMODITY_HULL      2
#define COMMODITY_ENERGY    3
#define COMMODITY_TORPEDOS  4
#define COMMODITY_SHIP_TYPE 5
#define COMMODITY_PLASMA    6
#define COMMODITY_DUTERIUM  7
#define COMMODITY_LATINUM   8
#define COMMODITY_WATER     9
#define COMMODITY_URANIUM   10
#define COMMODITY_WEAPONS   11
//#define COMMODITY_WEAPON1   11
//#define COMMODITY_WEAPON2   12
//#define COMMODITY_WEAPON3   13
//#define COMMODITY_WEAPON4   14
//#define COMMODITY_WEAPON5   15

#define HS_DATE       currentPlayer->date
#define HS_SHIELD     currentPlayer->shield
#define HS_HULL       currentPlayer->hull
#define HS_SYS_X      currentPlayer->systemX
#define HS_SYS_Y      currentPlayer->systemY
#define HS_GAL_X      currentPlayer->galaxyX
#define HS_GAL_Y      currentPlayer->galaxyY
#define HS_SECURITY   currentPlayer->security
#define HS_ENERGY     currentPlayer->energy
#define HS_TORPEDOS   currentPlayer->torpedos
#define HS_CREDITS    currentPlayer->credits
#define HS_PLASMA     currentPlayer->commodities[_HS_I_PLASMA]
#define HS_DUTERIUM   currentPlayer->commodities[_HS_I_DUTERIUM]
#define HS_LATINUM    currentPlayer->commodities[_HS_I_LATINUM]
#define HS_WATER      currentPlayer->commodities[_HS_I_WATER]
#define HS_URANIUM    currentPlayer->commodities[_HS_I_URANIUM]
#define HS_SHIP_TYPE  currentPlayer->shipType
#define HS_WEAPON1    currentPlayer->weapons[0]
#define HS_WEAPON2    currentPlayer->weapons[1]
#define HS_WEAPON3    currentPlayer->weapons[2]
#define HS_WEAPON4    currentPlayer->weapons[3]
#define HS_WEAPON5    currentPlayer->weapons[4]
#define HS_WEAPONS    currentPlayer->nWeapons
#define HS_UP_DMG     currentPlayer->upgrades[0]
#define HS_UP_RANGE   currentPlayer->upgrades[1]
#define HS_UP_HULL    currentPlayer->upgrades[2]
#define HS_UP_SHIELD  currentPlayer->upgrades[3]
#define HS_UP_CARGO   currentPlayer->upgrades[4]
#define HS_UP_TORP    currentPlayer->upgrades[5]
#define HS_UP_ENGINE  currentPlayer->upgrades[6]
#define HS_DEPLETION  currentPlayer->depletion
#define HS_IN_RANGE   currentPlayer->nGunsInRange
#define HS_PASSENGERS currentPlayer->passengers

#define ACHIEVE_I_DISTANCE 0
#define ACHIEVE_I_SYSTEMS  1
#define ACHIEVE_I_PLANETS  2
#define ACHIEVE_I_SHIPS    3
#define ACHIEVE_I_WEAPONS  4
#define ACHIEVE_I_KILLS    5
#define ACHIEVE_I_SIZE     50

#define LASTBUY_PLASMA     currentPlayer->commodityLastBuy[0]
#define LASTBUY_DUTERIUM   currentPlayer->commodityLastBuy[1]
#define LASTBUY_LATINUM    currentPlayer->commodityLastBuy[2]
#define LASTBUY_WATER      currentPlayer->commodityLastBuy[3]
#define LASTBUY_URANIUM    currentPlayer->commodityLastBuy[4]

#define SKILLS_I_SIZE      50
#define UPGRADES_I_SIZE    10
#define COMMODITIES_I_SIZE 10
#define WEAPONS_I_SIZE     5
#define LASTBUY_I_SIZE     5

// Comment
int commodityLastBuy[LASTBUY_I_SIZE] = {0};
int achievements[50] = {0};
int skillsArray[SKILLS_I_SIZE] = {0};

#define ACHIEVE_DISTANCE currentPlayer->achievements[0]
#define ACHIEVE_SYSTEMS  currentPlayer->achievements[1]
#define ACHIEVE_PLANETS  currentPlayer->achievements[2]
#define ACHIEVE_SHIPS    currentPlayer->achievements[3]
#define ACHIEVE_WEAPONS  currentPlayer->achievements[4]
#define ACHIEVE_KILLS    currentPlayer->achievements[5]

struct System *currentSystem;
#define EN_POS         currentSystem->enemy->pos()
#define EN_SHIP_TYPE   currentSystem->enemy->shipType
#define EN_TILE        currentSystem->enemy->tile
#define EN_WEAPON1     currentSystem->enemy->weapons[0]
#define EN_WEAPON2     currentSystem->enemy->weapons[1]
#define EN_WEAPON3     currentSystem->enemy->weapons[2]
#define EN_WEAPON4     currentSystem->enemy->weapons[3]
#define EN_WEAPON5     currentSystem->enemy->weapons[4]
#define EN_SHIELD      currentSystem->enemy->shield
#define EN_HULL        currentSystem->enemy->hull
//#define EN_I_POS       0
//#define EN_I_SHIP_TYPE 1
//#define EN_I_TILE      2
//#define EN_I_WEAPON1   3
//#define EN_I_WEAPON2   4
//#define EN_I_WEAPON3   5
//#define EN_I_WEAPON4   6
//#define EN_I_WEAPON5   7
//#define EN_I_SHIELD    8
//#define EN_I_HULL      9
//#define EN_I_SIZE      10

typedef struct Player {
  int credits;
  int date;
  int depletion;
  int energy;
  int galaxyX;
  int galaxyY;
  int hull;
  int nGunsInRange;
  int nWeapons;
  int pSystem;
  int passengers;
  int security;
  int shield;
  int shipType;
  int systemX;
  int systemY;
  int tile;
  int torpedos;
  int achievements[ACHIEVE_I_SIZE];
  int commodities[COMMODITIES_I_SIZE];
  int commodityLastBuy[LASTBUY_I_SIZE];
  int skills[SKILLS_I_SIZE];
  int upgrades[UPGRADES_I_SIZE];
  int weapons[WEAPONS_I_SIZE];


  static Player *newPlayer() {
    Debug.log("static Player* Player::newPlayer()");
    Player *p = (Player*)malloc(sizeof(Player));
    p->initialize();
    return p;
  }


  static Player *newEnemy() {
    Debug.log("static Player* Player::newEnemy()");
    Player *e = Player::newPlayer();
    e->shipType = 0;
    return e;
  }


  void initialize() {
    Debug.log("void Player::initialize()");

    memset(achievements, 0, ACHIEVE_I_SIZE * sizeof(int));
    memset(skills, 0, SKILLS_I_SIZE * sizeof(int));
    memset(upgrades, 0, UPGRADES_I_SIZE * sizeof(int));
    memset(commodities, 0, COMMODITIES_I_SIZE * sizeof(int));
    memset(weapons, 0, WEAPONS_I_SIZE * sizeof(int));
    memset(commodityLastBuy, 0, LASTBUY_I_SIZE * sizeof(int));
    date = 407595;
    shield = 0;
    hull = 100;
    systemX = 4;
    systemY = 4;
    galaxyX = 0;
    galaxyY = 0;
    security = 0;
    energy = 400;
    torpedos = 0;
    credits = 500;
    shipType = 1;
    weapons[0] = 1;
    nWeapons = 1;
    depletion = 0;
    nGunsInRange = 0;
    passengers = 0;
    achievements[ACHIEVE_I_SYSTEMS] = 1;
    achievements[ACHIEVE_I_SHIPS] = 1;
    achievements[ACHIEVE_I_WEAPONS] = 1;

    /*
    CAP_CARGO = 100; // cargo
    capacityArray[2] = 1000;
    capacityArray[3] = 5000;
    capacityArray[4] = 10000;
    capacityArray[5] = 100000;

    HS_SHIELD = (debug == 1) ? 0 : 10000; //shields
    HS_HULL = (debug == 1) ? 100 : 4000; //hull
    // 3, 4, 5, 6 location
    // 7 = security
    HS_ENERGY = (debug == 1) ? 400 : 60000; //energy
    HS_TORPEDOS = (debug == 1) ? 0 : 100; //torps
    HS_CREDITS = (debug == 1) ? 500 : 1000000000; //monies
    HS_PLASMA = 0;//warp plasma
    HS_DUTERIUM = 0;//duterium
    HS_LATINUM = 0;//latinum
    HS_WATER = 0;//water
    HS_URANIUM = 0;//uranium ore
    // 16, 17, 18 = planets, enemies, stellar objects
    HS_SHIP_TYPE = (debug == 1) ? 1 : 5; //ship class 1-5
    // 20 = enemy location
    HS_WEAPON1 = (debug == 1) ? 1 : 3; //21-25 = weapons (1-3)
    HS_WEAPON2 = (debug == 1) ? 0 : 3;
    HS_WEAPON3 = (debug == 1) ? 0 : 3;
    HS_WEAPON4 = (debug == 1) ? 0 : 3;
    HS_WEAPON5 = (debug == 1) ? 0 : 3;
    HS_WEAPONS = (debug == 1) ? 1 : 5; //total weapons
    HS_UP_DMG = 0;//damage upgrades
    HS_UP_RANGE = 0;//range upgrade
    HS_UP_HULL = 0;//hull upgrade
    HS_UP_SHIELD = 0;//shield upgrade
    HS_UP_CARGO = 0;//cargo upgrade
    HS_UP_TORP = 0;//torpedo upgrade
    HS_UP_ENGINE = 0;//engine upgrade
    // HS_DEPLETION = energy depletion
    // HS_IN_RANGE = guns in range
    HS_PASSENGERS = 0;//passengers
    // shuttle, cargo, freight, frigate, destroyer
    // shields1 = 0, 300, 500, 1000, 10000            1
    // hull2 = 100, 500, 700, 2000, 4000              2
    // energy8 = 0, 1000, 2000, 4000, 30000           3
    // torps9 = 0, 5, 10, 40, 100                     4
    // cargo11-15 = 100, 1000, 3000, 100000, 50000    5
    // ship range = 6-10                          6
    // cannon hardpoints = 16-20                  7

    #define COMMODITY_SHIELD    1
    #define COMMODITY_HULL      2
    #define COMMODITY_ENERGY    3
    #define COMMODITY_TORPEDOS  4
    #define COMMODITY_SHIP_TYPE 5
    #define COMMODITY_PLASMA    6
    #define COMMODITY_DUTERIUM  7
    #define COMMODITY_LATINUM   8
    #define COMMODITY_WATER     9
    #define COMMODITY_URANIUM   10
    #define COMMODITY_WEAPONS   11
    CAP_CARGO = 100; // cargo
    capacityArray[2] = 1000;
    capacityArray[3] = 5000;
    capacityArray[4] = 10000;
    capacityArray[5] = 100000;
    */
  }


  static Player *load(FILE *fp) {
    Debug.log("static Player* Planet::load(%d)", fp);
    Player *p = newPlayer();
    fread(p, sizeof(Player), 1, fp);
    return p;
  }


  int save(FILE *fp) {
    Debug.log("int Player::save(%d)", fp);
    fwrite(this, sizeof(Player), 1, fp);
    return 1;
  }


  static void unload(Player *p) {
    Debug.log("static void Player::unload(%d)", p);
    if (p == NULL) {
      return;
    }
    free(p);
  }


  int pos() {
    return systemX + 10 * systemY;
  }


  int setPos(int p) {
    if (p < 0 || p > 99) {
      return 0;
    }
    systemX = p % 10;
    systemY = p / 10;
    return 1;
  }

} Player;

