/**
 * Selectable menu class
 */
typedef struct Menu {
  int length;
  int highlighted;
  int x;
  int y;
  char **options;
  int *indices;


  ~Menu() {
    destruct();
  }


  void destruct() {
    int i;
    for (i = 0; i < length; ++i) {
      free(options[i]);
    }
    if (length > 0) {
      free(options);
      free(indices);
    }
    length = 0;
    highlighted = -1;
  }


  // Allow forward declarations
  Menu() {
    x = 1;
    y = 1;
    length = 0;
    highlighted = -1;
  }


  Menu(int sx, int sy) {
    x = sx;
    y = sy;
    length = 0;
    highlighted = -1;
  }


  static Menu *load() {
    Menu *m = newMenu(0, 0);
    fread(m, sizeof(Menu), 1, fp);
    fread(&(m->length), sizeof(int), 1, fp);
    m->options = (char**)malloc(m->length * sizeof(char*));
    int i;
    for (i = 0; i < m->length; i++) {
      if (i == 0) {
      m->options[i]
      fread(m->options[i], 1024, 1, fp);
      fread(m->indices[i], sizeof(int), 1, fp);
    }
  }

  save(FILE *fp) {
    fwrite(this, sizeof(Menu), 1, fp);
    fwrite(&length, sizeof(int), 1, fp);
    int i;
    for (i = 0; i < length; i++) {
      fwrite(options[i], 1024, 1, fp);
      fwrite(indices[i], sizeof(int), 1, fp);
    }
  }


  int addOption(const char *format, ...) {
    char buffer[1024] = {0};
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, 1024, format, args);
    va_end(args);

    return addOption(buffer);
  }


  int addOption(char *i) {
    if (length == 0) {
      options = (char**)malloc(sizeof(char*));
      indices = (int*)malloc(sizeof(int));
    } else {
      options = (char**)realloc(options, (length + 1) * sizeof(char*));
      indices = (int*)realloc(indices, (length + 1 ) * sizeof(int));
    }

    options[length] = (char*)malloc(128 * sizeof(char));
    strcpy(options[length], i);
    length++;
    return length;
  }


  int isHighlighted(const char *searchStr) {
    return (strstr(options[highlighted], searchStr) != NULL);
  }

  int optionIndex(const char *searchStr) {
    int i;
    for (i = 0; i < length; ++i) {
      if (strstr(options[i], searchStr) != NULL) {
        return i;
      }
    }

    return -1;
  }

  int getSelection() {
    int choice = -1;
    while (choice == -1) {
      choice = getInput();
    }
    return choice;
  }

  int getInput() {
    int i, choice = -1;

    if (highlighted < 0 || highlighted >= length) {
      highlighted = 0;
    }

    for (i = 0; i < length; i++) {
      gotoXY(x, y + i);
      if (i == highlighted) {
        setCB(COL_BLACK, COL_WHITE);
      } else {
        setCB(COL_WHITE, COL_BLACK);
      }
      printf("%s", options[i]);
      setCB(COL_WHITE, COL_BLACK);
    }

    choice = getch_arrow();
    Debug.log("\n\nmenu choice: %c", choice);
    if (choice == KEY_UP || choice == KEY_WARP_UP) {
      highlighted = (highlighted + length - 1) % length;
      return -1;
    } else if (choice == KEY_DOWN || choice == KEY_WARP_DOWN) {
      highlighted = (highlighted + 1) % length;
      return -1;
    } else if (choice == KEY_RETURN) {
      return KEY_RETURN;
    } else if (choice - '0' >= 0 && choice - '0' <= length - 1) {
      highlighted = choice - '0';
      return highlighted;
    } else if (choice == KEY_HELP) {
      return KEY_HELP;
    }

    return -1;
  }

} Menu;


/**
 * Basic math library
 */
typedef struct MATH {

  int min(int a, int b) {
    return (a > b) ? b : a;
  }

  int max(int a, int b) {
    return (a > b) ? a : b;
  }

  float round(float value) {
    return (value - (int)value >= 0.5) ? value + (1 - (value - (int)value)) :
    value - (value - (int)value);
  }

} MATH;
static MATH Math;

