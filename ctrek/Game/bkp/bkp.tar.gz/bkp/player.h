//#define HS_I_DATE       0
//#define HS_I_SHIELD     1
//#define HS_I_HULL       2
//#define HS_I_SYS_X      3
//#define HS_I_SYS_Y      4
//#define HS_I_GAL_X      5
//#define HS_I_GAL_Y      6
//#define HS_I_SECURITY   7
//#define HS_I_ENERGY     8
//#define HS_I_TORPEDOS   9
//#define HS_I_CREDITS    10
#define HS_I_PLASMA     0
#define HS_I_DUTERIUM   1
#define HS_I_LATINUM    2
#define HS_I_WATER      3
#define HS_I_URANIUM    4
//#define HS_I_PLANETS    16
//#define HS_I_ENEMIES    17
//#define HS_I_STELLAR    18
//#define HS_I_SHIP_TYPE  19
//#define HS_I_ENEMY_LOC  20
#define HS_I_WEAPON1    0
#define HS_I_WEAPON2    1
#define HS_I_WEAPON3    2
#define HS_I_WEAPON4    3
#define HS_I_WEAPON5    4
//#define HS_I_WEAPONS    26
//#define HS_I_DEPLETION  38
//#define HS_I_IN_RANGE   39
//#define HS_I_PASSENGERS 40
//#define HS_I_SIZE       100

// Commodity indeces
#define HS_I_COM_SHIELD     1
#define HS_I_COM_HULL       2
#define HS_I_COM_ENERGY     8
#define HS_I_COM_TORPEDOS   9
#define HS_I_COM_PLASMA     50
#define HS_I_COM_DUTERIUM   51
#define HS_I_COM_LATINUM    52
#define HS_I_COM_WATER      53
#define HS_I_COM_URANIUM    54
#define HS_I_COM_WEAPON1  60
#define HS_I_COM_WEAPON2  61
#define HS_I_COM_WEAPON3  62
#define HS_I_COM_WEAPON4  63
#define HS_I_COM_WEAPON5  64
#define HS_I_COM_WEAPONS  65

#define HS_DATE       currentPlayer->date
#define HS_SHIELD     currentPlayer->shield
#define HS_HULL       currentPlayer->hull
#define HS_SYS_X      currentPlayer->systemX
#define HS_SYS_Y      currentPlayer->systemY
#define HS_GAL_X      currentPlayer->galaxyX
#define HS_GAL_Y      currentPlayer->galaxyY
#define HS_SECURITY   currentPlayer->security
#define HS_ENERGY     currentPlayer->energy
#define HS_TORPEDOS   currentPlayer->torpedos
#define HS_CREDITS    currentPlayer->credits
#define HS_PLASMA     currentPlayer->commodities[HS_I_PLASMA]
#define HS_DUTERIUM   currentPlayer->commodities[HS_I_DUTERIUM]
#define HS_LATINUM    currentPlayer->commodities[HS_I_LATINUM]
#define HS_WATER      currentPlayer->commodities[HS_I_WATER]
#define HS_URANIUM    currentPlayer->commodities[HS_I_URANIUM]
#define HS_SHIP_TYPE  currentPlayer->shipType
#define HS_WEAPON1    currentPlayer->weapons[0]
#define HS_WEAPON2    currentPlayer->weapons[1]
#define HS_WEAPON3    currentPlayer->weapons[2]
#define HS_WEAPON4    currentPlayer->weapons[3]
#define HS_WEAPON5    currentPlayer->weapons[4]
#define HS_WEAPONS    currentPlayer->nWeapons
#define HS_UP_DMG     currentPlayer->upgrades[0]
#define HS_UP_RANGE   currentPlayer->upgrades[1]
#define HS_UP_HULL    currentPlayer->upgrades[2]
#define HS_UP_SHIELD  currentPlayer->upgrades[3]
#define HS_UP_CARGO   currentPlayer->upgrades[4]
#define HS_UP_TORP    currentPlayer->upgrades[5]
#define HS_UP_ENGINE  currentPlayer->upgrades[6]
#define HS_DEPLETION  currentPlayer->depletion
#define HS_IN_RANGE   currentPlayer->nGunsInRange
#define HS_PASSENGERS currentPlayer->passengers

#define ACHIEVE_I_DISTANCE 0
#define ACHIEVE_I_SYSTEMS  1
#define ACHIEVE_I_PLANETS  2
#define ACHIEVE_I_SHIPS    3
#define ACHIEVE_I_WEAPONS  4
#define ACHIEVE_I_KILLS    5
#define ACHIEVE_I_SIZE     50

#define SKILLS_I_SIZE      50
#define UPGRADES_I_SIZE    10
#define COMMODITIES_I_SIZE 10
#define WEAPONS_I_SIZE     5

#define ACHIEVE_DISTANCE currentPlayer->achievements[0]
#define ACHIEVE_SYSTEMS  currentPlayer->achievements[1]
#define ACHIEVE_PLANETS  currentPlayer->achievements[2]
#define ACHIEVE_SHIPS    currentPlayer->achievements[3]
#define ACHIEVE_WEAPONS  currentPlayer->achievements[4]
#define ACHIEVE_KILLS    currentPlayer->achievements[5]

typedef struct Player {
  int date;
  int shield;
  int hull;
  int pSystem;
  int systemX;
  int systemY;
  int galaxyX;
  int galaxyY;
  int security;
  int energy;
  int torpedos;
  int credits;

  //int planets;
  //int enemies;
  //int stellar;
  int shipType;
  //int pEnemy;
  int weapons[5];
  int nWeapons;
  int depletion;
  int nGunsInRange;
  int passengers;
  int upgrades[UPGRADES_I_SIZE];
  int achievements[ACHIEVE_I_SIZE];
  int skills[SKILLS_I_SIZE];
  int commodities[COMMODITIES_I_SIZE];

  static Player *newPlayer() {
    Debug.log("static Player* Player::newPlayer()");
    Player *p = (Player*)malloc(sizeof(Player));
    p->initialize();
    return p;
  }


  void initialize() {
    Debug.log("void Player::initialize()");

    memset(achievements, 0, ACHIEVE_I_SIZE * sizeof(int));
    memset(skills, 0, SKILLS_I_SIZE * sizeof(int));
    memset(upgrades, 0, UPGRADES_I_SIZE * sizeof(int));
    memset(commodities, 0, COMMODITIES_I_SIZE * sizeof(int));
    memset(weapons, 0, WEAPONS_I_SIZE * sizeof(int));
    date = 407595;
    shield = 0;
    hull = 100;
    systemX = 4;
    systemY = 4;
    galaxyX = 0;
    galaxyY = 0;
    security = 0;
    energy = 400;
    torpedos = 0;
    credits = 500;
    shipType = 1;
    weapons[0] = 1;
    nWeapons = 1;
    depletion = 0;
    nGunsInRange = 0;
    passengers = 0;
    achievements[ACHIEVE_I_SYSTEMS] = 1;
    achievements[ACHIEVE_I_SHIPS] = 1;
    achievements[ACHIEVE_I_WEAPONS] = 1;

    /*
    HS_SHIELD = (debug == 1) ? 0 : 10000; //shields
    HS_HULL = (debug == 1) ? 100 : 4000; //hull
    // 3, 4, 5, 6 location
    // 7 = security
    HS_ENERGY = (debug == 1) ? 400 : 60000; //energy
    HS_TORPEDOS = (debug == 1) ? 0 : 100; //torps
    HS_CREDITS = (debug == 1) ? 500 : 1000000000; //monies
    HS_PLASMA = 0;//warp plasma
    HS_DUTERIUM = 0;//duterium
    HS_LATINUM = 0;//latinum
    HS_WATER = 0;//water
    HS_URANIUM = 0;//uranium ore
    // 16, 17, 18 = planets, enemies, stellar objects
    HS_SHIP_TYPE = (debug == 1) ? 1 : 5; //ship class 1-5
    // 20 = enemy location
    HS_WEAPON1 = (debug == 1) ? 1 : 3; //21-25 = weapons (1-3)
    HS_WEAPON2 = (debug == 1) ? 0 : 3;
    HS_WEAPON3 = (debug == 1) ? 0 : 3;
    HS_WEAPON4 = (debug == 1) ? 0 : 3;
    HS_WEAPON5 = (debug == 1) ? 0 : 3;
    HS_WEAPONS = (debug == 1) ? 1 : 5; //total weapons
    HS_UP_DMG = 0;//damage upgrades
    HS_UP_RANGE = 0;//range upgrade
    HS_UP_HULL = 0;//hull upgrade
    HS_UP_SHIELD = 0;//shield upgrade
    HS_UP_CARGO = 0;//cargo upgrade
    HS_UP_TORP = 0;//torpedo upgrade
    HS_UP_ENGINE = 0;//engine upgrade
    // HS_DEPLETION = energy depletion
    // HS_IN_RANGE = guns in range
    HS_PASSENGERS = 0;//passengers
    // shuttle, cargo, freight, frigate, destroyer
    // shields1 = 0, 300, 500, 1000, 10000            1
    // hull2 = 100, 500, 700, 2000, 4000              2
    // energy8 = 0, 1000, 2000, 4000, 30000           3
    // torps9 = 0, 5, 10, 40, 100                     4
    // cargo11-15 = 100, 1000, 3000, 100000, 50000    5
    // ship range = 6-10                          6
    // cannon hardpoints = 16-20                  7
    CAP_CARGO = 100; // cargo
    capacityArray[2] = 1000;
    capacityArray[3] = 5000;
    capacityArray[4] = 10000;
    capacityArray[5] = 100000;
    */
  }

} Player;

