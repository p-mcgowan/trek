void drawWindow(int x, int y, int w, int h) {
  Debug.log("void drawWindow(%d, %d, %d, %d)", x, y, w, h);
  int i;
  char line[BUFFER_MEDIUM];
  memset(line, '-', BUFFER_MEDIUM * sizeof(char));

  gotoXY(x, y);
  printf("+%*.*s+", w - 2, w - 2, line);

  for (i = y + 1; i < y + h - 1; i++) {
    gotoXY(x, i);
    printf("|%*s|", w - 2, " ");
    //printf("%d%*s|", i, w - 2, " ");
  }

  gotoXY(x, y + h - 1);
  printf("+%*.*s+", w - 2, w - 2, line);
}


/**
 * Print a formatted string at x, y.
 * Returns next y coord.
 */
int printAt(int x, int y, const char *fmt, ...) {
  va_list args, dlog;
  va_start(args, fmt);
  if (Debug.logLevel == DEBUG_LOG_ALL) {
    __va_copy(dlog, args);
    char buffer[BUFFER_MEDIUM] = { "printAt: " };
    strcat(buffer, fmt);
    strcat(buffer, "\n");
    vfprintf(stderr, buffer, dlog);
    va_end(dlog);
  }
  gotoXY(x, y);
  vprintf(fmt, args);
  va_end(args);
  return ++y;
}


/**
 * Split a string with newlines print tokens on separate, indented lines.
 * Returns next y coord.
 */
int printLinesAt(int x, int y, const char *str) {
  char buffer[BUFFER_MEDIUM] = {0};
  int i;
  if (Debug.logLevel == DEBUG_LOG_ALL) {
    snprintf(buffer, BUFFER_MEDIUM - 1, "printLinesAt: %s", str);
    Debug.log(buffer);
    memset(buffer, 0, BUFFER_MEDIUM * sizeof(char));
  }
  snprintf(buffer, BUFFER_MEDIUM - 1, "%s", str);

  gotoXY(x, y);
  for (i = 0; i < BUFFER_MEDIUM; i++) {
    if (buffer[i] == '\n') {
      gotoXY(x, ++y);
    } else if (buffer[i] == '\0') {
      break;
    } else {
      printf("%c", buffer[i]);
    }
  }

  return ++y;
}


int printfLinesAt(int x, int y, const char *fmt, ...) {
  va_list args;
  char buffer[BUFFER_MEDIUM] = {0};
  va_start(args, fmt);
  vsnprintf(buffer, BUFFER_MEDIUM - 1, fmt, args);
  printLinesAt(x, y, (const char*)buffer);
  va_end(args);
  return ++y;
}


void printMap(int whichMap, int playerScanning) {
  Debug.log("void printMap(%d, %d)", whichMap, playerScanning);
  int i, j;
  // Reload player and enemies
  findPlayer();
  if (whichMap == MAP_TYPE_SYSTEM) {
    printAt(1, 1, "                System Map");
  } else {
    printAt(1, 1, "                Galaxy Map");
  }
  drawWindow(3, 3, 4 * 10 + 2, 2 * 10 + 1);
  for (i = 0; i < 10; i++) {
    gotoXY(4, 4 + 2 * i);
    printf(" ");
    for (j = 0; j < 10; j++) {
      if (whichMap == MAP_TYPE_GALAXY &&
      (i == 0 || i == 9 || j == 0 || j == 9)) {
        setCB(COL_WHITE, COL_MAGENTA);
      }
      if (whichMap == MAP_TYPE_SYSTEM) {
        printf(" %s ", charColour(currentSystem->map[(i * 10) + j],
        playerScanning, (i * 10) + j));
      /*} else {
        printf(" %s ", charColour(galaxyMap[(i * 10) + j],
        playerScanning, (i * 10) + j));*/
      }
      if (j != 9) {
        printf(" ");
      }
    }
  }
}


char* charColour(int mapTile, int playerScanning, int mapIndex) {
  // Too verbose
  // Debug.log("char* charColour(%d, %d, %d)", mapTile, playerScanning, mapIndex);
  static char out[BUFFER_MEDIUM] = {0};
  static char tile[32] = {0};
  int colourForeground = COL_WHITE;
  int colourBackground = COL_BLACK_BG;

  if (playerScanning != 0 && rangeScan(playerScanning, mapIndex)) {
    colourBackground = COL_CYAN_BG;
    colourForeground = COL_WHITE;
  }
  if (mapTile >= 1 && mapTile <= 5) {
    colourForeground = COL_RED;
    snprintf(tile, 31, "%s", printShip(mapTile));
  }
  if (mapTile >= 6 && mapTile <= 10) {
    colourForeground = COL_GREY;
    snprintf(tile, 31, "%s", printShip(mapTile));
  }
  if (mapTile == TILE_PLANET) {
    colourForeground = COL_GREEN;
    snprintf(tile, 31, "%c", TILE_PLANET);
  }
  if (mapTile == TILE_PLAYER) {
    colourForeground = COL_YELLOW;
    snprintf(tile, 31, "%s", printShip(HS_SHIP_TYPE));
  }
  if (mapTile == TILE_EMPTY) {
    colourForeground = COL_WHITE;
    snprintf(tile, 31, " ");
  }

  // Format and print out colours and tiles
  snprintf(out, BUFFER_MEDIUM - 1, "\033[%d;%dm%s\033[%d;%dm",
  colourForeground, colourBackground, tile, COL_WHITE, COL_BLACK_BG);

  return out;
}


const char* printShip(int ship) {
  Debug.log("const char* printShip(%d)", ship);
  switch (ship) {
    case 0:
      return ".";
    case 1:
    case 6:
      return "1";
    case 2:
    case 7:
      return "2";
    case 3:
    case 8:
      return "3";
    case 4:
    case 9:
      return "4";
    case 5:
    case 10:
      return "5";
    default:
      return "S";
  }
}


void printProgressBar(int skillSlot) {
  Debug.log("void printProgressBar(%d)", skillSlot);
  int i;
  printf("  ");
  for (i = 1; i <= 10; i++) {
    if (skillsArray[skillSlot] % 10 >= i) {
      setCB(COL_WHITE, COL_GREEN);
    } else {
      setCB(COL_WHITE, COL_BLACK);
      printf("  ");
      setCB(COL_WHITE, COL_BLACK);
      printf("|");
    }
  }
}


// TODO
void skillsHUD(int x, int page) {
  Debug.log("void skillsHUD(%d, %d)", x, page);
  int i, j, p = 9;
  gotoXY(x, 2);
  printf(" Skills:");
  gotoXY(x + 48, 2);
  printf("Page %i", page);
  gotoXY(x, 3);
  printf("%s", HUD_LINE);

  for (j = 4; j <= 22; j += 2) {
    gotoXY(x, j);
    printf("  Skill %i", 10 * page - p);
    gotoXY(x, j + 1);
    printProgressBar(10 * page - p);
    printf("\tLevel %i (%i %c)\t", skillsArray[10 * page - p] / 10 + 1,
    (skillsArray[10 * page - p] % 10) * 10, 37);
    p--;
  }

  for (i = 4; i < 32; i++) {
    gotoXY(x, i);
    printf("|");
    gotoXY(x + HUD_WIDTH, i);
    printf("|");
  }
}


void minimalHUD(int startX, int startY) {
  Debug.log("void minimalHUD(%d, %d)", startX, startY);
  //clear old
  gotoXY(startX, startY++);
  clrLine();
  printf("Shields: %s  ",
  hudColours(HS_SHIELD, capacityArray[10 + HS_SHIP_TYPE]));
  printf("Hull: %s  ",
  hudColours(HS_HULL, capacityArray[20 + HS_SHIP_TYPE]));
  printf("Energy: %-10s",
  hudColours(HS_ENERGY, capacityArray[30 + HS_SHIP_TYPE]));
  gotoXY(startX, startY++);
  clrLine();
  printf("Security: %s  Armaments: %s  ",
  securityStatus(), weaponStatus());
  printf("Torpedos: %-10s", hudColours(HS_TORPEDOS,
  capacityArray[40 + HS_SHIP_TYPE]));
  gotoXY(startX, startY++);
  clrLine();
  printf("Enemies: %d  Planets: %d  ISO: %d  Credits: %-10s", HS_ENEMIES,
  HS_PLANETS, HS_STELLAR, prefix(HS_CREDITS, 'n'));
  gotoXY(startX, startY);
  clrLine();
  printf("System: %s  ", getCoords(MAP_TYPE_SYSTEM));
  printf("Galaxy: %-10s", getCoords(MAP_TYPE_GALAXY));
}


char* weaponStatus() {
  Debug.log("static char* weaponStatus()");
  static char buf[BUFFER_MEDIUM] = {0};

  if (HS_SHIP_TYPE == 0) {
    snprintf(buf, BUFFER_MEDIUM - 1, "---");
    return buf;
  } else {
    rangeCheck(SCAN_PLAYER_RANGE, SCAN_TYPE_RANGE);
    if (EN_SHIP_TYPE > 0 && EN_SHIP_TYPE < 6) {
      snprintf(buf, BUFFER_MEDIUM - 1, "%i/%i (%s%i%s in range)", gunCount(),
      capacityArray[5 + HS_SHIP_TYPE], gunRangeColour(gunCount(), HS_IN_RANGE),
      HS_IN_RANGE, STR_COL_WHITE);
    } else {
      snprintf(buf, BUFFER_MEDIUM - 1, "%i/%i", gunCount(),
      capacityArray[5 + HS_SHIP_TYPE]);
    }
  }

  return buf;
}


// Clear, redraw, and set cursor at top left spot
void comLog(int x, int y) {
  Debug.log("void comLog(%d, %d)", x, y);
  drawWindow(x, y, COM_WIDTH, COM_HEIGHT);
  gotoXY(x + 1, y + 1);
}


void HUD(int startX, int startY) {
  Debug.log("void HUD(%d, %d)", startX, startY);
  findPlayer();
  securityStatus();
  startX++;
  gotoXY(startX, startY);
  printf("Helm Console:");
  drawWindow(startX - 1, ++startY, HUD_WIDTH, HUD_HELM_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Stardate           : %i.%i", HS_DATE / 10, HS_DATE % 10);
  gotoXY(startX, ++startY);
  printf(" Ship Class         : %s", shipName(HS_SHIP_TYPE));
  gotoXY(startX, ++startY);
  printf(" System Coordinates : (%i, %i)  ", HS_SYS_X, HS_SYS_Y);
  gotoXY(startX, ++startY);
  printf(" Galaxy Coordinates : (%i, %i)  ", HS_GAL_X, HS_GAL_Y);
  if (HS_GAL_X == 1 || HS_GAL_X == 10 || HS_GAL_Y == 1 || HS_GAL_Y == 10) {
    gotoXY(startX + 22, startY);
    setC(COL_RED);
    printf("%i, %i", HS_GAL_X, HS_GAL_Y);
    setC(COL_WHITE);
    printf(")");
  }

  startY++;
  gotoXY(startX, ++startY);
  printf("Tactical Ship Status:");
  gotoXY(startX, ++startY);
  drawWindow(startX - 1, startY, HUD_WIDTH, HUD_STATUS_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Shields         : %s", hudColours(HS_SHIELD,
  capacityArray[10 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Hull Integrity  : %s", hudColours(HS_HULL,
  capacityArray[20 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Security        : %s", securityStatus());
  gotoXY(startX, ++startY);
  printf(" Energy Reserves : %s", hudColours(HS_ENERGY,
  capacityArray[30 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Torpedos        : %s", hudColours(HS_TORPEDOS,
  capacityArray[40 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Armaments       : %s", weaponStatus());

  startY++;
  gotoXY(startX, ++startY);
  printf("Cargo: ");
  if (HS_SHIP_TYPE == 0) {
    printf("---");
  } else {
    printf("(%i/%i units)",
    HS_PLASMA + HS_DUTERIUM + HS_LATINUM + HS_WATER + HS_URANIUM,
    capacityArray[HS_SHIP_TYPE] + 100 * HS_UP_CARGO);
  }
  gotoXY(startX, ++startY);
  drawWindow(startX - 1, startY, HUD_WIDTH, HUD_CARGO_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Credits     : %s", prefix(HS_CREDITS, 'n'));
  gotoXY(startX, ++startY);
  if (HS_SHIP_TYPE != SHIP_ESCAPE_POD) {
    printf(" Warp Plasma : %s", prefix(HS_PLASMA, 'L'));
    gotoXY(startX, ++startY);
    printf(" Duterium    : %s", prefix(HS_DUTERIUM, 'g'));
    gotoXY(startX, ++startY);
    printf(" Latinum     : %s", prefix(HS_LATINUM, 'g'));
    gotoXY(startX, ++startY);
    printf(" Water       : %s", prefix(HS_WATER, 'L'));
    gotoXY(startX, ++startY);
    printf(" Uranium Ore : %s", prefix(HS_URANIUM, 'g'));
  } else {
    printf(" Warp Plasma : ---");
    gotoXY(startX, ++startY);
    printf(" Duterium    : ---");
    gotoXY(startX, ++startY);
    printf(" Latinum     : ---");
    gotoXY(startX, ++startY);
    printf(" Water       : ---");
    gotoXY(startX, ++startY);
    printf(" Uranium Ore : ---");
  }
  ++startY;

  gotoXY(startX, ++startY);
  printf("System Peripherals:");
  drawWindow(startX - 1, ++startY, HUD_WIDTH, HUD_SYSTEM_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Planets: %i ", HS_PLANETS);
  gotoXY(startX, ++startY);
  printf(" Enemies: %i", HS_ENEMIES);
  gotoXY(startX, ++startY);
  printf(" Inactive Stellar Objects: %i  ", HS_STELLAR);
}


const char* gunRangeColour(int totalGuns, int gunsInRange) {
  Debug.log("const char* gunRangeColour(%d, %d)", totalGuns, gunsInRange);
  if (gunsInRange == 0) {
    // red no guns in range
    return STR_COL_RED;
  } else if (gunsInRange == totalGuns) {
    // green, all guns in range
    return STR_COL_GREEN;
  }
  // yellow, not all guns in range
  return STR_COL_YELLOW;
}


// 3, 5, 9
char* hudColours(int currentHud, int maxHud) {
  Debug.log("static char* hudColours(%d, %d)", currentHud, maxHud);
  const char *fmt = "%s%i"STR_COL_WHITE"/%i";
  static char msg[BUFFER_MEDIUM] = {0};

  if (HS_SHIP_TYPE == SHIP_ESCAPE_POD) {
    return (char*)"---";
  }

  if (maxHud != 0) {
    int percent = currentHud * 100 / maxHud;
    if (percent == 100) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_WHITE, currentHud, maxHud);
    } else if (percent > 75) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_GREEN, currentHud, maxHud);
    } else if (percent > 50) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_YELLOW, currentHud, maxHud);
    } else {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_RED, currentHud, maxHud);
    }
  } else {
    snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_WHITE, currentHud, maxHud);
  }

  return msg;
}


void achievementsMenu() {
  Debug.log("void achievementsMenu()");
  int page = 1, choice, slot, value;
  do {
    //planetHUD(); // dis = 0, 1 = syst, 2 = plan, 3 = ships, 4 = weps, 5 = kills
    if (page == 1) {
      gotoXY(3, 5);
      printf("Basic Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 20) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("The Traveler");
      printf("\t\t%i/20 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 10) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Discoverer");
      printf("\t\t\t%i/10 systems visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 15) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Land Harr");
      printf("\t\t\t%i/15 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 2) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Able Captain");
      printf("\t\t%i/2 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 5) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Rifleman");
      printf("\t\t\t%i/5 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 10) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Brute");
      printf("\t\t\t%i/10 enemies killed", ACHIEVE_KILLS);
    }
    if (page == 2) {
      gotoXY(3, 5);
      printf("Intermediate Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Well Travelled");
      printf("\t\t%i/50 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 25) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Explorer");
      printf("\t\t\t%i/25 systems visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 35) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Sphere Hunter");
      printf("\t\t%i/35 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 4) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Admiral");
      printf("\t\t\t%i/4 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 15) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Arms Dealer");
      printf("\t\t%i/15 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 25) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Soldier");
      printf("\t\t\t%i/25 enemiies killed", ACHIEVE_KILLS);
    }
    if (page == 3) {
      gotoXY(3, 5);
      printf("Advanced Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 150) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Not Lost In Space");
      printf("\t\t%i/150 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Found Your Hemingway");
      printf("\t%i/50 system visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 75) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Diplomat");
      printf("\t\t\t%i/75 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 5) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Enshiplopedia");
      printf("\t\t%i/5 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 30) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Gun Fettish");
      printf("\t\t%i/30 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Warren Piece");
      printf("\t\t%i/50 enemies killed", ACHIEVE_KILLS);
// silver tounge
    }
    setC(COL_WHITE);
    gotoXY(3, 27);
    if (page == 1) {
      printf("0: Back\t\t2: Next");
    } else if (page == 3) {
      printf("1: Previous\t\t0: Back");
    } else {
      printf("1: Previous\t\t0: Back\t\t2: Next");
    }
    gotoXY(3, 29);
    printf("5: achievements[x] = y");
    gotoXY(3, 30);
    choice = getch_arrow() - '0';
    comLog(COM_BELOW_MAP); //66
    if (choice == 5) {
      gotoXY(3, 28);
      printf("achievements[");
      scanf("%i", &slot);
      if (slot > 9) {
        gotoXY(18, 28) ;
      } else {
        gotoXY(17, 28);
      }
      printf("] = ");
      scanf("%i", &value);
      if (slot > 50 || value > 200) {
        gotoXY(67, 27);
        printf("Invalid slot/value");
      } else {
        achievements[slot] = value;
      }
    }
    if (choice == 1) {
      if (page == 1) {
        printf("Cannot go back a page");
      } else {
        page--;
      }
    }
    if (choice == 2) {
      if (page == 3) {
        printf("Cannot go forward a page");
      } else {
        page++;
      }
    }
    if (choice != 1 && choice != 2 && choice != 0 && choice != 5) {
      printf("Invalid selection");
    }
  } while (choice != 0);
}

