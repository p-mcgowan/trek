#define OPTION_LENGTH 128
/**
 * Selectable menu class
 */
typedef struct Menu {
  int length;
  int highlighted;
  int x;
  int y;
  char **options;
  int *indices;


  ~Menu() {
    destruct();
  }


  void destruct() {
    Debug.log("void Menu::destruct()");
    int i;
    for (i = 0; i < length; ++i) {
      free(options[i]);
    }
    if (length > 0) {
      free(options);
      free(indices);
    }
    length = 0;
    highlighted = -1;
  }


  // Allow forward declarations
  Menu() {
    Debug.log("Menu::Menu()");
    x = 1;
    y = 1;
    length = 0;
    highlighted = -1;
  }


  Menu(int sx, int sy) {
    Debug.log("Menu::Menu(%d, %d)", sx, sy);
    x = sx;
    y = sy;
    length = 0;
    highlighted = -1;
  }

  static Menu *newMenu(int sx, int sy) {
    Debug.log("static Menu* Menu::newMenu(%d, %d)", sx, sy);
    Menu *m = (Menu*)malloc(sizeof(Menu));
    m->x = sx;
    m->y = sy;
    m->length = 0;
    m->highlighted = -1;
    return m;
  }


  static Menu *load(FILE *fp) {
    Debug.log("static Menu* Menu::load(%d)", fp);
    Menu *m = newMenu(0, 0);
    Debug.write("  this, ");
    fread(m, sizeof(Menu), 1, fp);
    Debug.write("length, ");
    fread(&(m->length), sizeof(int), 1, fp);
    m->options = (char**)malloc(m->length * sizeof(char*));
    m->indices = (int*)malloc(m->length * sizeof(int));
    int i;
    for (i = 0; i < m->length; i++) {
      m->options[i] = (char*)malloc(OPTION_LENGTH * sizeof(char));
      Debug.write("opt[i], ");
      fread(m->options[i], OPTION_LENGTH, 1, fp);
      Debug.write("&ind[i], ");
      fread(&(m->indices[i]), sizeof(int), 1, fp);
    }
    Debug.write("\n");
    return m;
  }

  int save(FILE *fp) {
    Debug.log("int Menu::save(%d)", fp);
    Debug.write("  this, ");
    fwrite(this, sizeof(Menu), 1, fp);
    Debug.write("length, ");
    fwrite(&length, sizeof(int), 1, fp);
    int i;
    for (i = 0; i < length; i++) {
      Debug.write("opt[i], ");
      fwrite(options[i], OPTION_LENGTH, 1, fp);
      Debug.write("&ind[i], ");
      fwrite(&indices[i], sizeof(int), 1, fp);
    }
    Debug.write("\n");

    return 1;
  }

  static void unload(Menu *m) {
    Debug.log("static void Menu::unload(%d)", m);
    if (m == NULL) {
      return;
    }
    int i;
    for (i = 0; i < m->length; i++) {
      Debug.log("freeing m->options[%d] %s", m->options[i]);
      free(m->options[i]);
    }

    Debug.log("freeing %d m->options and m->indices", m->length);
    if (m->length > 0) {
      Debug.log("freeing m->options %d", m->options);
      free(m->options);
      Debug.log("freeing m->indices %d", m->indices);
      free(m->indices);
    }
    Debug.log("freeing m");
    free(m);
    return;
  }


  int addOption(const char *format, ...) {
    char buffer[1024] = {0};
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, BUFFER_MEDIUM, format, args);
    va_end(args);

    return addOption(buffer);
  }


  int addOption(char *i) {
    if (length == 0) {
      options = (char**)malloc(sizeof(char*));
      indices = (int*)malloc(sizeof(int));
    } else {
      options = (char**)realloc(options, (length + 1) * sizeof(char*));
      indices = (int*)realloc(indices, (length + 1 ) * sizeof(int));
    }

    options[length] = (char*)malloc(OPTION_LENGTH * sizeof(char));
    strcpy(options[length], i);
    length++;
    return length;
  }


  int isHighlighted(const char *searchStr) {
    return (strstr(options[highlighted], searchStr) != NULL);
  }

  int optionIndex(const char *searchStr) {
    int i;
    for (i = 0; i < length; ++i) {
      if (strstr(options[i], searchStr) != NULL) {
        return i;
      }
    }

    return -1;
  }

  int getSelection() {
    int choice = -1;
    while (choice == -1) {
      choice = getInput();
    }
    return choice;
  }

  int getInput() {
    int i, choice = -1;

    if (highlighted < 0 || highlighted >= length) {
      highlighted = 0;
    }

    for (i = 0; i < length; i++) {
      gotoXY(x, y + i);
      if (i == highlighted) {
        setCB(COL_BLACK, COL_WHITE);
      } else {
        setCB(COL_WHITE, COL_BLACK);
      }
      printf("%s", options[i]);
      setCB(COL_WHITE, COL_BLACK);
    }

    choice = getch_arrow();
    Debug.log("\n\nmenu choice: %c", choice);
    if (choice == KEY_UP || choice == KEY_WARP_UP) {
      highlighted = (highlighted + length - 1) % length;
      return -1;
    } else if (choice == KEY_DOWN || choice == KEY_WARP_DOWN) {
      highlighted = (highlighted + 1) % length;
      return -1;
    } else if (choice == KEY_RETURN) {
      return KEY_RETURN;
    } else if (choice - '0' >= 0 && choice - '0' <= length - 1) {
      highlighted = choice - '0';
      return highlighted;
    } else if (choice == KEY_HELP) {
      return KEY_HELP;
    }

    return -1;
  }

} Menu;

