#define BUFFER_MEDIUM 1024

#define MAP_TYPE_SYSTEM 1
#define MAP_TYPE_GALAXY 2

#define HUD_LINE          "+--------------------------------------------------+"
#define HUD_WIDTH         51
#define HUD_HELM_HEIGHT   6
#define HUD_STATUS_HEIGHT 8
#define HUD_CARGO_HEIGHT  8
#define HUD_SYSTEM_HEIGHT 5
#define HUD_COM_HEIGHT    5

#define COM_WIDTH                  60
#define COM_HEIGHT                 5
#define COM_BELOW_MAP              1, 30
#define COM_BELOW_MAP_START        2, 31
#define COM_BELOW_PLANET_HUD       1, 30
#define COM_BELOW_PLANET_HUD_START 2, 31
#define HUD_MINIMAL_START          2, 25
#define PLANET_MENU_HEADER         3, 3
#define PLANET_MENU_START          3, 5

#define KEY_ENEMY_MOVE   'E'
#define KEY_SKILLS_ARRAY 'S'
#define KEY_TAKE_DMG     'T'
#define KEY_HUDSTAT      'H'
#define KEY_SCANS        'l'
#define KEY_TORPEDO      'u'
#define KEY_STATS        'p'
#define KEY_SKILLS       'k'
#define KEY_RANGE        'r'
#define KEY_SCAN         'n'
#define KEY_ATTACK       't'
#define KEY_DIVERT       'o'
#define KEY_WARP_UP      'w'
#define KEY_WARP_LEFT    'a'
#define KEY_WARP_RIGHT   'd'
#define KEY_WARP_DOWN    's'
#define KEY_UP           65
#define KEY_DOWN         66
#define KEY_RIGHT        67
#define KEY_LEFT         68
#define KEY_RETURN       10
#define KEY_HELP         '?'

#define KEY_DEBUG ':'
#define KEY_TEST  ';'

#define EN_I_POS       0
#define EN_I_SHIP_TYPE 1
#define EN_I_TILE      2
#define EN_I_WEAPON1   3
#define EN_I_WEAPON2   4
#define EN_I_WEAPON3   5
#define EN_I_WEAPON4   6
#define EN_I_WEAPON5   7
#define EN_I_SHIELD    8
#define EN_I_HULL      9
#define EN_I_SIZE      10


#define TILE_EMPTY     0
#define TILE_ENEMY1    1
#define TILE_ENEMY2    2
#define TILE_ENEMY3    3
#define TILE_ENEMY4    4
#define TILE_ENEMY5    5
#define TILE_DERELICT1 6
#define TILE_DERELICT2 7
#define TILE_DERELICT3 8
#define TILE_DERELICT4 9
#define TILE_DERELICT5 10
#define TILE_PLANET    'O'
#define TILE_PLAYER    'P'

#define SECURITY_SAFE    1
#define SECURITY_UNSAFE  2
#define SECURITY_INRANGE 3

#define SCAN_TYPE_NONE      0
#define SCAN_TYPE_RANGE     1
#define SCAN_TYPE_DEPLETION 2
#define SCAN_PLAYER_RANGE   1
#define SCAN_ENEMY_RANGE    2

#define CAP_CARGO       capacityArray[1]
#define CAP_HARDPOINT   capacityArray[6]
#define CAP_SHIELD      capacityArray[11]
#define CAP_HULL        capacityArray[21]
#define CAP_ENERGY      capacityArray[31]
#define CAP_TORP        capacityArray[41]
#define CAP_AVGPLASMA   capacityArray[46]
#define CAP_AVGDUTERIUM capacityArray[47]
#define CAP_AVGLATINUM  capacityArray[48]
#define CAP_AVGWATER    capacityArray[49]
#define CAP_AVGURANIUM  capacityArray[50]

#define CAP_I_CARGO       0
#define CAP_I_HARDPOINT   5
#define CAP_I_SHIELD      10
#define CAP_I_HULL        20
#define CAP_I_ENERGY      30
#define CAP_I_TORP        40
#define CAP_I_AVGPLASMA   46
#define CAP_I_AVGDUTERIUM 47
#define CAP_I_AVGLATINUM  48
#define CAP_I_AVGWATER    49
#define CAP_I_AVGURANIUM  50
#define CAP_I_SIZE        100

#define LASTBUY_PLASMA   commodityLastBuy[0]
#define LASTBUY_DUTERIUM commodityLastBuy[1]
#define LASTBUY_LATINUM  commodityLastBuy[2]
#define LASTBUY_WATER    commodityLastBuy[3]
#define LASTBUY_URANIUM  commodityLastBuy[4]
#define LASTBUY_I_SIZE   5


#define SHIP_ESCAPE_POD 0

#define SKILLS_I_SIZE 50

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <stdarg.h>  // va_arg
#include <dirent.h>  // directory

//int hudstats[100],
int capacityArray[CAP_I_SIZE],
commodityLastBuy[LASTBUY_I_SIZE], achievements[50], skillsArray[SKILLS_I_SIZE];
unsigned int lastSeed;


#include "getch.h" // getch (conio.h, unistd.h)
#include "con_c_nix.h"
#include "externs.h"
#include "libs.h"
#include "menu.h"
#include "upgrades.h"

#include "player.h"
Player *currentPlayer;

#include "planet.h"
#include "system.h"
//#include "sector.h"
System *currentSystem;

#include "drawable.h"
#include "utils.h"
