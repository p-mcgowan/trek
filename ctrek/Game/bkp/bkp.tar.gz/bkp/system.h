#define SYSTEM_SIZE 100
#define PLANET_MAX 3
#define EN_POS         currentSystem->enemy[0]
#define EN_SHIP_TYPE   currentSystem->enemy[1]
#define EN_TILE        currentSystem->enemy[2]
#define EN_WEAPON1     currentSystem->enemy[3]
#define EN_WEAPON2     currentSystem->enemy[4]
#define EN_WEAPON3     currentSystem->enemy[5]
#define EN_WEAPON4     currentSystem->enemy[6]
#define EN_WEAPON5     currentSystem->enemy[7]
#define EN_SHIELD      currentSystem->enemy[8]
#define EN_HULL        currentSystem->enemy[9]

#define HS_ENEMIES     currentSystem->enemy[1] != 0
#define HS_STELLAR     currentSystem->stellarObjects
#define HS_PLANETS     currentSystem->nPlanets

typedef struct System {
  Planet *planets[PLANET_MAX];
  int nPlanets;
  int map[SYSTEM_SIZE];
  int enemy[100];
  int initialized;
  int galaxyX;
  int galaxyY;
  int stellarObjects;

  static System *newSystem(int x, int y) {
    Debug.log("static System* System::System(%d, %d)", x, y);
    System *s = (System*)malloc(sizeof(System));
    s->galaxyX = x;
    s->galaxyY = y;
    s->nPlanets = 0;
    memset(s->map, 0, SYSTEM_SIZE * sizeof(int));
    memset(s->enemy, 0, SYSTEM_SIZE * sizeof(int));

    s->initialized = 0;

    return s;
  }

  void startingSystem() {
    Debug.log("void System::startingSystem()");
    stellarObjects = randomNumber(10);

    map[45] = TILE_PLAYER;
    map[35] = TILE_PLANET;

    nPlanets = 1;
    planets[0] = Planet::newPlanet(35);

    initialized = 1;
  }

  void initialize() {
    Debug.log("void System::initialize()");

    stellarObjects = randomNumber(10);

    if (initialized) {
      return;
    }

    int i, derelictLocation;
    int playerPos = playerCoord();
    if (playerPos != -1) {
      map[playerPos] = TILE_PLAYER;
    }

    initEnemy(0);

    int chance = percentile();
    if (chance > 50) {
      nPlanets = Math.min((chance - 30) / 20, PLANET_MAX);
    }
    for (i = 0; i < nPlanets; i++) {
      int placePlanet = randomNumber(100);
      while (map[placePlanet] != 0) {
        placePlanet = randomNumber(100);
      }
      map[placePlanet] = TILE_PLANET;
      planets[i] = Planet::newPlanet(placePlanet);
    }
    chance = percentile();
    int xyEdge = (HS_GAL_X == 1 || HS_GAL_X == 10 || HS_GAL_Y == 1 ||
    HS_GAL_Y == 10)? 1 : 0;
    if ((xyEdge && chance > 30) || chance > 75) {
      spawnEnemy(xyEdge);
    }

    chance = percentile();
    if (chance > 90 && enemy[EN_I_SHIP_TYPE] == 0) {
      derelictLocation = randomNumber(99);
      while (map[derelictLocation] != 0) {
        derelictLocation = randomNumber(100);
      }
      enemy[EN_I_POS] = derelictLocation;
      map[derelictLocation] = 6 + randomNumber(4);
      enemy[EN_I_SHIP_TYPE] = map[derelictLocation];
      enemy[EN_I_TILE] = 0;
    }

    HS_DATE += 1 + randomNumber(9);
    initialized = 1;
  }


  Planet *getPlanet(int pos) {
    Debug.log("Planet System::getPlanet(%d)", pos);
    int i;
    Planet *p = NULL;
    for (i = 0; i < nPlanets; ++i) {
      if (planets[i]->position == pos) {
        p = planets[i];
      }
    }
    if (p == NULL) {
      Debug.log("Error: did not find planet at %d", pos);
    }

    return p;
  }

  int save() {
    Debug.log("int System::save()");
    FILE *fp;
    char path[128] = {0};

    snprintf(path, 128, "sectors/%d_%d.trek", galaxyX, galaxyY);

    fp = fopen(path, "wb");
    if (fp == NULL) {
      Debug.log("System::save() Error writing to file %s", path);
      return -1;
    }
    fwrite(this, sizeof(System), 1, fp);
    fwrite(map, SYSTEM_SIZE * sizeof(int), 1, fp);
    fwrite(enemy, SYSTEM_SIZE * sizeof(int), 1, fp);
    fwrite(&nPlanets, sizeof(int), 1, fp);
    int i;
    for (i = 0; i < nPlanets; i++) {
      planets[i]->save(fp);
    }
    fclose(fp);

    return 1;
  }

  static System *load(int x, int y) {
    Debug.log("System* System::load(%d, %d)", x, y);
    FILE *fp;
    System *s;
    char path[128] = {0};

    snprintf(path, 128, "sectors/%d_%d.trek", x, y);
    fp = fopen(path, "rb");
    if (fp == NULL) {
      Debug.log("System::load() could not find %s", path);
      return NULL;
    } else {
      s = System::newSystem(x, y);
      fread(s, sizeof(System), 1, fp);
      fread(s->map, SYSTEM_SIZE * sizeof(int), 1, fp);
      fread(s->enemy, SYSTEM_SIZE * sizeof(int), 1, fp);
      fread(&(s->nPlanets), sizeof(int), 1, fp);
      int i;
      for (i = 0; i < s->nPlanets; i++) {
        s->planets[i] = Planet::load(fp);
      }
      fclose(fp);
      return s;
    }
  }

  static void unload(System *s) {
    Debug.log("static void System::unload(%d)", s);
    if (s == NULL) {
      return;
    }
    int i;
    for (i = 0; i < s->nPlanets; i++) {
      Planet::unload(s->planets[i]);
    }

    free(s);
    return;
  }

} System;

