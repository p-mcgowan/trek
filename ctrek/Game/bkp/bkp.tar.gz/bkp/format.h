#include "cTrekGame.h"

//#define RANDMAX 65535
char systemMap[100], galaxyMap[100];
int hudstats[100], commerceArray[100], outfitArray[100],
shipArray[100], capacityArray[CAP_I_SIZE], enemyArray[10],
commodityLastBuy[LASTBUY_I_SIZE], achievements[50], skillsArray[SKILLS_I_SIZE];
unsigned int lastSeed;

/** TODO
 * - on enter planet, switch hud option
 */


/**
 * Print a formatted string at x, y.
 * Returns next y coord.
 */
int printAt(int x, int y, const char *fmt, ...) {
  va_list args, dlog;
  va_start(args, fmt);
  if (Debug.logLevel == DEBUG_LOG_ALL) {
    __va_copy(dlog, args);
    char buffer[BUFFER_MEDIUM] = { "printAt: " };
    strcat(buffer, fmt);
    strcat(buffer, "\n");
    vfprintf(stderr, buffer, dlog);
    va_end(dlog);
  }
  gotoXY(x, y);
  vprintf(fmt, args);
  va_end(args);
  return ++y;
}



int printfLinesAt(int x, int y, const char *fmt, ...) {
  va_list args;
  char buffer[BUFFER_MEDIUM] = {0};
  va_start(args, fmt);
  vsnprintf(buffer, BUFFER_MEDIUM - 1, fmt, args);
  printLinesAt(x, y, (const char*)buffer);
  va_end(args);
  return ++y;
}


/**
 * Split a string with newlines print tokens on separate, indented lines.
 * Returns next y coord.
 */
int printLinesAt(int x, int y, const char *str) {
  char buffer[BUFFER_MEDIUM] = {0};
  int i;
  if (Debug.logLevel == DEBUG_LOG_ALL) {
    snprintf(buffer, BUFFER_MEDIUM - 1, "printLinesAt: %s", str);
    Debug.log(buffer);
    memset(buffer, BUFFER_MEDIUM, 0);
  }
  snprintf(buffer, BUFFER_MEDIUM - 1, "%s", str);

  gotoXY(x, y);
  for (i = 0; i < BUFFER_MEDIUM; i++) {
    if (buffer[i] == '\n') {
      gotoXY(x, ++y);
    } else if (buffer[i] == '\0') {
      break;
    } else {
      printf("%c", buffer[i]);
    }
  }

  return ++y;
}

/**
 * Map hudstats to capacityArray.
 * Returns capacity of hudstat, or -1 if not found.
 */
int hudstatToCapacity(int hudstat) {
  Debug.log("int hudstatToCapacity(%d)", hudstat);
  switch(hudstat) {
    case HS_I_SHIELD:
       return capacityArray[CAP_I_SHIELD + HS_SHIP_TYPE];
    case HS_I_HULL:
       return capacityArray[CAP_I_HULL + HS_SHIP_TYPE];
    case HS_I_ENERGY:
       return capacityArray[CAP_I_ENERGY + HS_SHIP_TYPE];
    case HS_I_TORPEDOS:
       return capacityArray[CAP_I_TORP + HS_SHIP_TYPE];
    case HS_I_PLASMA:
    case HS_I_DUTERIUM:
    case HS_I_LATINUM:
    case HS_I_WATER:
    case HS_I_URANIUM:
       return capacityArray[CAP_I_CARGO + HS_SHIP_TYPE] + HS_UP_CARGO;
    case HS_I_WEAPONS:
       return capacityArray[CAP_I_HARDPOINT + HS_SHIP_TYPE];
    default:
      return -1;
  }
}


/**
 * Map commodities to strings
 */
const char *hudstatToCommodity(int hudstat) {
  Debug.log("const char *hudstatToCommodity(%d)", hudstat);
  switch(hudstat) {
    case HS_I_PLASMA:
      return "Warp plasma";
    case HS_I_DUTERIUM:
      return "Duterium";
    case HS_I_LATINUM:
      return "Latinum";
    case HS_I_WATER:
      return "Water";
    case HS_I_URANIUM:
      return "Uranium ore";
    default:
      return "";
  }
}


void test() {
  Debug.log("void test()");
  int derelictLocation = 47;
  EN_POS = derelictLocation;
  systemMap[derelictLocation] = 6 + randomNumber(4);
  EN_SHIP_TYPE = systemMap[derelictLocation];
  EN_TILE = 0;
  printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
}


int main() {
  Debug.init("debug.log", DEBUG_LOG_MEDIUM);

  while (1) {
    clrsCB(15, 0);
    //int i;for(i = 0;i < 124;i++) {printf("%d %c\n", i, i);}
    //return 0;
    int debug = preGameMenu();
    if (debug == 0) {
      return 0;
    }
    initialize(3);
    initStats(debug);
    systemMap[45] = 'P';
    galaxyMap[45] = 'P';
    systemMap[35] = 'O';
    findPlayer();
    securityStatus();
    choiceMenu(debug);
  }
  return 0;
}


void hitAnim(int playerHit) { // hs3, 4
  if (playerHit == 1) {

  } else {

  }
}


int preGameMenu() {
  char choice = '5', debug = 1;
  while (choice != '0' && choice != '1') {
    printf("Choose an option:\n");
    printf("1: Play Game\n");
    printf("2: Toggle Debug (");
    if (debug == 1) {
      printf("OFF)\n");
    } else {
      printf("ON) \n");
    }
    printf("0: Quit\n");
    choice = getch();
    if (choice == '2') {
      debug *= -1;
    }
    clrs();
  }
  if (choice != '0') {
    return debug;
  } else {
    return 0;
  }
}


void seed() {
  if ((unsigned int)clock() != lastSeed) {
    srand(clock());
    lastSeed = clock();
  }
}


int randomNumber(int max) {
  seed();
  return ((float)rand() / (float)RAND_MAX) * max;
}


void help() {
  Debug.log("void help()");
  clrs();
  gotoXY(1, 1);
  printf(
  "Controls:\n"
  "----------\n"
  "Use wasd or arrow keys to move\n"
  "%c - Toggle between long and short range scans (maps).\n"
  "%c - Try to fire torpedos.\n"
  "%c - Ship Status\n"
  "%c - Skills\n"
  "%c - Range Check\n"
  "%c - Scan Enemy\n"
  "%c - Attack\n"
  "%c - Divert Power\n"
  "\n"
  "Debugging - \n"
  "----------\n"
  "%c - Enemy Move\n"
  "%c - SkillsArray[x] = y\n"
  "%c - Take Damage\n"
  "%c - hudstat[x] = y\n"
  "%c - Toggle debug\n"
  "\n"
  "Press any key to go back",

  KEY_SCANS,
  KEY_TORPEDO,
  KEY_STATS,
  KEY_SKILLS,
  KEY_RANGE,
  KEY_SCAN,
  KEY_ATTACK,
  KEY_DIVERT,
  // wasd
  KEY_ENEMY_MOVE,
  KEY_SKILLS_ARRAY,
  KEY_TAKE_DMG,
  KEY_HUDSTAT,
  KEY_DEBUG);
}


void choiceMenu(int debug) {  // debug on right
  Debug.log("void choiceMenu(%d)", debug);
  int scans = 1 , hudstat, value;
  char choice, exit;
  printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
  minimalHUD(HUD_MINIMAL_START);
  comLog(COM_BELOW_MAP);

  do {
    minimalHUD(HUD_MINIMAL_START);
    choice = getch();
    Debug.log("\n\nchoice: %d", choice);
    if (debug) {
      switch (choice) {
      case KEY_ENEMY_MOVE:
        if (HS_SECURITY != 1) {
          enemyMovement();
          printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
        }
        continue;
        break;
      case KEY_SKILLS_ARRAY:
        comLog(COM_BELOW_MAP); //51
        printf("skillsArray[");
        scanf("%i", &hudstat);
        clean();
        printf("] = ");
        scanf("%i", &value);
        clean();
        if (hudstat > 0 && hudstat <= 50) {
          (skillsArray[hudstat] = value);
        } else {
          comLog(COM_BELOW_MAP); //51
          printf("Invalid skill array '%d'.", hudstat);
        }
        continue;
        break;
      case KEY_TAKE_DMG:
        comLog(COM_BELOW_MAP); //51
        fire(2);
        printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
        continue;
        break;
      case KEY_HUDSTAT:
        comLog(COM_BELOW_MAP); //51
        printf("hudstat: ");
        scanf("%i", &hudstat);
        clean();
        printf("|value: ");
        scanf("%i", &value);
        clean();
        if (hudstat >= HS_I_DATE && hudstat < HS_I_SIZE) {
          hudstats[hudstat] = value;
          comLog(COM_BELOW_MAP); //51
          } else {
          comLog(COM_BELOW_MAP); //51
          printf("Invalid hudstat.");
        }
        if (hudstat == 19) {
          printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
        }
        continue;
        break;
        case KEY_TEST:
          test();
        continue;
        break;
      }
    }
    switch (choice) {
    case KEY_UP:
    case KEY_WARP_UP:
    case KEY_RIGHT:
    case KEY_WARP_RIGHT:
    case KEY_DOWN:
    case KEY_WARP_DOWN:
    case KEY_LEFT:
    case KEY_WARP_LEFT:
      scans = 1;
      move(choice);
      printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      minimalHUD(HUD_MINIMAL_START);
      break;
    case KEY_STATS:
      clrs();
      HUD(1, 1);
      getch();
      clrs();
      printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      break;
    case KEY_SCANS:
      if (scans == 1) {
        printMap(MAP_TYPE_GALAXY, SCAN_TYPE_NONE);
      } else {
        printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      }
      scans *= -1;
      break;
    case KEY_TORPEDO:
      if (HS_SECURITY != 1) {
        firetorpedo();
      } else {
        comLog(COM_BELOW_MAP);
        printf("No enemies nearby; firing torpedos unadvisable.");
      }
      printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      break;
    case KEY_SKILLS:
      skillsArray[0] = (skillsArray[0] != 5) ? skillsArray[0] + 1 : 0;
      break;
    case KEY_RANGE:
      scan(SCAN_ENEMY_RANGE, HS_SHIP_TYPE, SCAN_TYPE_RANGE);
      break;
    case KEY_SCAN:
      scan(SCAN_PLAYER_RANGE, HS_SHIP_TYPE, SCAN_TYPE_RANGE);
      break;
    case KEY_ATTACK:
      scan(1, HS_SHIP_TYPE, 0);
      fire(1);
      printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      break;
    case KEY_DIVERT:
      comLog(COM_BELOW_MAP);
      printf("Ammount to divert to shields:");
      scanf("%i", &value);
      clean();
      gotoXY(1, 32);
      printf("                        ");
      if (HS_ENERGY == 0) {
        comLog(COM_BELOW_MAP);
        printf("Power not available.");
      } else {
        divertPower(value);
      }
      break;
    case KEY_DEBUG:
      debug *= -1;
      break;
    case KEY_HELP:
      clrs();
      help();
      getch();
      clrs();
      printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
      comLog(COM_BELOW_MAP);
      minimalHUD(HUD_MINIMAL_START);
      break;
    default:
      if (choice != '0') {
        comLog(COM_BELOW_MAP); //52
        printf("Input invalid, please enter again.");
      }
      break;
    }
    minimalHUD(HUD_MINIMAL_START);
  } while (choice != '0');

  comLog(COM_BELOW_MAP); //52
  printf("Are you sure you want to end the program?");
  exit = getch();
  exit = toupper(exit);
  if (exit != 'Y') {
    choiceMenu(debug);
  }
  return;
}


int percentile() {
  return randomNumber(100);
}

int playerCoord() {
  Debug.log("int playerCoord()");
  if (HS_SYS_X != -1 && HS_SYS_Y != -1) {
    return HS_SYS_X - 1 + (HS_SYS_Y - 1) * 10;
  }
  return -1;
}


void initialize(int whichArray) {
  Debug.log("void initialize(%d)", whichArray);
  int player = playerCoord();

  if (whichArray == 1) {
    memset(systemMap, 0, 100);
    if (player != -1) {
      systemMap[player] = TILE_PLAYER;
    }
  } else if (whichArray == 3) {
    memset(hudstats, 0, HS_I_SIZE);
    memset(galaxyMap, 0, 100);
    memset(systemMap, 0, 100);
    memset(achievements, 0, 50);
    memset(skillsArray, 0, 50);
    ACHIEVE_SYSTEMS = 1;
    ACHIEVE_SHIPS = 1;
    ACHIEVE_WEAPONS = 1; //initialize systems visited
  }
}


/**
 * Returns topmost map tile
 */
int getMapTile(int coord, int mapType) {
  Debug.log("int getMapTile(%d, %d)", coord, mapType);
  if (mapType == MAP_TYPE_SYSTEM) {
    return systemMap[coord];
  } else if (mapType == MAP_TYPE_GALAXY) {
    return galaxyMap[coord];
  }
  return -1;
}


/**
 * Returns true if there is an enemy tile at <coords>
 */
int enemyAtTile(int coord) {
  Debug.log("int enemyAtTile(%d)", coord);
  if (coord > 99 || coord < 0) {
    return 0;
  }
  int tile = getMapTile(coord, MAP_TYPE_SYSTEM);
  return (tile >= TILE_ENEMY1 && tile <= TILE_ENEMY5);
}


/**
 * Returns true if there is derelict tile at <coords>
 */
int derelictAtTile(int coord) {
  Debug.log("int derelictAtTile(%d)", coord);
  int tile = getMapTile(coord, MAP_TYPE_SYSTEM);
  return (tile >= TILE_DERELICT1 && tile <= TILE_DERELICT5);
}


void move(char toWhere) { // move to com log
  Debug.log("void move(%c)", toWhere);
  int systemPos, galaxyPos;
  int systemEdge, galaxyEdge;
  int nextSystemIndex, systemWrap;
  comLog(COM_BELOW_MAP); //51

  //findPlayer();
  //securityStatus();

  systemPos = (HS_SYS_Y - 1) * 10 + (HS_SYS_X - 1);
  galaxyPos = (HS_GAL_Y - 1) * 10 + (HS_GAL_X - 1);

  switch(toWhere) {
  case KEY_UP:
  case KEY_WARP_UP:
    systemEdge = (HS_SYS_Y == 1);
    galaxyEdge = (HS_GAL_Y == 1);
    nextSystemIndex = -10;
    break;
  case KEY_RIGHT:
  case KEY_WARP_RIGHT:
    systemEdge = (HS_SYS_X == 10);
    galaxyEdge = (HS_GAL_Y == 10);
    nextSystemIndex = 1;
    break;
  case KEY_DOWN:
  case KEY_WARP_DOWN:
    systemEdge = (HS_SYS_Y == 10);
    galaxyEdge = (HS_GAL_Y == 10);
    nextSystemIndex = 10;
    break;
  case KEY_LEFT:
  case KEY_WARP_LEFT:
  default:
    systemEdge = (HS_SYS_X == 1);
    galaxyEdge = (HS_GAL_X == 1);
    nextSystemIndex = -1;
    break;
  }
  systemWrap = -9 * nextSystemIndex;

  if (enemyAtTile(systemPos + nextSystemIndex)) {
    return;
  }

  if (!systemEdge) {
    if (getMapTile(systemPos + nextSystemIndex, MAP_TYPE_SYSTEM) == TILE_PLANET) {
      if (HS_SECURITY != SECURITY_SAFE) {
        comLog(COM_BELOW_MAP); //51
        printf("Docking request denied when enemy vessles nearby.");
      } else {
        planetMenu();
        comLog(COM_BELOW_MAP);
      }
    } else if (derelictAtTile(systemPos + nextSystemIndex)) {
      loot();
    } else if (getMapTile(systemPos + nextSystemIndex, MAP_TYPE_SYSTEM)
    == TILE_EMPTY) {
      systemMap[systemPos] = TILE_EMPTY;
      systemMap[systemPos + nextSystemIndex] = TILE_PLAYER;
      ACHIEVE_DISTANCE++;
      findPlayer();
    } else {
      comLog(COM_BELOW_MAP); //51
      fprintf(stderr, "Unknown map tile %d",
      getMapTile(systemPos + nextSystemIndex, MAP_TYPE_SYSTEM));
      exit(1);
    }
  } else { //move uni up
    if (!galaxyEdge) {
      systemMap[systemPos] = TILE_EMPTY;
      systemMap[systemPos + systemWrap] = TILE_PLAYER;
      galaxyMap[galaxyPos] = TILE_EMPTY;
      galaxyMap[galaxyPos + nextSystemIndex] = TILE_PLAYER;
      ACHIEVE_DISTANCE++;
      ACHIEVE_SYSTEMS++;
      findPlayer();
      generateSystem();
      return;
    } else {
      comLog(COM_BELOW_MAP); //51
      printf("You are tying to leave federation space...");
      gotoXY(52, 28);
      printf("This is ill advised.");
    }
  }
  // Update player location
  findPlayer();
}


void printMap(int whichMap, int playerScanning) {
  Debug.log("void printMap(%d, %d)", whichMap, playerScanning);
  int i, j;
  // Reload player and enemies
  findPlayer();
  if (whichMap == MAP_TYPE_SYSTEM) {
    printAt(1, 1, "                System Map");
  } else {
    printAt(1, 1, "                Galaxy Map");
  }
  drawWindow(3, 3, 4 * 10 + 2, 2 * 10 + 1);
  for (i = 0; i < 10; i++) {
    gotoXY(4, 4 + 2 * i);
    printf(" ");
    for (j = 0; j < 10; j++) {
      if (whichMap == MAP_TYPE_GALAXY &&
      (i == 0 || i == 9 || j == 0 || j == 9)) {
        setCB(COL_WHITE, COL_MAGENTA);
      }
      if (whichMap == MAP_TYPE_SYSTEM) {
        printf(" %s ", charColour(systemMap[(i * 10) + j],
        playerScanning, (i * 10) + j));
      } else {
        printf(" %s ", charColour(galaxyMap[(i * 10) + j],
        playerScanning, (i * 10) + j));
      }
      if (j != 9) {
        printf(" ");
      }
    }
  }
}


static char* charColour(int mapTile, int playerScanning, int mapIndex) {
  Debug.log("static char* charColour(%d, %d, %d)", mapTile, playerScanning, mapIndex);
  static char out[BUFFER_MEDIUM] = {0};
  static char tile[32] = {0};
  int colourForeground = COL_WHITE;
  int colourBackground = COL_BLACK_BG;

  if (playerScanning != 0 && rangeScan(playerScanning, mapIndex)) {
    colourBackground = COL_CYAN_BG;
    colourForeground = COL_WHITE;
  }
  if (mapTile >= 1 && mapTile <= 5) {
    colourForeground = COL_RED;
    snprintf(tile, 31, "%s", printShip(mapTile));
  }
  if (mapTile >= 6 && mapTile <= 10) {
    colourForeground = COL_GREY;
    snprintf(tile, 31, "%s", printShip(mapTile));
  }
  if (mapTile == TILE_PLANET) {
    colourForeground = COL_GREEN;
    snprintf(tile, 31, "%c", TILE_PLANET);
  }
  if (mapTile == TILE_PLAYER) {
    colourForeground = COL_YELLOW;
    snprintf(tile, 31, "%s", printShip(HS_SHIP_TYPE));
  }
  if (mapTile == TILE_EMPTY) {
    colourForeground = COL_WHITE;
    snprintf(tile, 31, " ");
  }

  // Format and print out colours and tiles
  snprintf(out, BUFFER_MEDIUM - 1, "\033[%d;%dm%s\033[%d;%dm",
  colourForeground, colourBackground, tile, COL_WHITE, COL_BLACK_BG);

  return out;
}


int rangeScan(int playerScanning, int mapIndex) {
  Debug.log("int rangeScan(%d, %d)", playerScanning, mapIndex);
  int i, xDifference, yDifference, inRange = 0;
  int ranges[3] = {0};
  float distance;

  int weaponStart;
  int *weaponArray;
  if (playerScanning == SCAN_PLAYER_RANGE) {
    weaponArray = hudstats;
    weaponStart = HS_I_WEAPON1;
  } else {
    weaponArray = enemyArray;
    weaponStart = EN_WEAPON1;
  }

  for (i = 1; i <= 5; i++) {
    if (weaponArray[weaponStart + i - 1] != 0) {
      ranges[weaponArray[weaponStart + i - 1] - 1]++;
    }
  }

  // Player
  if (playerScanning == SCAN_ENEMY_RANGE) {
    xDifference = abs(HS_ENEMY_LOC % 10 - mapIndex % 10);
    yDifference = abs(HS_ENEMY_LOC / 10 - mapIndex / 10);
    xDifference -= HS_UP_RANGE;
    yDifference -= HS_UP_RANGE;
  } else {
    xDifference = abs(HS_SYS_X - 1 - mapIndex % 10);
    yDifference = abs(HS_SYS_Y - 1 - mapIndex / 10);
  }

  xDifference = pow(xDifference, 2);
  yDifference = pow(yDifference, 2);
  distance = Math.round(sqrt(xDifference + yDifference));
  if (distance <= 3 && ranges[0] != 0) {
    inRange = 1;
  }
  if (distance <= 5 && ranges[1] != 0) {
    inRange = 1;
  }
  if (distance <= 7 && ranges[2] != 0) {
    inRange = 1;
  }

  return inRange;
}


const char* printShip(int ship) {
  Debug.log("const char* printShip(%d)", ship);
  switch (ship) {
    case 0:
      return ".";
    case 1:
    case 6:
      return "1";
    case 2:
    case 7:
      return "2";
    case 3:
    case 8:
      return "3";
    case 4:
    case 9:
      return "4";
    case 5:
    case 10:
      return "5";
    default:
      return "S";
  }
}


void clean () {
  char dummy;
  do {
    scanf("%c", &dummy);
  }
  while (dummy != '\n');
}


int spawnEnemy(int edgeOfSpace) {
  Debug.log("int spawnEnemy(%d)", edgeOfSpace);
  int i, enemyLocation;
  enemyLocation = randomNumber(99);
  while (systemMap[enemyLocation] != 0) {
    enemyLocation = randomNumber(99);
  }
  systemMap[enemyLocation] = edgeOfSpace ? 2 + randomNumber(4) :
  randomNumber(5);
  EN_POS = enemyLocation;
  EN_SHIP_TYPE = systemMap[enemyLocation];
  EN_TILE = 0;
  for (i = 1; i <= EN_SHIP_TYPE; i++) {
    EN_WEAPON1 = (i < 3) ? i : 1 + randomNumber(2);
    EN_WEAPON2 = (percentile() > 40 && i > 1) ?
    (i > 3) ? randomNumber(3) : randomNumber(2) : 0;
    EN_WEAPON3 = (percentile() > 60 && i > 2) ?
    (i > 3) ? randomNumber(3) : randomNumber(2) : 0;
    EN_WEAPON4 = (percentile() > 70 && i > 3) ? randomNumber(3) : 0;
    EN_WEAPON5 = (percentile() > 70 && i > 4) ? randomNumber(3) : 0;
  }
  EN_SHIELD = capacityArray[10 + EN_SHIP_TYPE];
  EN_HULL = capacityArray[20 + EN_SHIP_TYPE];
  return 1;
}


void generateSystem() {
  Debug.log("void generateSystem()");
  int numberOfPlanets = 0, chance, i, derelictLocation;

  initialize(1);
  initEnemy(0);
  chance = percentile();
  if (chance > 50) {
    numberOfPlanets = (chance - 30) / 20;
  }
  for (i = 0; i < numberOfPlanets; i++) {
    int placePlanet = randomNumber(100);
    while (systemMap[placePlanet] != 0) {
      placePlanet = randomNumber(100);
    }
    systemMap[placePlanet] = 'O';
  }
  chance = percentile();
  int xyEdge = (HS_GAL_X == 1 || HS_GAL_X == 10 || HS_GAL_Y == 1 ||
  HS_GAL_Y == 10)? 1 : 0;
  if ((xyEdge && chance > 30) || chance > 75) {
    spawnEnemy(xyEdge);
  }

  chance = percentile();
  if (chance > 90 && EN_SHIP_TYPE == 0) {
    derelictLocation = randomNumber(99);
    while (systemMap[derelictLocation] != 0) {
      derelictLocation = randomNumber(100);
    }
    EN_POS = derelictLocation;
    systemMap[derelictLocation] = 6 + randomNumber(4);
    EN_SHIP_TYPE = systemMap[derelictLocation];
    EN_TILE = 0;
  }

  HS_STELLAR = randomNumber(10);
  HS_DATE += 1 + randomNumber(9);
}


void printProgressBar(int skillSlot) {
  Debug.log("void printProgressBar(%d)", skillSlot);
  int i;
  printf("  ");
  for (i = 1; i <= 10; i++) {
    if (skillsArray[skillSlot] % 10 >= i) {
      setCB(COL_WHITE, COL_GREEN);
    } else {
      setCB(COL_WHITE, COL_BLACK);
      printf("  ");
      setCB(COL_WHITE, COL_BLACK);
      printf("|");
    }
  }
}


// TODO
void skillsHUD(int x, int page) {
  Debug.log("void skillsHUD(%d, %d)", x, page);
  int i, j, p = 9;
  gotoXY(x, 2);
  printf(" Skills:");
  gotoXY(x + 48, 2);
  printf("Page %i", page);
  gotoXY(x, 3);
  printf("%s", HUD_LINE);

  for (j = 4; j <= 22; j += 2) {
    gotoXY(x, j);
    printf("  Skill %i", 10 * page - p);
    gotoXY(x, j + 1);
    printProgressBar(10 * page - p);
    printf("\tLevel %i (%i %c)\t", skillsArray[10 * page - p] / 10 + 1,
    (skillsArray[10 * page - p] % 10) * 10, 37);
    p--;
  }

  for (i = 4; i < 32; i++) {
    gotoXY(x, i);
    printf("|");
    gotoXY(x + HUD_WIDTH, i);
    printf("|");
  }
}


static char* getCoords(int mapType) {
  Debug.log("static char* getCoords(%d)", mapType);
  static char buf[BUFFER_MEDIUM] = {0};
  const char* fmt = "(%s%d, %d"STR_COL_WHITE")";

  if (mapType == MAP_TYPE_SYSTEM) {
    snprintf(buf, BUFFER_MEDIUM, fmt, STR_COL_WHITE, HS_SYS_X, HS_SYS_Y);
  } else {
    if (HS_GAL_X == 1 || HS_GAL_X == 10 || HS_GAL_Y == 1 || HS_GAL_Y == 10) {
      snprintf(buf, BUFFER_MEDIUM, fmt, STR_COL_RED, HS_GAL_X, HS_GAL_Y);
    } else {
      snprintf(buf, BUFFER_MEDIUM, fmt, STR_COL_WHITE, HS_GAL_X, HS_GAL_Y);
    }
  }

  return buf;
}


void minimalHUD(int startX, int startY) {
  Debug.log("void minimalHUD(%d, %d)", startX, startY);
  //clear old
  gotoXY(startX, startY++);
  clrLine();
  printf("Shields: %s  ",
  hudColours(HS_SHIELD, capacityArray[10 + HS_SHIP_TYPE]));
  printf("Hull: %s  ",
  hudColours(HS_HULL, capacityArray[20 + HS_SHIP_TYPE]));
  printf("Energy: %-10s",
  hudColours(HS_ENERGY, capacityArray[30 + HS_SHIP_TYPE]));
  gotoXY(startX, startY++);
  clrLine();
  printf("Security: %s  Armaments: %s  ",
  securityStatus(), weaponStatus());
  printf("Torpedos: %-10s", hudColours(HS_TORPEDOS,
  capacityArray[40 + HS_SHIP_TYPE]));
  gotoXY(startX, startY++);
  clrLine();
  printf("Enemies: %d  Planets: %d  ISO: %d  Credits: %-10s", HS_ENEMIES,
  HS_PLANETS, HS_STELLAR, prefix(HS_CREDITS, 'n'));
  gotoXY(startX, startY);
  clrLine();
  printf("System: %s  ", getCoords(MAP_TYPE_SYSTEM));
  printf("Galaxy: %-10s", getCoords(MAP_TYPE_GALAXY));
}


void drawWindow(int x, int y, int w, int h) {
  Debug.log("void drawWindow(%d, %d, %d, %d)", x, y, w, h);
  int i;
  char line[BUFFER_MEDIUM];
  memset(line, '-', BUFFER_MEDIUM);

  gotoXY(x, y);
  printf("+%*.*s+", w - 2, w - 2, line);

  for (i = y + 1; i < y + h - 1; i++) {
    gotoXY(x, i);
    printf("|%*s|", w - 2, " ");
    //printf("%d%*s|", i, w - 2, " ");
  }

  gotoXY(x, y + h - 1);
  printf("+%*.*s+", w - 2, w - 2, line);
}


static char* weaponStatus() {
  Debug.log("static char* weaponStatus()");
  static char buf[BUFFER_MEDIUM] = {0};
  // memset(buf, 0, BUFFER_MEDIUM);

  if (HS_SHIP_TYPE == 0) {
    snprintf(buf, BUFFER_MEDIUM - 1, "---");
    return buf;
  } else {
    rangeCheck(SCAN_PLAYER_RANGE, SCAN_TYPE_RANGE);
    if (EN_SHIP_TYPE > 0 && EN_SHIP_TYPE < 6) {
      snprintf(buf, BUFFER_MEDIUM - 1, "%i/%i (%s%i%s in range)", gunCount(),
      capacityArray[5 + HS_SHIP_TYPE], gunRangeColour(gunCount(), HS_IN_RANGE),
      HS_IN_RANGE, STR_COL_WHITE);
    } else {
      snprintf(buf, BUFFER_MEDIUM - 1, "%i/%i", gunCount(),
      capacityArray[5 + HS_SHIP_TYPE]);
    }
  }

  return buf;
}


// Clear, redraw, and set cursor at top left spot
void comLog(int x, int y) {
  Debug.log("void comLog(%d, %d)", x, y);
  drawWindow(x, y, COM_WIDTH, COM_HEIGHT);
  gotoXY(x + 1, y + 1);
}


void HUD(int startX, int startY) {
  Debug.log("void HUD(%d, %d)", startX, startY);
  findPlayer();
  securityStatus();
  startX++;
  gotoXY(startX, startY);
  printf("Helm Console:");
  drawWindow(startX - 1, ++startY, HUD_WIDTH, HUD_HELM_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Stardate           : %i.%i", HS_DATE / 10, HS_DATE % 10);
  gotoXY(startX, ++startY);
  printf(" Ship Class         : %s", shipName(HS_SHIP_TYPE));
  gotoXY(startX, ++startY);
  printf(" System Coordinates : (%i, %i)  ", HS_SYS_X, HS_SYS_Y);
  gotoXY(startX, ++startY);
  printf(" Galaxy Coordinates : (%i, %i)  ", HS_GAL_X, HS_GAL_Y);
  if (HS_GAL_X == 1 || HS_GAL_X == 10 || HS_GAL_Y == 1 || HS_GAL_Y == 10) {
    gotoXY(startX + 22, startY);
    setC(COL_RED);
    printf("%i, %i", HS_GAL_X, HS_GAL_Y);
    setC(COL_WHITE);
    printf(")");
  }

  startY++;
  gotoXY(startX, ++startY);
  printf("Tactical Ship Status:");
  gotoXY(startX, ++startY);
  drawWindow(startX - 1, startY, HUD_WIDTH, HUD_STATUS_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Shields         : %s", hudColours(HS_SHIELD,
  capacityArray[10 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Hull Integrity  : %s", hudColours(HS_HULL,
  capacityArray[20 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Security        : %s", securityStatus());
  gotoXY(startX, ++startY);
  printf(" Energy Reserves : %s", hudColours(HS_ENERGY,
  capacityArray[30 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Torpedos        : %s", hudColours(HS_TORPEDOS,
  capacityArray[40 + HS_SHIP_TYPE]));
  gotoXY(startX, ++startY);
  printf(" Armaments       : %s", weaponStatus());

  startY++;
  gotoXY(startX, ++startY);
  printf("Cargo: ");
  if (HS_SHIP_TYPE == 0) {
    printf("---");
  } else {
    printf("(%i/%i units)",
    HS_PLASMA + HS_DUTERIUM + HS_LATINUM + HS_WATER + HS_URANIUM,
    capacityArray[HS_SHIP_TYPE] + 100 * HS_UP_CARGO);
  }
  gotoXY(startX, ++startY);
  drawWindow(startX - 1, startY, HUD_WIDTH, HUD_CARGO_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Credits     : %s", prefix(HS_CREDITS, 'n'));
  gotoXY(startX, ++startY);
  if (HS_SHIP_TYPE != SHIP_ESCAPE_POD) {
    printf(" Warp Plasma : %s", prefix(HS_PLASMA, 'L'));
    gotoXY(startX, ++startY);
    printf(" Duterium    : %s", prefix(HS_DUTERIUM, 'g'));
    gotoXY(startX, ++startY);
    printf(" Latinum     : %s", prefix(HS_LATINUM, 'g'));
    gotoXY(startX, ++startY);
    printf(" Water       : %s", prefix(HS_WATER, 'L'));
    gotoXY(startX, ++startY);
    printf(" Uranium Ore : %s", prefix(HS_URANIUM, 'g'));
  } else {
    printf(" Warp Plasma : ---");
    gotoXY(startX, ++startY);
    printf(" Duterium    : ---");
    gotoXY(startX, ++startY);
    printf(" Latinum     : ---");
    gotoXY(startX, ++startY);
    printf(" Water       : ---");
    gotoXY(startX, ++startY);
    printf(" Uranium Ore : ---");
  }
  ++startY;

  gotoXY(startX, ++startY);
  printf("System Peripherals:");
  drawWindow(startX - 1, ++startY, HUD_WIDTH, HUD_SYSTEM_HEIGHT);
  gotoXY(startX, ++startY);
  printf(" Planets: %i ", HS_PLANETS);
  gotoXY(startX, ++startY);
  printf(" Enemies: %i", HS_ENEMIES);
  gotoXY(startX, ++startY);
  printf(" Inactive Stellar Objects: %i  ", HS_STELLAR);
}


const char* gunRangeColour(int totalGuns, int gunsInRange) {
  Debug.log("const char* gunRangeColour(%d, %d)", totalGuns, gunsInRange);
  if (gunsInRange == 0) {
    // red no guns in range
    return STR_COL_RED;
  } else if (gunsInRange == totalGuns) {
    // green, all guns in range
    return STR_COL_GREEN;
  }
  // yellow, not all guns in range
  return STR_COL_YELLOW;
}


int gunCount() {
  Debug.log("int gunCount()");
  int i, guns = 0;
  for (i = 21; i <= 25; i++) {
    if (hudstats[i] == 1 || hudstats[i] == 2 || hudstats[i] == 3) {
      guns++;
    }
  }
  HS_WEAPONS = guns;
  return guns;
}


static char* prefix(int arrayValue, char unit) {
  Debug.log("static char* prefix(%d, %c)", arrayValue, unit);
  int pointValue, decimal, zero = 0;
  char unitPrefix;
  static char buf[BUFFER_MEDIUM] = {0};
  // memset(buf, 0, BUFFER_MEDIUM);

  if (arrayValue >= 1000) {
    pointValue = arrayValue / 1000;
    decimal = (arrayValue % 1000) / 10;
    zero = (decimal < 10);

    unitPrefix = 'k';
  }

  if (arrayValue >= 1000000) {
    zero = 0;
    pointValue = arrayValue / 1000000;
    decimal = (arrayValue % 1000000) / 10000;
    zero = (decimal < 10);
    unitPrefix = 'M';
  }
  const char *suffix = { (unit == 'g') ? " kg" : (unit == 'L') ? " L" : "" };

  if (arrayValue < 1000) {
    snprintf(buf, BUFFER_MEDIUM - 1, "%i%s",
    arrayValue, suffix);
  } else if (zero == 0) {
    snprintf(buf, BUFFER_MEDIUM - 1, "%i.%i%c%s",
    pointValue, decimal, unitPrefix, suffix);
  } else {
    snprintf(buf, BUFFER_MEDIUM - 1, "%i.0%i%c%s",
    pointValue, decimal, unitPrefix, suffix);
  }
  return buf;
}


void findPlayer() {
  Debug.log("void findPlayer()");
  int i;
  HS_PLANETS = 0;//planets
  HS_ENEMIES = 0;//enemies
  for (i = 0; i < 100; i++) {
    if (systemMap[i] == TILE_PLAYER) {
      HS_SYS_X = i % 10 + 1;
      HS_SYS_Y = i / 10 + 1;
    } else if (systemMap[i] > 0 && systemMap[i] < 6) {
      EN_POS = i;
      EN_SHIP_TYPE = systemMap[i];
      HS_ENEMIES++;
      HS_ENEMY_LOC = i;
      if (EN_TILE == 'O') {
        HS_PLANETS++;
      }
    } else if (systemMap[i] == TILE_PLAYER) {
      HS_PLANETS++;
    }
    if (galaxyMap[i] == 'P') {
      HS_GAL_X = i % 10 + 1;
      HS_GAL_Y = i / 10 + 1;
    }
  }
}


const char* securityStatus() {
  Debug.log("const char* securityStatus()");
  int i, status = 1;

  for (i = 0; i < 100; i++) {
    if (systemMap[i] >= 1 && systemMap[i] <= 5) {
      status = 2;
      if (rangeCheck(SCAN_ENEMY_RANGE, SCAN_TYPE_RANGE)) {
        status = 3;
      }
      break;
    }
  }

  HS_SECURITY = status;

  if (HS_SHIP_TYPE == SHIP_ESCAPE_POD) {
    return "---";
  }

  switch (status) {
  case 1:
    return "Safe";
  case 2:
    return "\033[30;43mCaution"STR_COL_RESET;
  case 3:
    return "\033[37;41mDanger"STR_COL_RESET;
  }
  return "";
}


void planetWindow() {
  Debug.log("void planetWindow()");
  drawWindow(1, 1, 60, 23);
}


void planetHUD() {
  Debug.log("void planetHUD()");
  clrs();
  planetWindow();
  minimalHUD(HUD_MINIMAL_START);
  comLog(COM_BELOW_MAP);
}


void planetMenu() {
  Debug.log("void planetMenu()");
  Menu menu = Menu(PLANET_MENU_START);
  int i = 1, reward;
  menu.addOption("0: Undock");

  ACHIEVE_PLANETS++;

  if (initShips()) {
    menu.addOption("%d: Shipyard", i++);
  }
  if (initOutfit()) {
    menu.addOption("%d: Outfitter", i++);
  }
  if (initCommerce()) {
    menu.addOption("%d: Commercial Sector", i++);
  }
  menu.addOption("%d: Bar", i++);
  planetHUD();
  if (HS_PASSENGERS != 0) {
    reward = HS_PASSENGERS * (8000 + randomNumber(4000));
    comLog(COM_BELOW_PLANET_HUD); //66
    printf("Your passenger");
    if (HS_PASSENGERS != 1) {
      printf("s");
    }
    printf(" rewarded you with %s credits.", prefix(reward, 'n'));
    HS_CREDITS += reward;
    HS_PASSENGERS = 0;
  }

  do {
    printAt(PLANET_MENU_HEADER, "%s", "Planetary services:");
    menu.getSelection();

    if (menu.isHighlighted("Shipyard")) {
      shipyardMenu();
    } else if (menu.isHighlighted("Outfitter")) {
      outfitterMenu();
    } else if (menu.isHighlighted("Commercial")) {
      commerceMenu();
    } else if (menu.isHighlighted("Bar")) {
      barMenu();
    } else {
      for (i = 0; i < 100; i++) {
        commerceArray[i] = 0;
        outfitArray[i] = 0;
        shipArray[i] = 0;
      }
      clrs();
      HS_DATE++;
      return;
    }
  } while (1);
}


int buildShipMenu(Menu *menu) {
  Debug.log("int buildShipMenu(%d)", menu);
  int i = 1;
  menu->addOption("0: Back");
  if (shipArray[0] == 1) {
    menu->addOption("%i: NXC-01: P-Class Shuttle", i++);
    menu->indices[i - 1] = 1;
  }
  if (shipArray[2] == 1) {
    menu->addOption("%i: Expanse 5060: F-Class Cargo Drone", i++);
    menu->indices[i - 1] = 2;
  }
  if (shipArray[4] == 1) {
    menu->addOption("%i: Axess DN-5: F-Class Freighter", i++);
    menu->indices[i - 1] = 3;
  }
  if (shipArray[6] == 1) {
    menu->addOption("%i: Green Goose FX-1: C-Class Frigate", i++);
    menu->indices[i - 1] = 4;
  }
  if (shipArray[8] == 1) {
    menu->addOption("%i: Imperium Industry FT9: C-Class Destroyer", i++);
    menu->indices[i - 1] = 5;
  }

  return i - 1;
}


void shipyardMenu() {
  Debug.log("void shipyardMenu()");
  int choice, nShips;

  Menu menu = Menu(PLANET_MENU_START);
  nShips = buildShipMenu(&menu);

  planetHUD();
  printAt(PLANET_MENU_HEADER, "%s", "Ships avaliable at this location:");
  do {
    choice = menu.getInput();
    planetHUD();
    printAt(PLANET_MENU_HEADER, "%s", "Ships avaliable at this location:");

    if (menu.highlighted > 0 && menu.highlighted <= nShips) {
      shipInfo(menu.indices[menu.highlighted]); // 1, 3, 5, 7, 9
    }
    if (choice == KEY_RETURN && !menu.isHighlighted("Back")) {
      comLog(COM_BELOW_PLANET_HUD); //66
      printf("You entered %d", menu.highlighted);
      /*
      comLog(COM_BELOW_PLANET_HUD); //66
      if (submenu == 1) {
        if (HS_CREDITS + resaleValue() < shipArray[ship * 2 - 1]) {
          comLog(COM_BELOW_PLANET_HUD); //66
          printf("Insufficient credits.");
        } else {
          cost = (shipArray[ship * 2 - 1] - resaleValue() > 0) ?
          shipArray[ship * 2 - 1] - resaleValue() : 0;

          printBuySell('b', 's', HS_SHIP_TYPE, ship, cost);
          HS_CREDITS -= cost;
          HS_SHIP_TYPE = ship;
          HS_SHIELD = capacityArray[10 + HS_SHIP_TYPE];
          HS_HULL = capacityArray[20 + HS_SHIP_TYPE];
          HS_ENERGY = capacityArray[30 + HS_SHIP_TYPE];
          HS_TORPEDOS = 0;
          for (i = HS_I_WEAPON1; i <= HS_I_UP_TORP; i++) {
            hudstats[i] = 0;
          }
          ACHIEVE_SHIPS++;
        }
      }*/
    }
  } while (!((choice == KEY_RETURN && menu.isHighlighted("Back")) ||
  choice == 0));
}


int buildOutfitterMenu(Menu *outfitMenu, Menu *repairMenu, Menu *supplyMenu,
Menu *upgradeMenu) {
  Debug.log("int buildOutfitterMenu(menus)");
  int i = 1;
  int n = outfitArray[0] + outfitArray[3] + outfitArray[8];
  outfitMenu->addOption("0: Back");

  if (n > 0) {
    if (outfitArray[0] == 1) {
      outfitMenu->addOption("%d: Repairs", i);
      i++;
      repairMenu->addOption("0: Back");
      repairMenu->addOption("1: Hull Repairs (%i/hour)",
      outfitArray[1] * HS_SHIP_TYPE);
      repairMenu->addOption("2: Power Cell Replacement (%i/hour)",
      outfitArray[2] * HS_SHIP_TYPE);
    }
    if (outfitArray[3] == 1) {
      outfitMenu->addOption("%d: Supplies", i);
      i++;
      supplyMenu->addOption("0: Back");
      supplyMenu->addOption("1: Buy Torpedos (%i/unit)", outfitArray[4]);
      supplyMenu->addOption("2: Sell Torpedos (%i/unit)", outfitArray[4]);
      supplyMenu->addOption("3: Buy Weapons");
      supplyMenu->addOption("4: Sell Weapons");
    }
    if (outfitArray[8] == 1) {
      outfitMenu->addOption("%d: Upgrades", i);
      upgradeMenu->addOption("0: Back");
      upgradeMenu->addOption("1: Ammunition Upgrade");
      upgradeMenu->addOption("2: Cannon Barrel Upgrade");
      upgradeMenu->addOption("3: Advanced Hull Plating Upgrade");
      upgradeMenu->addOption("4: Oscillating Shield Upgrade");
      upgradeMenu->addOption("5: Cargo Refit");
      upgradeMenu->addOption("6: Advanced Torpedo Upgrade");
      upgradeMenu->addOption("7: Port and Polish Engine Upgrade");
      i++;
    }
  }

  return n;
}


int tryToSell(int quantity, int price, int hudstat) {
  Debug.log("int tryToSell(%d, %d, %d)", quantity, price, hudstat);
  if (hudstats[hudstat] < quantity) {
    comLog(COM_BELOW_PLANET_HUD);
    printf("Insufficient supply. Did you want to sell %d (y/n)?",
    hudstats[hudstat]);
    int buymax = getch();
    if (buymax == 'y') {
      printBuySell('s', hudstat, hudstats[hudstat],
      hudstats[hudstat] * price, 0);
      HS_CREDITS += hudstats[hudstat] * price;
      hudstats[hudstat] = 0;
    } else {
      comLog(COM_BELOW_PLANET_HUD); //66
    }
  } else {
    printBuySell('s', hudstat, quantity, quantity * price, 0);
    hudstats[hudstat] -= quantity;
    HS_CREDITS += quantity * price;
  }
  return 1;
}


int tryToBuy(int quantity, int price, int hudstat) {
  Debug.log("int tryToBuy(%d, %d, %d)", quantity, price, hudstat);
  int capacity = hudstatToCapacity(hudstat);
  int nBought = 0;
  int cost = 0;
  char buymax;

  if (HS_CREDITS >= quantity * price &&
  checkCapacity(hudstat, quantity, HS_SHIP_TYPE)) {
    hudstats[hudstat] += quantity;
    HS_CREDITS -= quantity * price;
    printBuySell('b', hudstat, quantity, price, 0);
    return 1;
  } else {
    comLog(COM_BELOW_PLANET_HUD); //66
    printLinesAt(COM_BELOW_PLANET_HUD_START,
    "Insufficient credits or space.\n"
    "Do you want to buy the max ammount (y/n)?");
    buymax = getch();
    if (buymax == 'y') {
      if (HS_CREDITS / price >= capacity - hudstats[hudstat]) {
        nBought = capacity - hudstats[hudstat];
      } else {
        nBought = HS_CREDITS / price;
      }
      cost = price;
      printBuySell('b', hudstat, nBought, cost, 0);
      hudstats[hudstat] += nBought;
      HS_CREDITS -= cost * nBought;
      return 1;
    } else {
      comLog(COM_BELOW_PLANET_HUD); //66
      return 0;
    }
  }//buymax

  return 0;
}


void outfitterMenu() {
  Debug.log("void outfitterMenu()");
  int quantity = 0, choice;
  Menu outfitMenu = Menu(PLANET_MENU_START);
  Menu repairMenu = Menu(PLANET_MENU_START);
  Menu supplyMenu = Menu(PLANET_MENU_START);
  Menu upgradeMenu = Menu(PLANET_MENU_START);
  // Menu weaponMenu = Menu(PLANET_MENU_START);

  buildOutfitterMenu(&outfitMenu, &repairMenu, &supplyMenu, &upgradeMenu);

  do {
    planetHUD();
    printAt(PLANET_MENU_HEADER, "%s", "Oufitter services at this location:");
    outfitMenu.getSelection();

    if (outfitMenu.isHighlighted("Repair")) {
      do {
        planetHUD();
        printAt(PLANET_MENU_HEADER, "%s", "Repairs:");
        repairMenu.getSelection();

        if (repairMenu.isHighlighted("Hull")) {
          comLog(COM_BELOW_PLANET_HUD);
          printf("Hours: ");
          scanf("%i", &quantity);
          clean();
          tryToBuy(quantity, outfitArray[1] * HS_SHIP_TYPE, HS_I_HULL);
        }
        if (repairMenu.isHighlighted("Power")) {
          comLog(COM_BELOW_PLANET_HUD);
          printf("Hours:");
          scanf("%i", &quantity);
          clean();
          tryToBuy(quantity, outfitArray[2] * HS_SHIP_TYPE, HS_I_SHIELD);
        }
      } while (!repairMenu.isHighlighted("Back"));
    } else if (outfitMenu.isHighlighted("Supplies")) {
      do {
        planetHUD();
        printAt(PLANET_MENU_HEADER, "%s", "Resupply:");
        supplyMenu.getSelection();

        if (supplyMenu.isHighlighted("Buy Torpedos")) {
          comLog(COM_BELOW_PLANET_HUD);
          printf("Torpedo quantity to buy: ");
          scanf("%i", &quantity);
          clean();
          tryToBuy(quantity, outfitArray[4] * HS_SHIP_TYPE, HS_I_TORPEDOS);
        }
        if (supplyMenu.isHighlighted("Sell Torpedos")) {
          gotoXY(3, 27);
          printf("Torpedo quantity to sell: ");
          scanf("%i", &quantity);
          clean();
          tryToSell(quantity, outfitArray[4], HS_I_TORPEDOS);
          /*
          comLog(COM_BELOW_PLANET_HUD); //66
          if (HS_TORPEDOS < quantity) {
            comLog(COM_BELOW_PLANET_HUD); //66
            printf("Insufficient supply");
            gotoXY(3, 27);
            printf("Do you want to sell all your torpedos (y/n)?");
            buymax = getch();
            if (buymax == 'y') {
              printBuySell('s', 't', HS_TORPEDOS,
              HS_TORPEDOS * outfitArray[4], 0);
              HS_TORPEDOS -= HS_TORPEDOS;
              HS_CREDITS -= HS_TORPEDOS * outfitArray[4];
            } else {
              comLog(COM_BELOW_PLANET_HUD); //66
            }
          } else {
            printBuySell('s', 't', quantity, quantity * outfitArray[4], 0);
            HS_TORPEDOS -= quantity;
            HS_CREDITS += quantity * outfitArray[4];
          }*/
        }
        if (supplyMenu.isHighlighted("Buy Weapons")) {
          /*do {
            planetHUD();
            printf("Weapons for sale:");
            //wepon menu
            printf("1: Pew-Pew SK-337 Lance (%s)",
            prefix(outfitArray[5], 'n'));
            printf("2: N00bzorz ID 10-T Killer (%s)",
            prefix(outfitArray[6], 'n'));
            printf("3: Pwnzorz 1337 Cannon (%s)", prefix(outfitArray[7], 'n'));
            printf("1-3: Weapon info    0: Back");
            gotoXY(3, 29);
            subsubmenu = getch() - '0';
            comLog(COM_BELOW_PLANET_HUD); //66
            if (subsubmenu == 1) {
              do {
                planetHUD();
                gotoXY(3, 5);
                printf("Pew-Pew SK-337 Lance    %s",
                prefix(outfitArray[5], 'n'));
                gotoXY(3, 7);
                printf("Damage: 30");
                gotoXY(3, 8);
                printf("Range: 30km");
                gotoXY(3, 9);
                printf("Energy depletion: 10 MJ");
                gotoXY(3, 10);
                printf("Compatibility: All standard regulation federation"
                " ships.");
                gotoXY(3, 27);
                printf("1: Buy  0: Back");
                gotoXY(3, 28);
                subsubsubmenu = getch() - '0';
                gotoXY(3, 28);
                printf("  ");
                *
                comLog(COM_BELOW_PLANET_HUD); //66
                if (subsubsubmenu == 1) {
                  if (HS_CREDITS < outfitArray[5] ||
                  HS_WEAPONS == capacityArray[5 + HS_SHIP_TYPE]) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Insufficient funds or space.");
                  } else {
                    cost = outfitArray[5];
                    printBuySell('b', 'g', 1, cost, 0);
                    HS_CREDITS -= cost;
                    for (i = HS_I_WEAPON1; i < HS_I_WEAPON5; i++) {
                      if (hudstats[i] == 0) {
                        hudstats[i] = 1;
                        break;
                      }
                    }
                    hudstats[i] = 1;
                    HS_WEAPONS++;
                    ACHIEVE_WEAPONS++;
                  }
                }*
                if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                  comLog(COM_BELOW_PLANET_HUD); //66
                  printf("Invalid selection.");
                }
              } while (subsubsubmenu != 0);
              comLog(COM_BELOW_PLANET_HUD); //66
            }
            if (subsubmenu == 2) {
              do {
                planetHUD();
                gotoXY(3, 5);
                printf("N00bzorz ID10-T Killer    %s",
                prefix(outfitArray[6], 'n'));
                gotoXY(3, 7);
                printf("Damage: 50");
                gotoXY(3, 8);
                printf("Range: 50km");
                gotoXY(3, 9);
                printf("Energy depletion: 50 MJ");
                gotoXY(3, 10);
                printf("Compatibility: F or C class federation ships.");
                gotoXY(3, 27);
                printf("1: Buy  0: Back");
                gotoXY(3, 28);
                subsubsubmenu = getch() - '0';
                gotoXY(3, 28);
                printf("  ");
                *
                comLog(COM_BELOW_PLANET_HUD); //66
                if (subsubsubmenu == 1) {
                  // TODO split for better errors
                  if (HS_CREDITS < outfitArray[6] || HS_WEAPONS ==
                  capacityArray[5 + HS_SHIP_TYPE] || HS_SHIP_TYPE == 1) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Insufficient funds, space, or compatibility.");
                  } else {
                    cost = outfitArray[6];
                    printBuySell('b', 'g', 2, cost, 0);
                    HS_CREDITS -= cost;
                    for (i = HS_WEAPON1; i < HS_WEAPON5; i++) {
                      if (hudstats[i] == 0) {
                        hudstats[i] = 2;
                        break;
                      }
                    }
                    HS_WEAPONS++;
                    ACHIEVE_WEAPONS++;
                  }
                }*
                if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                  comLog(COM_BELOW_PLANET_HUD); //66
                  printf("Invalid selection.");
                }
              } while (subsubsubmenu != 0);
              comLog(COM_BELOW_PLANET_HUD); //66
            }
            if (subsubmenu == 3) {
              do {
                planetHUD();
                gotoXY(3, 5);
                printf("Pwnzorz 1337 Cannon    %s",
                prefix(outfitArray[7], 'n'));
                gotoXY(3, 7);
                printf("Damage: 100");
                gotoXY(3, 8);
                printf("Range: 70km");
                gotoXY(3, 9);
                printf("Energy depletion: 100 MJ");
                gotoXY(3, 10);
                printf("Compatibility: C class federation ships.");
                gotoXY(3, 27);
                printf("1: Buy  0: Back");
                gotoXY(3, 28);
                subsubsubmenu = getch() - '0';
                gotoXY(3, 28);
                printf("  ");
                *
                comLog(COM_BELOW_PLANET_HUD); //66
                if (subsubsubmenu == 1) {
                  if (HS_CREDITS < outfitArray[7] ||
                  HS_WEAPONS == capacityArray[5 + HS_SHIP_TYPE] ||
                  HS_SHIP_TYPE < 4) {
                    comLog(COM_BELOW_PLANET_HUD); //66
                    printf("Insufficient funds, space, or compatibility.");
                  } else {
                    cost = outfitArray[7];
                    printBuySell('b', 'g', 3, cost, 0);
                    HS_CREDITS -= cost;
                    for (i = 1; i < 6; i++) {
                      if (hudstats[HS_I_ENEMY_LOC + i] == 0) {
                        hudstats[HS_I_ENEMY_LOC + i] = 3;
                        break;
                      }
                    }
                    HS_WEAPONS++;
                    ACHIEVE_WEAPONS++;
                  }
                }*
                if (subsubsubmenu != 0 && subsubsubmenu != 1) {
                  comLog(COM_BELOW_PLANET_HUD); //66
                  printf("Invalid selection.");
                }
              } while (subsubsubmenu != 0);
              comLog(COM_BELOW_PLANET_HUD); //66
            }
            if (subsubmenu != 1 && subsubmenu != 2 && subsubmenu != 3) {
              gotoXY(67, 27);
              printf("Invalid selection.");
            }
          } while (subsubmenu != 0);
          */
        }
        if (supplyMenu.isHighlighted("Sell weapons")) {
//        do {
//          planetHUD();
//          gotoXY(3, 5);
//          printf("Your Weapons:");
//          gotoXY(3, 7);
//          if (HS_WEAPON1 != 0) {
//            printf("1: Sell Type %i Weapon in slot 1 (%s)", HS_WEAPON1,
//            prefix(outfitArray[4 + HS_WEAPON1] / 2, 'n'));
//          } else {
//             printf("No weapon in slot 1");
//          }
//          gotoXY(3, 8);
//          if (HS_WEAPON2 != 0) {
//            printf("2: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON2,
//            prefix(outfitArray[4 + HS_WEAPON2] / 2, 'n'));
//          } else {
//             printf("No weapon in slot 2");
//          }
//          gotoXY(3, 9);
//          if (HS_WEAPON3 != 0) {
//            printf("3: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON3,
//            prefix(outfitArray[4 + HS_WEAPON3] / 2, 'n'));
//          } else {
//             printf("No weapon in slot 3");
//          }
//          gotoXY(3, 10);
//          if (HS_WEAPON4 != 0) {
//            printf("4: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON4,
//            prefix(outfitArray[4 + HS_WEAPON4] / 2, 'n'));
//          } else {
//             printf("No weapon in slot 4");
//          }
//          gotoXY(3, 11);
//          if (HS_WEAPON5 != 0) {
//            printf("5: Sell Type %i Weapon in slot 2 (%s)", HS_WEAPON5,
//            prefix(outfitArray[4 + HS_WEAPON5] / 2, 'n'));
//          } else {
//             printf("No weapon in slot 5");
//          }
//          gotoXY(3, 13);
//          printf("0: Back");
//          gotoXY(3, 27);
//          printf("1-5: Sell weapon in slot    0: Back");
//          gotoXY(3, 29);
//          subsubmenu = getch() - '0';
//          gotoXY(3, 27);
//          comLog(COM_BELOW_PLANET_HUD); //66
//          if (subsubmenu > 0 && subsubmenu < 6 &&
//          hudstats[HS_I_ENEMY_LOC + subsubmenu] == 0) {
//            comLog(COM_BELOW_PLANET_HUD); //66
//            printf("There is no weapon in that slot.");
//          }
//          if (subsubmenu > 0 && subsubmenu < 6 &&
//          hudstats[HS_I_ENEMY_LOC + subsubmenu] != 0) {
//            cost = outfitArray[4 + hudstats[HS_I_ENEMY_LOC + subsubmenu]] / 2;
//            printBuySell('s', HS_I_WEAPONS,
//            hudstats[HS_I_ENEMY_LOC + subsubmenu],
//            cost, 0);
//            HS_CREDITS += cost;
//            hudstats[HS_I_ENEMY_LOC + subsubmenu] = 0;
//            HS_WEAPONS--;
//          }
//          if (subsubmenu < 0 || subsubmenu > 5) {
//            comLog(COM_BELOW_PLANET_HUD); //66
//            printf("Invalid selection.");
//          }
//        } while (subsubmenu != 0);
        }
      } while (!supplyMenu.isHighlighted("Back"));
    } else if (outfitMenu.isHighlighted("Upgrade")) {
      planetHUD();
      printAt(PLANET_MENU_HEADER, "Upgrades:");
      do {
        choice = upgradeMenu.getInput();
        planetHUD();
        printAt(PLANET_MENU_HEADER, "Upgrades:");
        if (upgradeMenu.highlighted > 0 && upgradeMenu.highlighted <= 7) {
          Upgrade upgrade = UPGRADES[upgradeMenu.highlighted - 1];
          printLinesAt(3, 14, upgrade.description);
          printf("%i", hudstats[upgrade.hudstat]);
          if (choice == KEY_RETURN) {
            comLog(COM_BELOW_PLANET_HUD); //66
            if (HS_CREDITS < upgrade.cost) {
              printf("Insufficient credits.");
            } else if (hudstats[upgrade.hudstat] >= upgrade.max) {
              printf("There is no more room for this upgrade.");
            } else if (HS_SHIP_TYPE < upgrade.compatibility) {
              printf("Upgrade incompatible with ship architecture.");
            } else {
              printf("You bought %s for %s credits.", upgrade.name,
              prefix(upgrade.cost, 'n'));
              HS_CREDITS -= upgrade.cost;
              hudstats[upgrade.hudstat]++;
              printLinesAt(3, 14, upgrade.description);
              printf("%i", hudstats[upgrade.hudstat]);
            }
          }
        }
      } while (!((choice == KEY_RETURN && upgradeMenu.isHighlighted("Back")) ||
      choice == 0));
    }
  } while (!outfitMenu.isHighlighted("Back"));
  planetHUD();
}


// int initOutfit() {
//   Debug.log("int initOutfit()");
//   int i = 0;
//   if (percentile() > 20) {
//     outfitArray[0] = 1;
//     i = 1;
//   }
//   outfitArray[1] = 5 + randomNumber(10);
//   outfitArray[2] = 10 + randomNumber(10);

//   if (percentile() > 50) {
//     outfitArray[3] = 1;
//     i = 1;
//   }
//   outfitArray[4] = 900 + randomNumber(200); // torps
//   outfitArray[5] = 80000 + randomNumber(20000); // cannon 1
//   outfitArray[6] = 100000 + randomNumber(100000); // cannon 2
//   outfitArray[7] = 5000000 + randomNumber(5000000); // cannon 3

//   if (percentile() > 70) {
//     outfitArray[8] = 1;
//     i = 1;
//   }

//   return i;
// }


int cargoLeft() {
  Debug.log("int cargoLeft()");
  return capacityArray[HS_SHIP_TYPE] + 100 * HS_UP_CARGO -
  HS_PLASMA - HS_DUTERIUM - HS_LATINUM - HS_WATER - HS_URANIUM;
}


/**
 * Dynamic commodity preview.
 * Returns last y coord printed at.
 */
int commodityPreview(int x, int y, int buying) {
  Debug.log("int commodityPreview(%d %d, %d)", x, y, buying);
  int increment, indexStart, compStart;
  int *array, *comparator;

  if (buying) {
    array = commerceArray;
    comparator = capacityArray;
    compStart = 46;
    increment = 2;
    indexStart = 0;
  } else {
    array = hudstats;
    comparator = commodityLastBuy;
    compStart = 0;
    increment = 1;
    indexStart = HS_I_PLASMA;
  }

  if (array[indexStart] > 0) {
    y = printAt(x, y, "Warp Plasma (%i/L) %s", commerceArray[1],
    printDealArrow(commerceArray[1], comparator[compStart], buying));
  }
  indexStart += increment;
  compStart++;
  if (array[indexStart] > 0) {
    y = printAt(x, y, "Duterium (%i/kg) %s", commerceArray[3],
    printDealArrow(commerceArray[3], comparator[compStart], buying));
  }
  indexStart += increment;
  compStart++;
  if (array[indexStart] > 0) {
    y = printAt(x, y, "Latinum (%i/kg) %s", commerceArray[5],
    printDealArrow(commerceArray[5], comparator[compStart], buying));
  }
  indexStart += increment;
  compStart++;
  if (array[indexStart] > 0) {
    y = printAt(x, y, "Water (%i/L) %s", commerceArray[7],
    printDealArrow(commerceArray[7], comparator[compStart], buying));
  }
  indexStart += increment;
  compStart++;
  if (array[indexStart] > 0) {
    y = printAt(x, y, "Uranium Ore (%i/kg) %s", commerceArray[9],
    printDealArrow(commerceArray[9], comparator[compStart], buying));
  }

  return y;
}


void buildCommerceMenu(Menu *main, Menu *buy, Menu *sell) {
  Debug.log("void buildCommerceMenu(menus)");
  int i, j = 1;
  main->addOption("0: Back");
  buy->addOption("0: Back");
  sell->addOption("0: Back");

  i = 1;
  if (commerceArray[0] == 1) {
    buy->addOption("%i: Warp Plasma (%i/L) %s", i++, commerceArray[1],
    printDealArrow(commerceArray[1], CAP_AVGPLASMA, 1));
  }
  if (commerceArray[2] == 1) {
    buy->addOption("%i: Duterium (%i/kg) %s", i++, commerceArray[3],
    printDealArrow(commerceArray[3], CAP_AVGDUTERIUM, 1));
  }
  if (commerceArray[4] == 1) {
    buy->addOption("%i: Latinum (%i/kg) %s", i++, commerceArray[5],
    printDealArrow(commerceArray[5], CAP_AVGLATINUM, 1));
  }
  if (commerceArray[6] == 1) {
    buy->addOption("%i: Water (%i/L) %s", i++, commerceArray[7],
    printDealArrow(commerceArray[7], CAP_AVGWATER, 1));
  }
  if (commerceArray[8] == 1) {
    buy->addOption("%i: Uranium Ore (%i/kg) %s", i++, commerceArray[9],
    printDealArrow(commerceArray[9], CAP_AVGURANIUM, 1));
  }
  if (i > 1) {
    main->addOption("%d: Buy", j++);
  }

  i = 1;
  if (HS_PLASMA > 0) {
    sell->addOption("%i: Warp Plasma (%i/L) %s", i++, commerceArray[1],
    printDealArrow(commerceArray[1], LASTBUY_PLASMA, 0));
  }
  if (HS_DUTERIUM > 0) {
    sell->addOption("%i: Duterium (%i/kg) %s", i++, commerceArray[3],
    printDealArrow(commerceArray[3], LASTBUY_DUTERIUM, 0));
  }
  if (HS_LATINUM > 0) {
    sell->addOption("%i: Latinum (%i/kg) %s", i++, commerceArray[5],
    printDealArrow(commerceArray[5], LASTBUY_LATINUM, 0));
  }
  if (HS_WATER > 0) {
    sell->addOption("%i: Water (%i/L) %s", i++, commerceArray[7],
    printDealArrow(commerceArray[7], LASTBUY_WATER, 0));
  }
  if (HS_URANIUM > 0) {
    sell->addOption("%i: Uranium Ore (%i/kg) %s", i++, commerceArray[9],
    printDealArrow(commerceArray[9], LASTBUY_URANIUM, 0));
  }
  Debug.log("done adding menu items");
  main->addOption("%d: Sell", j++);
}


void getMenuCommodity(char *opt, int *price, int *index) {
  Debug.log("void getMenuCommodity(%s, %d, %d)", opt, *price, *index);
  if (strstr(opt, "Plasma")) {
    *price = commerceArray[1];
    *index = HS_I_PLASMA;
  } else if (strstr(opt, "Duterium")) {
    *price = commerceArray[3];
    *index = HS_I_DUTERIUM;
  } else if (strstr(opt, "Latinum")) {
    *price = commerceArray[5];
    *index = HS_I_LATINUM;
  } else if (strstr(opt, "Water")) {
    *price = commerceArray[7];
    *index = HS_I_WATER;
  } else if (strstr(opt, "Uranium")) {
    *price = commerceArray[9];
    *index = HS_I_URANIUM;
  }
  Debug.log("return getMenuCommodity(%s, %d, %d)", opt, *price, *index);

  return;
}


void rebuildCommerceMenus(Menu *menu, Menu *buyMenu, Menu *sellMenu) {
  Debug.log("void rebuildCommerceMenus(menus)");
  int m = Math.max(menu->highlighted, 0);
  int b = Math.max(buyMenu->highlighted, 0);
  int s = Math.max(sellMenu->highlighted, 0);
  menu->destruct();
  buyMenu->destruct();
  sellMenu->destruct();

  buildCommerceMenu(menu, buyMenu, sellMenu);
  menu->highlighted = m;
  buyMenu->highlighted = b;
  sellMenu->highlighted = Math.min(s, sellMenu->length - 1);
}


void commerceMenu() {
  Debug.log("void commerceMenu()");
  int choice, price, hudstat;
  double quantity;

  Menu menu = Menu(PLANET_MENU_START);
  Menu buyMenu = Menu(PLANET_MENU_START);
  Menu sellMenu = Menu(PLANET_MENU_START);
  buildCommerceMenu(&menu, &buyMenu, &sellMenu);

  planetHUD();
  printAt(PLANET_MENU_HEADER, "Commercial sector:");
  do {
    choice = menu.getInput();
    planetHUD();
    printAt(PLANET_MENU_HEADER, "Commercial sector:");

    if (menu.isHighlighted("Buy")) {
      commodityPreview(3, 10, 1);
      if (choice == KEY_RETURN || (choice > -1 &&
      choice == menu.optionIndex("Buy"))) {
        planetHUD();
        do {
          planetWindow();
          printAt(PLANET_MENU_HEADER, "Buy commodities:");
          choice = buyMenu.getSelection();

          if (!buyMenu.isHighlighted("Back")) {
            comLog(COM_BELOW_PLANET_HUD);
            printf("Purchase how many units: ");
            scanf("%lf", &quantity);
            clean();
            getMenuCommodity(buyMenu.options[buyMenu.highlighted],
            &price, &hudstat);
            if (tryToBuy(quantity, price, hudstat)) {
              commodityLastBuy[hudstat - HS_I_PLASMA] = price;
              minimalHUD(HUD_MINIMAL_START);
              rebuildCommerceMenus(&menu, &buyMenu, &sellMenu);
            }
            choice = -1;
          }
        } while (!((buyMenu.isHighlighted("Back") && choice == KEY_RETURN) ||
        choice == 0));
        choice = -1;
        planetHUD();
        printAt(PLANET_MENU_HEADER, "Commercial sector:");
        commodityPreview(3, 10, 1);
      }
    } else if (menu.isHighlighted("Sell")) {
      commodityPreview(3, 10, 0);
      if (choice == KEY_RETURN || (choice > -1 &&
      choice == menu.optionIndex("Sell"))) {
        planetHUD();
        do {
          planetWindow();
          printAt(PLANET_MENU_HEADER, "Sell commodities:");
          choice = sellMenu.getSelection();

          if (!sellMenu.isHighlighted("Back")) {
            comLog(COM_BELOW_PLANET_HUD);
            printf("Sell how many units: ");
            scanf("%lf", &quantity);
            clean();
            getMenuCommodity(sellMenu.options[sellMenu.highlighted],
            &price, &hudstat);
            if (tryToSell(quantity, price, hudstat)) {
              minimalHUD(HUD_MINIMAL_START);
              rebuildCommerceMenus(&menu, &buyMenu, &sellMenu);
              planetWindow();
              choice = -1;
            }
          }
        } while (!((sellMenu.isHighlighted("Back") && choice == KEY_RETURN) ||
        choice == 0));
        choice = -1;
        planetHUD();
        printAt(PLANET_MENU_HEADER, "Commercial sector:");
        commodityPreview(3, 10, 0);
      }
    }
  } while (!((menu.isHighlighted("Back") && choice == KEY_RETURN) ||
  choice == 0));
}


static char* printBuySell(char buySell, int commodity, int quantity, int costProfit, int shipCost) {
  Debug.log("static char* printBuySell(%c, %d, %d, %d, %d)", buySell, commodity, quantity, costProfit, shipCost);
  char unit;
  static char buffer[BUFFER_MEDIUM] = {0};
  switch (commodity) {
  case HS_I_PLASMA:
  case HS_I_WATER:
    unit = 'L';
    break;
  case HS_I_DUTERIUM:
  case HS_I_LATINUM:
  case HS_I_URANIUM:
    unit = 'g';
    break;
  case HS_I_HULL:
  case HS_I_ENERGY:
  case HS_I_TORPEDOS:
  default:
    unit = 'n';
    break;
  }

  if (commodity == HS_I_WEAPONS && buySell == 'b') {
    snprintf(buffer, BUFFER_MEDIUM - 1, "You bought a class %i cannon for %s credits.",
    quantity, prefix(costProfit, 'n'));
    return buffer;
  }
  if (commodity == HS_I_WEAPONS && buySell == 's') {
    snprintf(buffer, BUFFER_MEDIUM - 1, "You sold your class %i cannon for %s credits.",
    quantity, prefix(costProfit, 'n'));
    return buffer;
  }
  if (commodity == HS_I_SHIP_TYPE) {
    snprintf(buffer, BUFFER_MEDIUM, "You sold your %s and bought a %s for %s credits.",
    shipName(quantity), shipName(costProfit), prefix(shipCost, 'n'));
    return buffer;
  }

  char desc[128] = {0}, item[128] = {0}, profit[128] = {0};
  if (buySell == 's' && quantity != 0) {
    snprintf(desc, 127, "You sold %s", prefix(quantity, unit));
  }
  if (buySell == 's' && quantity == 0) {
    snprintf(desc, 127, "You did not sell any ");
  }
  if (buySell == 'b' && quantity != 0) {
    snprintf(desc, 127, "You bought %s", prefix(quantity, unit));
  }
  if (buySell == 'b' && quantity == 0) {
    snprintf(desc, 127, "You did not purchase any ");
  }
  if (commodity == HS_I_PLASMA) {
    if (quantity != 0) {
      snprintf(item, 127, " of Warp Plasma.");
    } else {
      snprintf(item, 127, "Warp Plasma");
    }
  }
  if (commodity == HS_I_DUTERIUM) {
    if (quantity != 0) {
      snprintf(item, 127, " of Duterium.");
    } else {
      snprintf(item, 127, "Duterium");
    }
  }
  if (commodity == HS_I_LATINUM) {
    if (quantity != 0) {
      snprintf(item, 127, " of Latinum.");
    } else {
      snprintf(item, 127, "Latinum");
    }
  }
  if (commodity == HS_I_WATER) {
    if (quantity != 0) {
      snprintf(item, 127, " of Water.");
    } else {
      snprintf(item, 127, "Water");
    }
  }
  if (commodity == HS_I_URANIUM) {
    if (quantity != 0) {
      snprintf(item, 127, " of Uranium Ore.");
    } else {
      snprintf(item, 127, "Uranium Ore");
    }
  }
  if (commodity == HS_I_HULL) {
    if (quantity != 0) {
      snprintf(item, 127, " hours of hull repairs.");
      HS_DATE += quantity / 24;
    } else {
      snprintf(item, 127, "hull repairs.");
    }
  }
  if (commodity == HS_I_ENERGY) {
    if (quantity != 0) {
      snprintf(item, 127, " hours of energy cell replacements.");
      HS_DATE += quantity / 24;
    } else {
      if (commodity == HS_I_ENERGY && quantity == 0) {
        snprintf(item, 127, "energy cell replacements.");
      }
    }
  }
  if (commodity == HS_I_TORPEDOS) {
    if (quantity != 0) {
      snprintf(item, 127, " torpedos.");
    } else {
      snprintf(item, 127, "torpedos.");
    }
  }

  if (buySell == 's' && quantity != 0) {
    snprintf(profit, 127, "\nYou made %s credits.", prefix(costProfit, 'n'));
  }
  if (buySell == 'b' && quantity != 0) {
    snprintf(profit, 127, "\nYou paid %s credits.",
    prefix(quantity * costProfit, 'n'));
  }
  snprintf(buffer, 1027, "%s%s%s", desc, item, profit);

  comLog(COM_BELOW_PLANET_HUD);
  printLinesAt(COM_BELOW_PLANET_HUD_START, buffer);

  return buffer;
}


int initCommerce() {
  Debug.log("int initCommerce()");
  int i;
  if (percentile() > 20) {
    commerceArray[0] = 1;
    i = 1;
  }
  commerceArray[1] = 5 + randomNumber(15);
  if (percentile() > 30) {
    commerceArray[2] = 1;
    i = 1;
  }
  commerceArray[3] = 20 + randomNumber(30);
  if (percentile() > 40) {
    commerceArray[4] = 1;
    i = 1;
  }
  commerceArray[5] = 70 + randomNumber(30);
  if (percentile() > 50) {
    commerceArray[6] = 1;
    i = 1;
  }
  commerceArray[7] = 350 + randomNumber(150);
  if (percentile() > 75) {
    commerceArray[8] = 1;
    i = 1;
  }
  commerceArray[9] = 700 + randomNumber(300);

  return i;
}


const char* shipClass(int shipType) {
  Debug.log("const char* shipClass(%d)", shipType);
  switch (shipType) {
  case 1:
    return "P";
  case 2:
    return "F";
  case 3:
    return "F";
  case 4:
    return "C";
  case 5:
    return "C";
  default:
    return "E";
  }
}


const char* shipName(int shipType) {
  Debug.log("const char* shipName(%d)", shipType);
  switch (shipType) {
  case 1:
    return "Shuttle (P)";
    break;
  case 2:
    return "Cargo Drone (F)";
    break;
  case 3:
    return "Freighter (F)";
    break;
  case 4:
    return "Frigate (C)";
    break;
  case 5:
    return "Destroyer (C)";
    break;
  default:
    return "Escape Pod";
    break;
  }
}


/*int initShips() {
  Debug.log("int initShips()");
  int i = 0;
  if (percentile() > 20) {
    shipArray[0] = 1;
    shipArray[1] = 10000 + randomNumber(1000);
    i = 1;
  }
  if (percentile() > 40) {
    shipArray[2] = 1;
    shipArray[3] = 100000 + randomNumber(10000);
    i = 1;
  }
  if (percentile() > 60) {
    shipArray[4] = 1;
    shipArray[5] = 1000000 + randomNumber(100000);
    i = 1;
  }
  if (percentile() > 80) {
    shipArray[6] = 1;
    shipArray[7] = 10000000 + randomNumber(10000000);
    i = 1;
  }
  if (percentile() > 90) {
    shipArray[8] = 1;
    shipArray[9] = 100000000 + randomNumber(100000000);
    i = 1;
  }

  return i;
}*/


int checkCapacity(int hudstat, int quantity, int ship) {
  Debug.log("int checkCapacity(%d, %d, %d)", hudstat, quantity, ship);
  int capacity = hudstatToCapacity(hudstat);

  switch(hudstat) {
    case HS_I_SHIELD:
    case HS_I_HULL:
    case HS_I_ENERGY:
    case HS_I_TORPEDOS:
      if (quantity + hudstats[hudstat] < capacity) {
        return 1;
      }
      break;
    case HS_I_PLASMA:
    case HS_I_DUTERIUM:
    case HS_I_LATINUM:
    case HS_I_WATER:
    case HS_I_URANIUM:
      if (quantity + HS_PLASMA + HS_DUTERIUM + HS_LATINUM + HS_WATER + HS_URANIUM +
      100 * HS_UP_CARGO <= capacityArray[ship]) {
        return 1;
      }
      break;
    default:
      return 0;
  }

  return 0;
}


void shipInfo(int ship) {
  Debug.log("void shipInfo(%d)", ship);
  int x = 3, y = 12;
  const char *sfmt = "%-30s%-16s%s";
  const char *ifmt = "%-30s%-16d%d";
  y = printAt(x, y, sfmt, "Ship stats:", shipName(ship), "Your ship");
  y = printAt(x, y, ifmt, "Shield Power:",
  capacityArray[10 + ship], capacityArray[10 + HS_SHIP_TYPE]);
  y = printAt(x, y, ifmt, "Hull Strength:", capacityArray[20 + ship],
  capacityArray[20 + HS_SHIP_TYPE]);
  y = printAt(x, y, ifmt, "Battery Charge:", capacityArray[30 + ship],
  capacityArray[30 + HS_SHIP_TYPE]);
  y = printAt(x, y, ifmt, "Torpedo Bay Capacity:", capacityArray[40 + ship],
  capacityArray[40 + HS_SHIP_TYPE]);
  y = printAt(x, y, ifmt, "Cargo Hold Capacity:", capacityArray[ship],
  capacityArray[HS_SHIP_TYPE]);
  y = printAt(x, y, ifmt, "Turret Hardpoints:", capacityArray[5 + ship],
  capacityArray[5 + HS_SHIP_TYPE]);
  y = printAt(x, y, "Current Ship Value: %s", prefix(resaleValue(), 'n'));
  y = printAt(x, y, "Cost before resale: %s",
  prefix(shipArray[ship * 2 - 1], 'n'));
  y = printAt(x, y, "Total Cost: %s",
  prefix(Math.max(shipArray[ship * 2 - 1] - resaleValue(), 0), 'n'));
}


int resaleValue() { // torps???????!?!?!?
  Debug.log("int resaleValue()");
  int guns = 0, i, upgrades;
  float shipCondition;
  upgrades = 50000 * (HS_UP_DMG + HS_UP_RANGE) + 125000 *
  (HS_UP_HULL + HS_UP_SHIELD) + 75000 * HS_UP_CARGO + 250000 * HS_UP_TORP;
  shipCondition = (HS_SHIELD + HS_HULL + HS_ENERGY) / (
  capacityArray[HS_SHIP_TYPE + 10] + capacityArray[HS_SHIP_TYPE + 20] +
  capacityArray[HS_SHIP_TYPE + 30]);

  if (ACHIEVE_SHIPS != 1) {
    for (i = 1; i <= 5; i++) {
      guns += (hudstats[HS_I_ENEMY_LOC + i] == 1) ? outfitArray[5] : 0;
      guns += (hudstats[HS_I_ENEMY_LOC + i] == 2) ? outfitArray[6] : 0;
      guns += (hudstats[HS_I_ENEMY_LOC + i] == 3) ? outfitArray[7] : 0;
    }
    return ((shipCondition * shipArray[2 * HS_SHIP_TYPE - 1] / 4) +
    shipArray[2 * HS_SHIP_TYPE - 1] / 4 + guns / 2 + upgrades +
    (HS_TORPEDOS * outfitArray[4]) / 2);
  }

  return ((shipCondition * shipArray[2 * HS_SHIP_TYPE - 1] / 4) +
  shipArray[2 * HS_SHIP_TYPE - 1] / 4);
}


void enemyMovement() {
  Debug.log("void enemyMovement()");
  int xDistance, yDistance, tileUnderEnemy;
  int enX, enY, plX, plY;

  enX = EN_POS % 10;
  enY = EN_POS / 10;
  plX = HS_SYS_X - 1;
  plY = HS_SYS_Y - 1;
  xDistance = abs(enX - plX);
  yDistance = abs(enY - plY);

  if (xDistance >= yDistance) {
    if (enX < plX && getMapTile(EN_POS + 1, MAP_TYPE_SYSTEM) != 'P') {
      tileUnderEnemy = EN_TILE;
      EN_TILE = getMapTile(EN_POS + 1, MAP_TYPE_SYSTEM);
      systemMap[EN_POS + 1] = EN_SHIP_TYPE;
      systemMap[EN_POS] = tileUnderEnemy;
      EN_POS = EN_POS + 1;
    }
    if (enX > plX && getMapTile(EN_POS - 1, MAP_TYPE_SYSTEM) != 'P') {
      tileUnderEnemy = EN_TILE;
      EN_TILE = getMapTile(EN_POS - 1, MAP_TYPE_SYSTEM);
      systemMap[EN_POS - 1] = EN_SHIP_TYPE;
      systemMap[EN_POS] = tileUnderEnemy;
      EN_POS = EN_POS - 1;
    }
  } else {
    if (enY < plY && getMapTile(EN_POS + 10, MAP_TYPE_SYSTEM) != 'P') {
      tileUnderEnemy = EN_TILE;
      EN_TILE = getMapTile(EN_POS + 10, MAP_TYPE_SYSTEM);
      systemMap[EN_POS + 10] = EN_SHIP_TYPE;
      systemMap[EN_POS] = tileUnderEnemy;
      EN_POS = EN_POS + 10;
    }
    if (enY > plY && getMapTile(EN_POS - 10, MAP_TYPE_SYSTEM) != 'P') {
      tileUnderEnemy = EN_TILE;
      EN_TILE = getMapTile(EN_POS - 10, MAP_TYPE_SYSTEM);
      systemMap[EN_POS - 10] = EN_SHIP_TYPE;
      systemMap[EN_POS] = tileUnderEnemy;
      EN_POS = EN_POS - 10;
    }
  }
}


void scan(int playerScanning, int ship, int rangeScan) {
  Debug.log("void scan(%d, %d, %d)", playerScanning, ship, rangeScan);
  int i;
  int range = rangeCheck(1, 1);
  // F can scan shields/hull, C weaps, range, P no scans
  // 2 = none, 1 = limited, 0 = out of range, 3 = in range
  if (playerScanning == SCAN_PLAYER_RANGE) {
    comLog(COM_BELOW_MAP); //51
    if (HS_WEAPONS == 0) {
      printf("You have no weapons.");
    } else if (HS_SECURITY == SECURITY_SAFE) {
      printf("No enemies nearby.");
    } else {
      if (HS_IN_RANGE == 0) {
        printf("Hostile Out of Range.");
      } else {
        printf("Hostile In Range.");
      }
      if (range != 0) {
        printf("Potential Damage Output: %i", range);
      }
    }

    if (HS_DEPLETION == 1 && HS_SECURITY != 1 && HS_WEAPONS != 0) {
      printf("Limited energy available.");
    } else if (HS_DEPLETION == 2 && HS_SECURITY != 1 && HS_WEAPONS != 0) {
      printf("Insufficient energy available.");
    }

    if (rangeScan) {
      printMap(MAP_TYPE_SYSTEM, playerScanning);
    }
  }

  if (playerScanning == SCAN_ENEMY_RANGE) {
    comLog(COM_BELOW_MAP); //51
    if (EN_SHIP_TYPE > 0 && EN_SHIP_TYPE < 6) {
      if (ship == 0 || ship == 1) {
        printf("No scanning capabilities in this ship.");
        printMap(MAP_TYPE_SYSTEM, SCAN_TYPE_NONE);
        return;
      }

      if (ship == 2 || ship == 3) {
        printf("Shield:%i Hull:%i", EN_SHIELD, EN_HULL);
      }
      if (ship == 4 || ship == 5) {
        printf("Gun Types: ");
        for (i = EN_I_WEAPON1; i <= EN_SHIP_TYPE + 2; i++) {
          if (enemyArray[i] != 0) {
            printf("%i ", enemyArray[i]);
          }
        }
        printf("Shield Power:%i\tHull Strength:%i", EN_SHIELD, EN_HULL);
      }
      printf("Potential Damage Output: %i", rangeCheck(2, 1));
      if (rangeCheck(2, 1) == 0) {
        printf("Out of Range.");
      } else {
        printf("In Range."); // 8, 9
      }
      printMap(MAP_TYPE_SYSTEM, playerScanning);
    } else {
      printf("No hostiles to scan.");
    }
  }
}


/**
 *  TODO refactor
 */
int rangeCheck(int scanTarget, int scans) {
  Debug.log("int rangeCheck(%d, %d)", scanTarget, scans);
  int i, xDifference, yDifference, damage = 0, energyDepletion = 0,
  track1 = 0, track2 = 0, track3 = 0;
  int ranges[3] = {0};
  int weaponStart;
  int *weaponArray;
  float distance;

  HS_DEPLETION = 0;
  HS_IN_RANGE = 0;

  if (scanTarget == SCAN_PLAYER_RANGE) {
    weaponArray = hudstats;
    weaponStart = HS_I_WEAPON1;
  } else {
    weaponArray = enemyArray;
    weaponStart = EN_WEAPON1;
  }

  for (i = 1; i <= 5; i++) {
    if (weaponArray[weaponStart + i - 1] != 0) {
      ranges[weaponArray[weaponStart + i - 1] - 1]++;
    }
  }

  xDifference = pow((double)(EN_POS % 10 - (HS_SYS_X - 1)), 2);
  yDifference = pow((double)(EN_POS / 10 - (HS_SYS_Y - 1)), 2);
  distance = Math.round(sqrt(xDifference + yDifference));

  if (scanTarget == SCAN_PLAYER_RANGE) {
    if (distance <= 3 + HS_UP_RANGE) {
      HS_IN_RANGE += ranges[0];
    }
    if (distance <= 5 + HS_UP_RANGE) {
      HS_IN_RANGE += ranges[1];
    }
    if (distance <= 7 + HS_UP_RANGE) {
      HS_IN_RANGE += ranges[2];
    }
    energyDepletion += 10 * ranges[0];
    energyDepletion += 50 * ranges[1];
    energyDepletion += 100 * ranges[2];
    if (energyDepletion > HS_ENERGY) {
      // Calculate max dmg with remaining energy - TODO refactor
      energyDepletion = HS_ENERGY;
      for (i = 0; i < 5; i++) {
        if (energyDepletion >= 100 * (ranges[2] - i) && (ranges[2] - i) > 0 &&
        track1 == 0) {
          damage += (ranges[2] - i) * 100;
          energyDepletion -= (ranges[2] - i) * 100;
          HS_DEPLETION += energyDepletion;
          track1 = 1;
        }
      }
      for (i = 0; i < 5; i++) {
        if (energyDepletion >= 50 * (ranges[1] - i) && (ranges[1] - i) > 0 &&
        track2 == 0) {
          damage += (ranges[1] - i) * 50;
          energyDepletion -= (ranges[1] - i) * 50;
          HS_DEPLETION += energyDepletion;
          track2 = 1;
        }
      }
      for (i = 0; i < 5; i++) {
        if (energyDepletion >= 10 * (ranges[0] - i) && (ranges[0] - i) > 0 &&
        track3 == 0) {
          damage += (ranges[0] - i) * 30;
          energyDepletion -= (ranges[0] - i) * 10;
          HS_DEPLETION += energyDepletion;
          track3 = 1;
        }
      }
      if (scans == SCAN_TYPE_NONE) {
        HS_ENERGY = energyDepletion;
      }
      HS_DEPLETION = (scans == SCAN_TYPE_RANGE) ?
      (track1 == 0 && track2 == 0 && track3 == 0) ? 2 : 1 : HS_DEPLETION;
    }
  } else {
    if (distance <= 3) {
      damage += 30 * ranges[0];
    } // 0 = fire, 1 = scan, 2 = info
    if (distance <= 5) {
      damage += 50 * ranges[1];
    }
    if (distance <= 7) {
      damage += 100 * ranges[2];
    }
    if (scans == 0) {
      HS_ENERGY -= energyDepletion;
    } // 1 = none 2 = lim
  }
  if (damage != 0) {
    damage += HS_UP_DMG * 10;
  }
  if (scans == SCAN_TYPE_DEPLETION) {
    HS_DEPLETION = 10 * ranges[0] + 50 * ranges[1] + 100 * ranges[2];
    damage = 30 * ranges[0] + 50 * ranges[1] + 100 * ranges[2];
  }
  HS_IN_RANGE = (scans == SCAN_TYPE_DEPLETION) ? (ranges[2] != 0) ? 7 :
  (ranges[1] != 0) ? 5 : (ranges[0] != 0) ? 3 : 0 : HS_IN_RANGE;

  if (scanTarget == SCAN_PLAYER_RANGE) {
    if (distance <= 3) {
      damage += 30 * ranges[0];
    }
    if (distance <= 5) {
      damage += 50 * ranges[1];
    }
    if (distance <= 7) {
      damage += 100 * ranges[2];
    }
  }
  return damage;
}


void fire(int playerFiring) {
  Debug.log("void fire(%d)", playerFiring);
  int damage, crit;
  comLog(COM_BELOW_MAP); //51
  if (HS_SECURITY == 1) {
// gotoXY(52, 27);printf("There are no hostiles to shoot at.");
    return;
  }
  if (rangeCheck(playerFiring, 1) != 0) {
    //randomNumber(100); randomNumber(100); randomNumber(100);
    if (percentile() < 10 && rangeCheck(playerFiring, 1) != 0) {
      if (playerFiring == 1) {
        printf("You miss. ");
      } else {
        printf("Enemy misses.");
      }
      rangeCheck(playerFiring, 0);
      return;
    }
    damage = rangeCheck(playerFiring, 1);
    damage *= (playerFiring == 2) ? 0.9 : 1;
    damage -= damage / 10 + randomNumber(damage / 5);
    crit = percentile();
    if (crit >= 95 && rangeCheck(playerFiring, 1) != 0) {
      damage *= 2;
      if (playerFiring == 1) {
        printf("You hit a critical system! ");
      } else {
        printf("Enemy hits a critical system! ");
      }
    }
    if (crit < 95 && rangeCheck(playerFiring, 1) != 0) {
      if (playerFiring == 1) {
        printf("You hit. ");
      } else {
        printf("Enemy hits. ");
      }
      if (playerFiring == 1) {
        hitAnim(2);
      } else {
        hitAnim(1);
      }
    }
    if (damage != 0) {
      rangeCheck(playerFiring, 0);
      printfLinesAt(COM_BELOW_MAP_START, "\n%i damage was done.\n", damage);
    }
    damageReport(damage, playerFiring);
  }
}


void firetorpedo() {
  Debug.log("void firetorpedo()");
  int damage = 0, xDifference, yDifference;
  float distance = 0;
  comLog(COM_BELOW_MAP); //51
  if (HS_TORPEDOS == 0) {
    printf("You have no torpedos to fire.");
    return;
  }
  xDifference = pow((double)(EN_POS % 10 - (HS_SYS_X - 1)), 2);
  yDifference = pow((double)(EN_POS / 10 - (HS_SYS_Y - 1)), 2);
  distance = Math.round(sqrt(xDifference + yDifference));
  damage = 50 - 3 * randomNumber((int)distance) +
  2 * randomNumber((int)distance) + 20 * HS_UP_TORP;

  if (percentile() < 2 * (int)distance) {
    printf("Torpedo missed.");
    HS_TORPEDOS--;
    return;
  } else {
    if (percentile() > 95) {
      printf("Torpedo hits critical systems.");
      damage *= 2;
    } else {
      printf("Torpedo hits.");
    }
    printf("Enemy takes %i damage.", damage);
    if (distance < 2) {
      printf(" You take %i splash damage.", damage / 2);
      damageReport(damage / 2, 2);
    }
    damageReport(damage, 1);
  }

  HS_TORPEDOS--;
}


void damageReport(int damage, int player) {
  Debug.log("void damageReport(%d, %d)", damage, player);
  // hull:2[29] shields:1[30]
  if (player == 2) {
    // shields down
    if (damage - 10 * HS_UP_SHIELD > HS_SHIELD) {
      // death
      if (damage - HS_SHIELD - 10 * HS_UP_HULL >= HS_HULL) {
        printf("Your ship was destroyed.");
        shipDestroyed();
        return;
      }
      // hull damage
      if (damage - HS_SHIELD - 10 * HS_UP_HULL < HS_HULL) {
        HS_HULL -= damage - HS_SHIELD - 10 * HS_UP_HULL;
        HS_SHIELD = 0;
        return;
      }
    }
    // shields damaged
    if (damage - 10 * HS_UP_SHIELD <= HS_SHIELD) {
      HS_SHIELD -= damage - 10 * HS_UP_SHIELD;
      return;
    }
  }
  // hull:9 shields:8
  if (player == 1) {
    // shields down
    if (damage > EN_SHIELD) {
      // death
      if (damage - EN_SHIELD >= EN_HULL) {
        EN_SHIELD = 0;
        EN_HULL = 0;
        printf("The enemy ship was destroyed.");
        ACHIEVE_KILLS++;
        HS_SECURITY = 1;
        initEnemy(1);
        return;
      }
      // hull damage
      if (damage - EN_SHIELD < EN_HULL) {
        EN_HULL -= damage - EN_SHIELD;
        EN_SHIELD = 0;
        return;
      }
    }
    // shields damaged
    if (damage <= EN_SHIELD) {
      EN_SHIELD -= damage;
      return;
    }
  }
}


// 3, 5, 9
static char* hudColours(int currentHud, int maxHud) {
  Debug.log("static char* hudColours(%d, %d)", currentHud, maxHud);
  const char *fmt = "%s%i"STR_COL_WHITE"/%i";
  static char msg[BUFFER_MEDIUM] = {0};
  // memset(msg, 0, BUFFER_MEDIUM);

  if (HS_SHIP_TYPE == SHIP_ESCAPE_POD) {
    return (char*)"---";
  }

  if (maxHud != 0) {
    int percent = currentHud * 100 / maxHud;
    if (percent == 100) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_WHITE, currentHud, maxHud);
    } else if (percent > 75) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_GREEN, currentHud, maxHud);
    } else if (percent > 50) {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_YELLOW, currentHud, maxHud);
    } else {
      snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_RED, currentHud, maxHud);
    }
  } else {
    snprintf(msg, BUFFER_MEDIUM - 1, fmt, STR_COL_WHITE, currentHud, maxHud);
  }

  return msg;
}


int initEnemy(int died) {
  Debug.log("int initEnemy(%d)", died);
  int location = EN_POS;
  int ship = EN_SHIP_TYPE + 5 * died;
  int tile = EN_TILE;

  memset(enemyArray, EN_I_SIZE, 0);
  EN_TILE = tile;
  if (died) {
    systemMap[location] = ship;
    EN_SHIP_TYPE = ship;
    EN_POS = location;
  }
  return 0;
}


// 1, 2, 8, 9, 11, 12, 13, 14, 15, 19, 21-26, 27-32
void shipDestroyed() {
  Debug.log("void shipDestroyed()");
  int i;
  ACHIEVE_SHIPS++;
  HS_SHIELD = 0;
  HS_HULL = 0;
  HS_ENERGY = 0;
  HS_TORPEDOS = 0;
  HS_SECURITY = 1;
  for (i = 11; i < 16; i++) {
    hudstats[i] = 0;
  }
  HS_SHIP_TYPE = 0;
  for (i = 21; i < 33; i++) {
    hudstats[i] = 0;
  }
}


// s1 e8 // cap 10
void divertPower(int quantity) {
  Debug.log("void divertPower(%d)", quantity);
  int diverted = 0;
  comLog(COM_BELOW_MAP); //51
  // less energy than asked
  if (HS_ENERGY < quantity) {
    // enough energy to charge shield
    if (capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD <= HS_ENERGY) {
      diverted = capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD;
      HS_ENERGY -= capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD;
      HS_SHIELD = capacityArray[10 + HS_SHIP_TYPE];
      printf("%i power was diverted to shields.", diverted);
      gotoXY(52, 28);
      printf("Shields Full.");
    } else  {
      // take all energy avail
      diverted = HS_ENERGY;
      HS_SHIELD += HS_ENERGY;
      HS_ENERGY = 0;
      printf("%i power was available.", diverted);
      gotoXY(52, 28);
      printf("Shields Increased.");
    }
  } else {
    // energy > asked
    // less energy than shield
    if (capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD > quantity) {
      diverted = quantity;
      HS_ENERGY -= quantity;
      HS_SHIELD += quantity;
      printf("%i power was diverted to shields.", diverted);
      gotoXY(52, 28);
      printf("Shields Increased.");
    } else {
      // more energy than shield
      diverted = capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD;
      HS_ENERGY -= capacityArray[10 + HS_SHIP_TYPE] - HS_SHIELD;
      HS_SHIELD = capacityArray[10 + HS_SHIP_TYPE];
      printf("%i power was diverted to shields.", diverted);
      gotoXY(52, 28);
      printf("Shields Full.");
    }
  }
}


void loot() {
  Debug.log("void loot()");
  int lootCount = 0;
  int foundLoot = 0;
  char str[BUFFER_MEDIUM] = {0};
  char *msg = str;
  int msgLen = 0;
  comLog(COM_BELOW_MAP);

  if (percentile() < 10 && HS_SHIP_TYPE != 0) {
    printLinesAt(COM_BELOW_MAP_START,
    "Aboard the vessel you found a pilot who claims they\n"
    "will pay you to bring them to the nearest planet.");
    systemMap[EN_POS] = EN_TILE;
    initEnemy(0);
    HS_PASSENGERS++;
    return;
  } else if (percentile() > 95 && HS_SHIP_TYPE != 0) {
    int damage = randomNumber(HS_SHIELD + HS_HULL + 10 * HS_SHIP_TYPE *
    (EN_SHIP_TYPE - 5));
    if (damage != 0) {
      printfLinesAt(COM_BELOW_MAP_START, "%s\n%i damage was done",
      "Boarding the vessel tripped a security protocol.", damage);
      damageReport(damage, 2);
    } else {
      printLinesAt(COM_BELOW_MAP_START,
      "Boarding the vessel tripped a security protocol.\n"
      "Fortunately the system was damaged and malfunctioned.");
    }
    systemMap[EN_POS] = EN_TILE;
    initEnemy(0);
    return;
  }

  // Credits
  if (percentile() > 50) {
    lootCount = 20 + randomNumber(100);
    if (EN_SHIP_TYPE == 7) {
      lootCount += randomNumber(500);
    }
    if (EN_SHIP_TYPE == 8) {
      lootCount += 500 + randomNumber(1000);
    }
    if (EN_SHIP_TYPE == 9) {
      lootCount += 1000 + randomNumber(5000);
    }
    if (EN_SHIP_TYPE == 10) {
      lootCount += 2000 + randomNumber(10000);
    }
    msgLen += snprintf(msg + msgLen, BUFFER_MEDIUM - msgLen,
    "%i Credits, ", lootCount);
    HS_CREDITS += lootCount;
    foundLoot = 1;
  }

  if (HS_SHIP_TYPE != 0) {
    // Commodities
    if (percentile() > 50) {
      int lootType = HS_I_PLASMA + randomNumber(4);
      lootCount =
      Math.min((EN_SHIP_TYPE - 5) * randomNumber(5), cargoLeft());

      if (lootCount) {
        msgLen += snprintf(msg + msgLen, BUFFER_MEDIUM - msgLen,
        "%d %s, ", lootCount, hudstatToCommodity(lootType));
        hudstats[lootType] += lootCount;
        foundLoot = 1;
      }
    }

    // Energy
    if (percentile() > 65 && HS_SHIP_TYPE != 1 && EN_SHIP_TYPE != 6) {
      lootCount = Math.min((EN_SHIP_TYPE - 5) * randomNumber(100),
      hudstatToCapacity(HS_I_ENERGY) - HS_ENERGY);

      if (lootCount) {
        msgLen += snprintf(msg + msgLen, BUFFER_MEDIUM - msgLen,
        "%d Power cells, ", lootCount);
        HS_ENERGY += lootCount;
        foundLoot = 1;
      }
    }

    // Hull
    if (percentile() > 70) {
      lootCount = Math.min((EN_SHIP_TYPE - 5) * (randomNumber(30)),
      hudstatToCapacity(HS_I_HULL) - HS_HULL);

      if (lootCount) {
        msgLen += snprintf(msg + msgLen, BUFFER_MEDIUM - msgLen,
        "%d Tritanium plating, ",lootCount);
        HS_HULL += lootCount;
        foundLoot = 1;
      }
    }

    // Torpedos
    if (percentile() > 85 && HS_SHIP_TYPE != 1 && HS_SHIP_TYPE != 0) {
      lootCount = Math.min(randomNumber(EN_SHIP_TYPE),
      hudstatToCapacity(HS_I_TORPEDOS) - HS_TORPEDOS);

      if (lootCount) {
        msgLen += snprintf(msg + msgLen, BUFFER_MEDIUM - msgLen,
        "%d Torpedos, ", lootCount);
        HS_TORPEDOS += lootCount;
        foundLoot = 1;
      }
    }
  }

  if (!foundLoot) {
    printf("No loot found.");
  } else {
    printfLinesAt(COM_BELOW_MAP_START, "%s\n%.*s",
    "You looted the vessel and found:", msgLen - 2, str);
  }

  systemMap[EN_POS] = EN_TILE;
  initEnemy(0);
}


void lootPrint(int number) {
  Debug.log("void lootPrint(%d)", number);
  switch (number) {
  case 1:
    gotoXY(52, 29);
    break;
  case 2:
    gotoXY(52, 30);
    break;
  case 3:
    gotoXY(52, 31);
    break;
  case 4:
    gotoXY(78, 29);
    break;
  case 5:
    gotoXY(78, 30);
    break;
  case 6:
    printf("Warp Plasma");
    break;
  case 7:
    printf("Duterium");
    break;
  case 8:
    printf("Latinum");
    break;
  case 9:
    printf("Water");
    break;
  case 10:
    printf("Uranium Ore");
    break;
  }
}


/**
 * TODO descriptive var names
 */
const char* printDealArrow(int price, int lastBuy, int buying) {
  Debug.log("const char* printDealArrow(%d, %d, %d)", price, lastBuy, buying);
  int cost, comparator;

  if (buying) {
    cost = price;
    comparator = lastBuy;
  } else {
    cost = lastBuy;
    comparator = price;
  }

  if (cost > comparator) {
    if (buying) {
      return STR_COL_RED">"STR_COL_WHITE;
    } else {
      return STR_COL_RED"<"STR_COL_WHITE;
    }
  }
  if (cost < comparator) {
    if (buying) {
      return STR_COL_GREEN"<"STR_COL_WHITE;
    } else {
      return STR_COL_GREEN">"STR_COL_WHITE;
    }
  }
  return STR_COL_YELLOW"="STR_COL_WHITE;
}


void barMenu() { // 1525
  Debug.log("void barMenu()");
  int choice;
  planetHUD();
  do {
    planetHUD();
    gotoXY(3, 5);
    printf("Bar:");
    gotoXY(3, 7);
    printf("1: Ship Logs");
    gotoXY(3, 8);
    printf("2: Achievements");
    gotoXY(3, 9);
    printf("3: Gamble");
    gotoXY(3, 27);
    printf("1-3: Select Passtime\t\t0: Back");
    gotoXY(3, 29);
    choice = getch() - '0';
    comLog(COM_BELOW_MAP); //66

    switch (choice) {
    case 1:
      if (HS_SHIP_TYPE != 0) {
        printLog();
      } else {
        comLog(COM_BELOW_MAP); //66
        printf("Ship logs not available in this vessel.");
      }
      break;
    case 2:
      achievementsMenu();
      break;
    case 3:
      gamblingMenu();
      break;
    default:
      if (choice != 0) {
        comLog(COM_BELOW_MAP); //66
        printf("Invalid selection.");
      }
    }
  } while (choice != 0);
  //gamble, crew?
}


void printLog() {
  Debug.log("void printLog()");
  int page = 1, choice, i, j, guns;
  do {
    planetHUD(); // max 24
    if (page == 1) {
      gotoXY(3, 5);
      printf("Ship Logs: Current as of %i.%i", HS_DATE / 10,
      HS_DATE % 10);
      gotoXY(3, 8);
      printf("General Information:");
      gotoXY(3, 10);
      printf("Exploration Logs:");
      gotoXY(3, 11);
      printf("\tTime in Space: %i day", HS_DATE - 407594);
      if (HS_DATE - 407594 > 1) {
        printf("s");
      }
      gotoXY(3, 12);
      printf("\tDistance Travelled: %i km", ACHIEVE_DISTANCE * 10);
      // in move - a[0]
      gotoXY(3, 13);
      printf("\tSystems Visited: %i", ACHIEVE_SYSTEMS);
      // in move - a[1]
      gotoXY(3, 14);
      printf("\tPlanets Visited: %i", ACHIEVE_PLANETS);
      // in planet menu
      gotoXY(3, 16);
      printf("Combat Logs:");
      gotoXY(3, 17);
      printf("\tShips Commanded: %i", ACHIEVE_SHIPS);
      // in outfitter
      gotoXY(3, 18);
      printf("\tWeapons Obtained: %i", ACHIEVE_WEAPONS);
      // outfit
      gotoXY(3, 19);
      printf("\tEnemies Ships Destroyed: %i", ACHIEVE_KILLS);
      // damagereport
      gotoXY(3, 20);
      printf("\tCombat Status: Legionnaire");
    }
    if (page == 2) {
      i = 0;
      gotoXY(3, 5);
      printf("Outfit Details:");
      gotoXY(3, 8);
      printf("Ship Class: Section %i ", HS_SHIP_TYPE);
      shipName(HS_SHIP_TYPE), printf(" Class");
      gotoXY(3, 10);
      printf("Armaments:");
      gotoXY(3, 11);
      printf("\tShip Hardpoints: %i", capacityArray[5 + HS_SHIP_TYPE]);
      if (HS_WEAPONS == 0) {
        gotoXY(3, 11 + i);
        printf("\tNo modules currently equipped.");
      } else {
        gotoXY(3, 11 + i);
        printf("\tCurrent installations: %i", HS_WEAPONS);
        guns = 0;
        for (j = 21; j < 26; j++) {
          if (hudstats[j] == 1) {
            guns++;
          }
        }
        if (guns != 0) {
          i++;
          gotoXY(3, 11 + i);
          printf("\t\t%i Class 1 type pulse cannon", guns);
          if (guns > 1) {
            printf("s.");
          } else {
            printf(".");
          }
        }
        guns = 0;
        for (j = 21; j < 26; j++) {
          if (hudstats[j] == 2) {
            guns++;
          }
        }
        if (guns != 0) {
          i++;
          gotoXY(3, 11 + i);
          printf("\t\t%i Class 2 type pulse cannon", guns);
          if (guns > 1) {
            printf("s.");
          } else {
            printf(".");
          }
        }
        guns = 0;
        for (j = 21; j < 26; j++) {
          if (hudstats[j] == 3) {
            guns++;
          }
        }
        if (guns != 0) {
          i++;
          gotoXY(3, 11 + i);
          printf("\t\t%i Class 3 type pulse cannon", guns);
          if (guns > 1) {
            printf("s.");
          } else {
            printf(".");
          }
        }
      }
      if (HS_WEAPONS != 0) {
        i++;
        gotoXY(3, 11 + i);
        rangeCheck(1, 2);
        printf("\tMaximum energy draw: %i MJ", HS_DEPLETION);
      }
      if (HS_WEAPONS != 0) {
        i++;
        gotoXY(3, 11 + i);
        printf("\tPotential damage output: %i", rangeCheck(1, 2));
      }
      if (HS_SHIP_TYPE != 1) {
        i++;
        gotoXY(3, 11 + i);
        printf("\tStandard Sigma Shipyards torpedo bays: %i",
        HS_SHIP_TYPE - 1);
      }
    }
    if (page == 3) {
      //armour pierce+10, carbonalloy+10, tritaniumhullstruts+10,
      //shieldprotocol+10, reconfigure+100, ,photons+20
      i = 0;
      gotoXY(3, 5);
      // 27-32//damage, range, hull, shield, cargo, torp
      printf("Ship Enhancements:");
      gotoXY(3, 7 + i);
      if (HS_UP_DMG != 0) {
        printf("%i Pulse cannon armour piercing shell upgrades.", HS_UP_DMG);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i extra damage per shot.", HS_UP_DMG * 10);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (HS_UP_RANGE != 0) {
        printf("%i Pulse cannon carbon alloy barrel upgrades.", HS_UP_RANGE);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i km range added.", HS_UP_RANGE * 10);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (HS_UP_HULL != 0) {
        printf("%i Tritanium hull strut upgrades.", HS_UP_HULL);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i damage dampening on hull per shot.", HS_UP_HULL * 10);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (HS_UP_SHIELD != 0) {
        printf("%i Shileding reaction protocol reconfigurations.",
        HS_UP_SHIELD);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i damage deflection on shield per shot.",
        HS_UP_SHIELD * 10);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (HS_UP_CARGO != 0) {
        printf("%i Cargo bay reconfigurations and expansion processes.",
        HS_UP_CARGO);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i extra cargo capacity.", HS_UP_CARGO * 100);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (HS_UP_TORP != 0) {
        printf("%i Photonic torpedo upgrades.", HS_UP_TORP);
        i++;
        gotoXY(3, 7 + i);
        printf("\t%i extra damage per torpedo.", HS_UP_TORP * 20);
        i += 2;
      }
      gotoXY(3, 7 + i);
      if (i == 0) {
        printf("No upgrades at this time.");
      }
    }
    gotoXY(3, 27);
    if (page == 1) {
      printf("0: Back\t\t2: Next");
    } else if (page == 3) {
      printf("1: Previous\t\t0: Back");
    } else {
      printf("1: Previous\t\t0: Back\t\t2: Next");
    }

    gotoXY(3, 28);
    choice = getch() - '0';
    gotoXY(3, 28);
    comLog(COM_BELOW_MAP); //66
    if (choice == 1) {
      if (page == 1) {
        printf("Cannot go back a page") ;
      } else {
        page--;
      }
    }
    if (choice == 2) {
      if (page == 3) {
        printf("Cannot go forward a page") ;
      } else {
        page++;
      }
    }
    if (choice != 1 && choice != 2 && choice != 0) {
      gotoXY(67, 27);
      printf("Invalid selection");
    }
  } while (choice != 0);

  // outfit log - guns equipped, upgrades equipped, average damage output,
  // max range, combat/trade status/title
}


void achievementsMenu() {
  Debug.log("void achievementsMenu()");
  int page = 1, choice, slot, value;
  do {
    planetHUD(); // dis = 0, 1 = syst, 2 = plan, 3 = ships, 4 = weps, 5 = kills
    if (page == 1) {
      gotoXY(3, 5);
      printf("Basic Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 20) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("The Traveler");
      printf("\t\t%i/20 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 10) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Discoverer");
      printf("\t\t\t%i/10 systems visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 15) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Land Harr");
      printf("\t\t\t%i/15 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 2) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Able Captain");
      printf("\t\t%i/2 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 5) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Rifleman");
      printf("\t\t\t%i/5 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 10) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Brute");
      printf("\t\t\t%i/10 enemies killed", ACHIEVE_KILLS);
    }
    if (page == 2) {
      gotoXY(3, 5);
      printf("Intermediate Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Well Travelled");
      printf("\t\t%i/50 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 25) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Explorer");
      printf("\t\t\t%i/25 systems visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 35) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Sphere Hunter");
      printf("\t\t%i/35 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 4) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Admiral");
      printf("\t\t\t%i/4 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 15) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Arms Dealer");
      printf("\t\t%i/15 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 25) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Soldier");
      printf("\t\t\t%i/25 enemiies killed", ACHIEVE_KILLS);
    }
    if (page == 3) {
      gotoXY(3, 5);
      printf("Advanced Achievements:");
      gotoXY(5, 7);
      if (ACHIEVE_DISTANCE >= 150) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Not Lost In Space");
      printf("\t\t%i/150 km travelled", ACHIEVE_DISTANCE);
      gotoXY(5, 8);
      if (ACHIEVE_SYSTEMS >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Found Your Hemingway");
      printf("\t%i/50 system visited", ACHIEVE_SYSTEMS);
      gotoXY(5, 9);
      if (ACHIEVE_PLANETS >= 75) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Diplomat");
      printf("\t\t\t%i/75 planets landed on", ACHIEVE_PLANETS);
      gotoXY(5, 10);
      if (ACHIEVE_SHIPS >= 5) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Enshiplopedia");
      printf("\t\t%i/5 ships owned", ACHIEVE_SHIPS);
      gotoXY(5, 11);
      if (ACHIEVE_WEAPONS >= 30) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Gun Fettish");
      printf("\t\t%i/30 weapons obtained", ACHIEVE_WEAPONS);
      gotoXY(5, 12);
      if (ACHIEVE_KILLS >= 50) {
        setC(COL_WHITE);
      } else {
        setC(COL_GREY);
      }
      printf("Warren Piece");
      printf("\t\t%i/50 enemies killed", ACHIEVE_KILLS);
// silver tounge
    }
    setC(COL_WHITE);
    gotoXY(3, 27);
    if (page == 1) {
      printf("0: Back\t\t2: Next");
    } else if (page == 3) {
      printf("1: Previous\t\t0: Back");
    } else {
      printf("1: Previous\t\t0: Back\t\t2: Next");
    }
    gotoXY(3, 29);
    printf("5: achievements[x] = y");
    gotoXY(3, 30);
    choice = getch() - '0';
    comLog(COM_BELOW_MAP); //66
    if (choice == 5) {
      gotoXY(3, 28);
      printf("achievements[");
      scanf("%i", &slot);
      if (slot > 9) {
        gotoXY(18, 28) ;
      } else {
        gotoXY(17, 28);
      }
      printf("] = ");
      scanf("%i", &value);
      if (slot > 50 || value > 200) {
        gotoXY(67, 27);
        printf("Invalid slot/value");
      } else {
        achievements[slot] = value;
      }
    }
    if (choice == 1) {
      if (page == 1) {
        printf("Cannot go back a page");
      } else {
        page--;
      }
    }
    if (choice == 2) {
      if (page == 3) {
        printf("Cannot go forward a page");
      } else {
        page++;
      }
    }
    if (choice != 1 && choice != 2 && choice != 0 && choice != 5) {
      printf("Invalid selection");
    }
  } while (choice != 0);
}


void gamblingMenu() {
  Debug.log("void gamblingMenu()");
  int choice;
  do {
    planetHUD();

    gotoXY(3, 27);
    printf("Under Development\t\t0: Back");
    choice = getch() - '0';
    if (choice != 1 && choice != 2 && choice != 0 && choice != 5) {
      printf("Invalid selection");
    }
  } while (choice != 0);
}


void initStats(int debug) { // debug = -1 on, 1 off
  Debug.log("void initStats(%d)", debug);
  HS_DATE = 407595;//date
  HS_SHIELD = (debug == 1) ? 0 : 10000; //shields
  HS_HULL = (debug == 1) ? 100 : 4000; //hull
// 3, 4, 5, 6 location
// 7 = security
  HS_ENERGY = (debug == 1) ? 400 : 60000; //energy
  HS_TORPEDOS = (debug == 1) ? 0 : 100; //torps
  HS_CREDITS = (debug == 1) ? 500 : 1000000000; //monies
  HS_PLASMA = 0;//warp plasma
  HS_DUTERIUM = 0;//duterium
  HS_LATINUM = 0;//latinum
  HS_WATER = 0;//water
  HS_URANIUM = 0;//uranium ore
// 16, 17, 18 = planets, enemies, stellar objects
  HS_SHIP_TYPE = (debug == 1) ? 1 : 5; //ship class 1-5
// 20 = enemy location
  HS_WEAPON1 = (debug == 1) ? 1 : 3; //21-25 = weapons (1-3)
  HS_WEAPON2 = (debug == 1) ? 0 : 3;
  HS_WEAPON3 = (debug == 1) ? 0 : 3;
  HS_WEAPON4 = (debug == 1) ? 0 : 3;
  HS_WEAPON5 = (debug == 1) ? 0 : 3;
  HS_WEAPONS = (debug == 1) ? 1 : 5; //total weapons
  HS_UP_DMG = 0;//damage upgrades
  HS_UP_RANGE = 0;//range upgrade
  HS_UP_HULL = 0;//hull upgrade
  HS_UP_SHIELD = 0;//shield upgrade
  HS_UP_CARGO = 0;//cargo upgrade
  HS_UP_TORP = 0;//torpedo upgrade
  HS_UP_ENGINE = 0;//engine upgrade

// HS_DEPLETION = energy depletion
// HS_IN_RANGE = guns in range
  HS_PASSENGERS = 0;//passengers


// shuttle, cargo, freight, frigate, destroyer
// shields1 = 0, 300, 500, 1000, 10000            1
// hull2 = 100, 500, 700, 2000, 4000              2
// energy8 = 0, 1000, 2000, 4000, 30000           3
// torps9 = 0, 5, 10, 40, 100                     4
// cargo11-15 = 100, 1000, 3000, 100000, 50000    5
// ship range = 6-10                          6
// cannon hardpoints = 16-20                  7
  CAP_CARGO = 100; // cargo
  capacityArray[2] = 1000;
  capacityArray[3] = 5000;
  capacityArray[4] = 10000;
  capacityArray[5] = 100000;
  CAP_HARDPOINT = 1; // hardpoints
  capacityArray[7] = 2;
  capacityArray[8] = 3;
  capacityArray[9] = 4;
  capacityArray[10] = 5;
  CAP_SHIELD = 0; // shields
  capacityArray[12] = 300;
  capacityArray[13] = 500;
  capacityArray[14] = 1000;
  capacityArray[15] = 10000;
  CAP_HULL = 100; // hull
  capacityArray[22] = 500;
  capacityArray[23] = 700;
  capacityArray[24] = 2000;
  capacityArray[25] = 4000;
  CAP_ENERGY = 400; // energy
  capacityArray[32] = 2000;
  capacityArray[33] = 4000;
  capacityArray[34] = 8000;
  capacityArray[35] = 60000;
  CAP_TORP = 0; // torps
  capacityArray[42] = 5;
  capacityArray[43] = 10;
  capacityArray[44] = 40;
  capacityArray[45] = 100;
  CAP_AVGPLASMA = 12; // commodity mids
  CAP_AVGDUTERIUM = 35;
  CAP_AVGLATINUM = 85;
  CAP_AVGWATER = 425;
  CAP_AVGURANIUM = 850;
  LASTBUY_PLASMA = 12;
  LASTBUY_DUTERIUM = 35;
  LASTBUY_LATINUM = 85;
  LASTBUY_WATER = 425;
  LASTBUY_URANIUM = 850;
  if (debug != 1) {
    ACHIEVE_DISTANCE = randomNumber(150);
  }
  if (debug != 1) {
    ACHIEVE_SYSTEMS = randomNumber(50);
  }
  if (debug != 1) {
    ACHIEVE_PLANETS = randomNumber(75);
  }
  if (debug != 1) {
    ACHIEVE_SHIPS = randomNumber(5);
  }
  if (debug != 1) {
    ACHIEVE_WEAPONS = randomNumber(30);
  }
  if (debug != 1) {
    ACHIEVE_KILLS = randomNumber(50);
  }
  if (debug != 1) {
    int i = 0;
    for (; i < SKILLS_I_SIZE; i++) {
      skillsArray[i] = randomNumber(50);
    }
  }
}

/**            ACHIEVEMENTS
0: distance travelled
1: systems visited
2: planets visited
3: ships commanded
4: weapons obtained
5: kills - leads to combat status
**/
