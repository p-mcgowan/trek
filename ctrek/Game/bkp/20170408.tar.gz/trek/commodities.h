#define CAP_AVGPLASMA   12
#define CAP_AVGDUTERIUM 35
#define CAP_AVGLATINUM  85
#define CAP_AVGWATER    425
#define CAP_AVGURANIUM  860

typedef struct Commodity {
  int avg;
  int range;
  int base;
}

